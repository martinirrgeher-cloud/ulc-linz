// services/exercisesStore.ts
import { downloadJson, overwriteJsonContent, uploadFile, deleteFile } from "@/lib/drive/DriveClientCore";
import { IDS } from "@/config/driveIds";
import type { Exercise, ExercisesJson, MediaItem } from "../types/exercise";
import { mapLegacyExercise } from "./_legacyMap";

function getExercisesFileId(): string {
  const anyIDS = IDS as any;
  const id = anyIDS.UEBUNGEN_FILE_ID || anyIDS.EXERCISES_FILE_ID || import.meta.env.VITE_DRIVE_UEBUNGEN_FILE_ID || import.meta.env.VITE_DRIVE_EXERCISES_FILE_ID;
  if (!id) throw new Error("UEBUNGEN_FILE_ID fehlt (IDS/ENV).");
  return id as string;
}
function getMediaFolderId(): string | undefined {
  const anyIDS = IDS as any;
  return anyIDS.UEBUNGEN_MEDIA_FOLDER_ID || anyIDS.EXERCISES_MEDIA_FOLDER_ID || import.meta.env.VITE_DRIVE_UEBUNGEN_MEDIA_FOLDER_ID || undefined;
}

async function loadRaw(): Promise<{ list: any[]; isLegacy: boolean }> {
  const raw = await downloadJson<any>(getExercisesFileId());
  const data = raw?.data ?? raw;
  if (Array.isArray(data)) return { list: data, isLegacy: true };
  if (Array.isArray((data as ExercisesJson)?.exercises)) return { list: (data as ExercisesJson).exercises as any[], isLegacy: false };
  return { list: [], isLegacy: false };
}

export async function loadExercises(): Promise<Exercise[]> {
  const { list } = await loadRaw();
  return list.map(mapLegacyExercise);
}

async function saveAll(list: any[], isLegacy: boolean): Promise<void> {
  if (isLegacy) {
    await overwriteJsonContent(getExercisesFileId(), list);
  } else {
    await overwriteJsonContent(getExercisesFileId(), { exercises: list });
  }
}

export async function addExercise(ex: Partial<Exercise>): Promise<Exercise> {
  const { list, isLegacy } = await loadRaw();
  const now = new Date().toISOString();
  const created = mapLegacyExercise({
    id: globalThis.crypto?.randomUUID ? crypto.randomUUID() : String(Date.now()),
    name: (ex.name || "").trim(),
    hauptgruppe: ex.hauptgruppe || "",
    untergruppe: ex.untergruppe || "",
    difficulty: ex.difficulty ?? 3,
    menge: ex.menge,
    einheit: ex.einheit,
    info: ex.info,
    active: ex.active !== false,
    createdAt: now, updatedAt: now,
  });
  list.push(created);
  await saveAll(list, isLegacy);
  return created;
}

export async function updateExercise(patch: Exercise): Promise<Exercise> {
  const { list, isLegacy } = await loadRaw();
  const idx = list.findIndex((x:any) => String(x.id) === String(patch.id));
  if (idx < 0) throw new Error("Übung nicht gefunden.");
  // Merge on legacy shape (keep legacy single-media fields in sync)
  const target = list[idx];
  const updated = { ...target, ...patch, updatedAt: new Date().toISOString() };
  // sync back legacy media fields (take first media item)
  if (Array.isArray(patch.media) && patch.media.length > 0) {
    const m = patch.media[0];
    updated.mediaUrl = m.url;
    updated.mediaType = m.type;
    updated.mediaName = m.name;
    updated.mediaId = m.id;
  }
  list[idx] = updated;
  await saveAll(list, isLegacy);
  return mapLegacyExercise(updated);
}

export async function uploadExerciseMedia(file: File): Promise<MediaItem> {
  const folderId = getMediaFolderId();
  const meta = await uploadFile(file, { parents: folderId ? [folderId] : undefined });
  const mime = meta.mimeType || file.type || "";
  const kind: "image" | "video" = mime.startsWith("video/") ? "video" : "image";
  const url = (meta.webContentLink || meta.downloadUrl || meta.webViewLink || "") as string;
  return { id: meta.id!, name: meta.name || file.name, mimeType: mime, url, type: kind, createdAt: new Date().toISOString() };
}

export async function linkMediaToExercise(exerciseId: string, media: MediaItem): Promise<Exercise> {
  const { list, isLegacy } = await loadRaw();
  const idx = list.findIndex((x:any) => String(x.id) === String(exerciseId));
  if (idx < 0) throw new Error("Übung nicht gefunden.");
  const target = list[idx];
  // legacy: keep single media fields in sync
  const updated = { ...target,
    mediaUrl: media.url, mediaType: media.type, mediaName: media.name, mediaId: media.id,
    updatedAt: new Date().toISOString()
  };
  list[idx] = updated;
  await saveAll(list, isLegacy);
  return mapLegacyExercise(updated);
}

export async function unlinkMediaFromExercise(exerciseId: string, mediaId: string, alsoDeleteOnDrive = false): Promise<Exercise> {
  const { list, isLegacy } = await loadRaw();
  const idx = list.findIndex((x:any) => String(x.id) === String(exerciseId));
  if (idx < 0) throw new Error("Übung nicht gefunden.");
  const target = list[idx];
  const updated = { ...target, mediaUrl: "", mediaType: "", mediaName: "", mediaId: "", updatedAt: new Date().toISOString() };
  list[idx] = updated;
  await saveAll(list, isLegacy);
  if (alsoDeleteOnDrive) { try { await deleteFile(mediaId); } catch (e) { console.warn("Drive delete failed:", e); } }
  return mapLegacyExercise(updated);
}
