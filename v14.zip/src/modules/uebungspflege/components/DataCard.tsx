import React, { useEffect, useMemo, useState } from "react";
import DifficultyStars from "./DifficultyStars";
import { removeFile } from "@/modules/uebungskatalog/services/UebungenStore";
import { exerciseUnits } from "@/modules/uebungskatalog/types/ExerciseTypes";

interface Props {
  selectedId: string | null;
  onSaved: () => void;
  addUebung: (u: any) => Promise<void>;
  updateUebung: (u: any) => Promise<void>;
  uploadMedia: (file: File) => Promise<{ id: string; url: string; type: "image" | "video"; name: string }>;
  gruppen: Record<string, string[]>;
  refresh: () => Promise<void>;
}

export default function DataCard({
  selectedId,
  onSaved,
  addUebung,
  updateUebung,
  uploadMedia,
  gruppen,
}: Props) {
  const [state, setState] = useState<any>({
    id: null,
    name: "",
    hauptgruppe: "",
    untergruppe: "",
    menge: "",
    einheit: "",
    difficulty: 1,
    active: true,
    mediaName: "",
    mediaUrl: "",
  });

  const untergruppen = useMemo(() => gruppen[state.hauptgruppe] || [], [state.hauptgruppe, gruppen]);

  useEffect(() => {
    if (!selectedId) return;
    const all = JSON.parse(localStorage.getItem("uebungen_cache") || "[]");
    const found = all.find((x: any) => x.id === selectedId);
    if (found) {
  // Sicherheitsabgleich für Untergruppe
  const validUntergruppe = gruppen[found.hauptgruppe]?.includes(found.untergruppe)
    ? found.untergruppe
    : "";
  setState({ ...found, untergruppe: validUntergruppe });
};
  }, [selectedId]);

  const setField = (f: string, v: any) => setState((s: any) => ({ ...s, [f]: v }));

  const onSubmit = async () => {
    if (!state.name || !state.hauptgruppe || !state.untergruppe) {
      alert("Bitte alle Pflichtfelder ausfüllen.");
      return;
    }
    const data = { ...state, menge: state.menge ? parseFloat(state.menge) : null };
   if (state.id) {
  await updateUebung(data);
} else {
  await addUebung(data);
  clearForm(); // Maske leeren nach neu anlegen
}
await onSaved();
alert("Gespeichert."); 


  };

  const clearForm = () => {
    setState({
      id: null,
      name: "",
      hauptgruppe: "",
      untergruppe: "",
      menge: "",
      einheit: "",
      difficulty: 1,
      active: true,
      mediaName: "",
      mediaUrl: "",
    });
  };

  return (
    <div className="data-card">
      <h3>Daten bearbeiten</h3>

      <input
        type="text"
        value={state.name ?? ""}
        placeholder="Name"
        onChange={(e) => setField("name", e.target.value)}
      />

      <select
        value={state.hauptgruppe ?? ""}
        onChange={(e) => setField("hauptgruppe", e.target.value)}
      >
        <option value="">– Hauptgruppe –</option>
        {Object.keys(gruppen).map((g) => (
          <option key={g}>{g}</option>
        ))}
      </select>

      <select
        value={state.untergruppe ?? ""}
        onChange={(e) => setField("untergruppe", e.target.value)}
      >
        <option value="">– Untergruppe –</option>
        {untergruppen.map((u) => (
          <option key={u}>{u}</option>
        ))}
      </select>

      <input
        type="number"
        value={state.menge ?? ""}
        placeholder="Menge"
        onChange={(e) => setField("menge", e.target.value)}
      />

      <select
        value={state.einheit ?? ""}
        onChange={(e) => setField("einheit", e.target.value)}
      >
        <option value="">– Einheit –</option>
        {exerciseUnits.map((u) => (
          <option key={u} value={u}>
            {u}
          </option>
        ))}
      </select>

      <div className="stars-row">
        <DifficultyStars
          value={state.difficulty ?? 1}
          onChange={(v) => setField("difficulty", v)}
        />
      </div>

{/* Medien-Upload */}
<div className="upload-row">
  <label className="upload-label">Medien-Datei</label>
  {state.mediaName ? (
    <div className="upload-preview">
      <span>{state.mediaName}</span>
      <button
        type="button"
        className="kt-btn secondary small"
        onClick={async () => {
          try {
            if (state.mediaId) { await removeFile(state.mediaId); }
          } catch (e) { console.error('Drive delete failed', e); }
          setState((prev:any)=>({ ...prev, mediaId: "", mediaUrl: "", mediaType: "", mediaName: "" }));
        }}
      >
        Entfernen
      </button>
    </div>
  ) : (
    
<input
  type="file"
  accept="image/*,video/*"
  onChange={async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;

    try {
      // Datei auf Google Drive hochladen
      const uploadedUrl = await uploadMedia(file);

      if (uploadedUrl) {
        const type = file.type.startsWith("image")
          ? "image"
          : file.type.startsWith("video")
          ? "video"
          : "file";

        // Medieninformationen im Zustand speichern
        setState((prev: any) => ({
          ...prev,
          mediaUrl: uploadedUrl,
          mediaType: type,
          mediaName: file.name,
        }));
      }
    } catch (err) {
      console.error("Upload fehlgeschlagen:", err);
    }
  }}
/>



  )}
</div>
      <div className="button-row">
        <button className="kt-btn primary" onClick={onSubmit}>
          Neu anlegen
        </button>
        <button className="kt-btn secondary" type="button" onClick={clearForm}>
          Maske leeren
        </button>
        <label className="active-inline">
          <input
            type="checkbox"
            checked={!!state.active}
            onChange={(e) => setField("active", e.target.checked)}
          />
          Aktiv
        </label>
      </div>
    </div>
  );
}
