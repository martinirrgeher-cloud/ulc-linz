import React, { useState } from "react";
import { useUebungsgruppen } from "@/modules/uebungspflege/hooks/useUebungsgruppen";
import "../styles/Uebungspflege.css";

type Props = { onClose: () => void };

export const GruppenVerwaltung: React.FC<Props> = ({ onClose }) => {
  const { gruppen, save } = useUebungsgruppen();
  const [newH, setNewH] = useState("");
  const [newU, setNewU] = useState<{ [k: string]: string }>({});
  const [open, setOpen] = useState<string | null>(null);

  const addH = async () => {
    const val = newH.trim();
    if (!val || gruppen[val]) return;
    await save({ ...gruppen, [val]: [] });
    setNewH("");
  };

  const addU = async (h: string) => {
    const val = (newU[h] || "").trim();
    if (!val) return;
    const updated = { ...gruppen, [h]: [...(gruppen[h] || []), val] };
    await save(updated);
    setNewU({ ...newU, [h]: "" });
  };

  return (
    <div className="settings-overlay">
      <div className="settings-modal">
        <div className="settings-header">
          <h2>Gruppen verwalten</h2>
          <button onClick={onClose}>×</button>
        </div>

        <div className="gruppen-addhaupt">
          <input
            type="text"
            placeholder="Neue Hauptgruppe"
            value={newH}
            onChange={(e) => setNewH(e.target.value)}
          />
          <button className="kt-btn" onClick={addH}>
            + Hauptgruppe
          </button>
        </div>

        {Object.keys(gruppen)
          .sort()
          .map((h) => (
            <div key={h} className="gruppe-item">
              <div
                className="gruppe-header"
                onClick={() => setOpen(open === h ? null : h)}
              >
                <strong>{h}</strong> <span>{open === h ? "▲" : "▼"}</span>
              </div>
              {open === h && (
                <div className="gruppe-body">
                  {(gruppen[h] || []).map((u) => (
                    <div key={u}>{u}</div>
                  ))}
                  <input
                    type="text"
                    placeholder="Neue Untergruppe"
                    value={newU[h] || ""}
                    onChange={(e) =>
                      setNewU({ ...newU, [h]: e.target.value })
                    }
                  />
                  <button className="kt-btn" onClick={() => addU(h)}>
                    + Untergruppe
                  </button>
                </div>
              )}
            </div>
          ))}
      </div>
    </div>
  );
};
