import React, { useEffect, useRef, useState } from "react";

type Props = {
  label?: string;
  onUpload: (file: File) => Promise<{ id: string; url: string; type: "image"|"video"; name: string }>;
  onClear?: () => void;
  previewUrl?: string;
  disabled?: boolean;
  maxSizeMB?: number;
};

const UploadField: React.FC<Props> = ({ label = "Medien hochladen", onUpload, onClear, previewUrl, disabled, maxSizeMB = 50 }) => {
  const inputRef = useRef<HTMLInputElement | null>(null);
  const [uploading, setUploading] = useState(false);
  const [localPreview, setLocalPreview] = useState<string | undefined>(previewUrl);
  const [info, setInfo] = useState<string | undefined>(undefined);

  useEffect(() => setLocalPreview(previewUrl), [previewUrl]);
  useEffect(() => () => { if (localPreview?.startsWith("blob:")) URL.revokeObjectURL(localPreview); }, [localPreview]);

  const openFileDialog = () => inputRef.current?.click();

  const handleChange: React.ChangeEventHandler<HTMLInputElement> = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const mb = file.size / (1024 * 1024);
    if (mb > maxSizeMB) {
      setInfo(`Datei zu groß (${mb.toFixed(1)} MB). Max ${maxSizeMB} MB.`);
      e.currentTarget.value = "";
      return;
    }
    setUploading(true);
    setInfo(undefined);
    try {
      const preview = URL.createObjectURL(file);
      setLocalPreview(preview);
      await onUpload(file);
    } finally {
      setUploading(false);
    }
  };

  const handleClear = () => {
    setLocalPreview(undefined);
    setInfo(undefined);
    if (inputRef.current) inputRef.current.value = "";
    onClear?.();
  };

  const isVideo = (url?: string) => !!url && (url.endsWith(".mp4") || url.endsWith(".webm"));

  return (
    <div className="upload-field">
      <div style={{ display: "flex", gap: 8, alignItems: "center" }}>
        <button type="button" className="kt-btn" onClick={openFileDialog} disabled={disabled || uploading}>
          {uploading ? "Lade hoch…" : label}
        </button>
        {localPreview && (
          <button type="button" className="kt-btn danger" onClick={handleClear} disabled={disabled || uploading}>
            Entfernen
          </button>
        )}
      </div>

      <input
        ref={inputRef}
        type="file"
        accept="image/*,video/*"
        style={{ display: "none" }}
        onChange={handleChange}
        disabled={disabled || uploading}
      />

      {info && <div style={{ color: "#b00", marginTop: 6, fontSize: 13 }}>{info}</div>}

      {localPreview && (
        <div className="upload-preview" style={{ marginTop: 8 }}>
          {isVideo(localPreview) ? (
            <video src={localPreview} controls style={{ maxWidth: "240px", borderRadius: 8 }} />
          ) : (
            <img src={localPreview} alt="Preview" style={{ maxWidth: "240px", borderRadius: 8 }} />
          )}
        </div>
      )}
    </div>
  );
};

export default UploadField;
