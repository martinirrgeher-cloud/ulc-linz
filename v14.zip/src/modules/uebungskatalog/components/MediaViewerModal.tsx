import React from "react";
import { extractFileIdFromUrl } from "@/lib/utils/extractFileIdFromUrl";

function toPreviewSrc(fileId?: string, mediaUrl?: string): string | null {
  const id = (fileId && fileId.trim()) || (mediaUrl ? extractFileIdFromUrl(mediaUrl) : "");
  if (!id) return null;
  return `https://drive.google.com/file/d/${encodeURIComponent(id)}/preview`;
}

export default function MediaViewerModal({
  open,
  onClose,
  fileId,
  mediaUrl,
  title,
}: {
  open: boolean;
  onClose: () => void;
  fileId?: string;
  mediaUrl?: string;
  title?: string;
}) {
  if (!open) return null;
  const src = toPreviewSrc(fileId, mediaUrl);
  if (!src) return null;

  return (
    <div className="fixed inset-0 bg-black/60 flex items-center justify-center z-50" onClick={onClose}>
      <div className="bg-white rounded-xl w-[92vw] max-w-[980px] aspect-video shadow-xl overflow-hidden" onClick={(e) => e.stopPropagation()}>
        <div className="px-4 py-2 text-sm font-medium border-b">{title || "Vorschau"}</div>
        <iframe src={src} className="w-full h-full" allow="autoplay" />
      </div>
    </div>
  );
}
