// services/authToken.ts
import { getTokenFromProvider } from "@/lib/drive/token";

/**
 * Resilient Google access token resolver.
 * 1) Ask global provider (set once in Auth/Google-Login)
 * 2) Fallback: try Local/SessionStorage common keys
 * 3) Fallback: try gapi (if present)
 */
export async function getAccessToken(): Promise<string | null> {
  // 1) Provider (recommended)
  const viaProvider = await getTokenFromProvider();
  if (viaProvider) return viaProvider;

  // 2) Local/session storage
  const candidates = [
    "google_token",
    "googleAccessToken",
    "gis_token",
    "auth.google",
    "auth",
    "GOOGLE_TOKEN",
    "GIS_TOKEN",
  ];
  for (const store of [localStorage, sessionStorage]) {
    for (const key of candidates) {
      try {
        const raw = store.getItem(key);
        if (!raw) continue;
        if (/^[A-Za-z0-9-_.]+$/.test(raw) && raw.length > 20) {
          return raw;
        }
        try {
          const obj = JSON.parse(raw);
          if (obj && typeof obj.access_token === "string") return obj.access_token;
          if (obj?.google && typeof obj.google.access_token === "string") return obj.google.access_token;
          if (obj?.token && typeof obj.token === "string") return obj.token;
        } catch {}
      } catch {}
    }
  }

  // 3) gapi (optional)
  try {
    const gapi: any = (globalThis as any).gapi;
    const auth = gapi?.auth2?.getAuthInstance?.();
    const at = auth?.currentUser?.get()?.getAuthResponse(true)?.access_token;
    if (typeof at === "string" && at.length > 10) return at;
  } catch {}

  return null;
}
