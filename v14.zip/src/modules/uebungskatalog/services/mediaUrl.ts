// services/mediaUrl.ts
// Utilities to preview Google Drive media safely inside the app.

/** Extract a Google Drive fileId from common URLs. */
export function extractDriveId(raw?: string): string | null {
  if (!raw) return null;
  try {
    const u = new URL(raw);
    const m1 = u.pathname.match(/\/file\/d\/([a-zA-Z0-9_-]+)/);
    if (m1 && m1[1]) return m1[1];
    const id = u.searchParams.get("id");
    if (id) return id;
    return null;
  } catch {
    // raw might already be an id
    if (/^[a-zA-Z0-9_-]{10,}$/.test(raw || "")) return raw as string;
    return null;
  }
}

/** Build the Drive preview URL for embedding in an <iframe>. */
export function toPreviewIframeUrl(raw?: string): string {
  const id = extractDriveId(raw || "");
  if (!id) return "";
  return `https://drive.google.com/file/d/${id}/preview`;
}

/**
 * Try to fetch the binary via Drive API using the current Google access token,
 * then return a blob object URL for safe same-origin rendering.
 * Requires an access token provider that your app already uses.
 */
export async function buildDriveBlobObjectUrl(
  rawUrlOrId: string,
  getAccessToken: () => Promise<string | null>
): Promise<string | null> {
  const id = extractDriveId(rawUrlOrId || "");
  if (!id) return null;
  const token = await getAccessToken().catch(() => null);
  if (!token) return null;

  const resp = await fetch(`https://www.googleapis.com/drive/v3/files/${id}?alt=media`, {
    method: "GET",
    headers: { Authorization: `Bearer ${token}` },
  });
  if (!resp.ok) return null;
  const blob = await resp.blob();
  const url = URL.createObjectURL(blob);
  return url;
}
