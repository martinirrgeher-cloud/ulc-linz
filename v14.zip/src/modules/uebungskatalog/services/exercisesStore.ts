// services/exercisesStore.ts
import { downloadJson } from "@/lib/drive/DriveClientCore";
import { IDS } from "@/config/driveIds";
import type { Exercise, ExercisesJson } from "../types/exercise";
import { mapLegacyExercise } from "./_legacyMap";

function getExercisesFileId(): string {
  const anyIDS = IDS as any;
  const id = anyIDS.UEBUNGEN_FILE_ID || anyIDS.EXERCISES_FILE_ID || import.meta.env.VITE_DRIVE_UEBUNGEN_FILE_ID || import.meta.env.VITE_DRIVE_EXERCISES_FILE_ID;
  if (!id) throw new Error("UEBUNGEN_FILE_ID fehlt (IDS/ENV).");
  return id as string;
}

export async function loadExercises(): Promise<Exercise[]> {
  const raw = await downloadJson<any>(getExercisesFileId());
  const data = raw?.data ?? raw;
  if (Array.isArray(data)) {
    // legacy: root array
    return data.map(mapLegacyExercise);
  }
  const list = (data as ExercisesJson)?.exercises;
  if (Array.isArray(list)) {
    return list.map(mapLegacyExercise);
  }
  return [];
}
