
import React, { useEffect, useMemo, useState } from "react";
import "./Kindertraining.css";
import KTHeader from "./components/KTHeader";
import PersonList from "./components/PersonList";
import NamePopup from "./components/NamePopup";
import NotePopup from "./components/NotePopup";
import { useKindertraining } from "./hooks/useKindertraining";

// Person-Typ lokal für Handler-Signaturen
type Person = { name: string; inactive?: boolean; paid?: boolean; generalNote?: string };

export default function Kindertraining() {
  // 👉 Alle benötigten Werte/Funktionen aus dem Hook holen
  const {
    week,
    info,
    prevWeek,
    nextWeek,
    persons,                // bereits gefiltert (Suche, Sortierung, Inaktive je nach Hook-State)
    activeDaysForWeek,      // [{ idx, name, dateStr, visible, disabled }]
    setInactiveForDate,     // (dateStr, boolean)
    getAttendance,          // (personName, dateStr) => true | false | null
    toggleAttendance,       // (personName, dateStr) => void
    addPerson,              // (name) => Promise<void>
    updatePerson,           // (name, patch) => Promise<void>
    getDayNote,             // (dateStr) => string
    setDayNote,             // (dateStr, text) => void
    setSearch,              // (text) => void
    // ⚙️ Settings für globalen Header
    sortOrder,
    setSortOrder,
    showInactive,
    setShowInactive,
    setActiveDaysForWeek,
  } = useKindertraining();

  // 🔎 lokale Suche (UI) → in Hook spiegeln
  const [search, setSearchLocal] = useState("");

  // 📅 sichtbare Tage: als einfache Stringliste (YYYY-MM-DD) für PersonList
  const visibleDays: string[] = useMemo(
    () => activeDaysForWeek.filter(d => d.visible).map(d => d.dateStr),
    [activeDaysForWeek]
  );
  // deaktivierte Spalten: Map YYYY-MM-DD -> true
  const inactiveDays: Record<string, boolean> = useMemo(() => {
    const m: Record<string, boolean> = {};
    activeDaysForWeek.forEach(d => { if (d.disabled) m[d.dateStr] = true; });
    return m;
  }, [activeDaysForWeek]);

  // ➕ Popup-State
  const [createOpen, setCreateOpen] = useState(false);
  const [editPerson, setEditPerson] = useState<Person | null>(null);
  const [dayNoteDate, setDayNoteDate] = useState<string | null>(null);

  const handleNewAthlete = () => setCreateOpen(true);
  const handleClickName = (p: Person) => setEditPerson(p);

  const handleCreate = (name: string) => { if (name?.trim()) addPerson(name.trim()); };
  const handleSaveEdit = (patch: { name: string; inactive?: boolean; generalNote?: string; paid?: boolean }) => {
    updatePerson(patch.name, { inactive: patch.inactive, generalNote: patch.generalNote, paid: patch.paid });
  };

  // 🔧 Name-Spaltenbreite: Dynamisch nach längstem Namen (inkl. optionaler Symbole)
  const maxLen = useMemo(() => Math.max(4, ...persons.map(p => p.name.length)), [persons]);
  const nameColWidth = useMemo(() => Math.min(420, Math.max(180, maxLen * 8)), [maxLen]);

  // 🔗 Suche an Hook binden (debounce nicht nötig)
  useEffect(() => { setSearch(search); }, [search, setSearch]);

  // 🧭 Settings an globalen Header announcen (wie Athleten)
  useEffect(() => {
    const detail = {
      module: "kindertraining",
      sortOrder,
      setSortOrder,
      showInactive,
      setShowInactive,
      getActiveDays: () => activeDaysForWeek.filter(d => d.visible).map(d => d.name),
      setActiveDaysForWeek,
    };
    window.dispatchEvent(new CustomEvent("appheader:settings", { detail }));
    return () => { window.dispatchEvent(new CustomEvent("appheader:settings:clear")); };
  }, [sortOrder, showInactive, activeDaysForWeek, setActiveDaysForWeek, setShowInactive, setSortOrder]);

  return (
    <div className="kt-shell compact-top">
      <div className="kt-card">
        {/* Kalender-Zeile (minimalistisch, wie Anmeldung) */}
        <KTHeader
          year={info.year}
          weekNumber={info.weekNumber}
          prevWeek={prevWeek}
          nextWeek={nextWeek}
        />

        {/* Suche + Neuer Athlet */}
        <div className="kt-toolbar slim">
          <input
            className="kt-input"
            placeholder="Suche Name..."
            value={search}
            onChange={(e) => setSearchLocal(e.target.value)}
          />
          <button className="kt-btn kt-btn--primary" onClick={handleNewAthlete}>
            Neuer Athlet
          </button>
        </div>

        {/* Liste */}
        <div className="kt-list">
          <PersonList
            persons={persons as Person[]}
            visibleDays={visibleDays}
            getAttendance={(p, d) => {
              const v = getAttendance(p, d);
              return v === true ? true : v === false ? false : undefined;
            }}
            toggleAttendance={(p, d) => toggleAttendance(p, d)}
            onClickName={handleClickName}
            nameColWidth={nameColWidth}
            inactiveDays={inactiveDays}
            setInactiveForDate={(d, val) => setInactiveForDate(d, val)}
          />
        </div>
      </div>

      {/* Popups */}
      <NamePopup
        mode="create"
        isOpen={createOpen}
        onClose={() => setCreateOpen(false)}
        onCreate={handleCreate}
      />
      <NamePopup
        mode="edit"
        isOpen={!!editPerson}
        onClose={() => setEditPerson(null)}
        person={editPerson || undefined}
        onSaveEdit={handleSaveEdit}
      />
      <NotePopup
        isOpen={!!dayNoteDate}
        onClose={() => setDayNoteDate(null)}
        initialText={dayNoteDate ? getDayNote(dayNoteDate) : ""}
        onSave={(txt) => { if (dayNoteDate) setDayNote(dayNoteDate, txt); }}
        title="Tagesnotiz"
      />
    </div>
  );
}
