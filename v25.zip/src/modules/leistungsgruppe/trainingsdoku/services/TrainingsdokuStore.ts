import { downloadJson, overwriteJsonContent, uploadFile, list } from "@/lib/drive/DriveClientCore";
import { IDS } from "@/config/driveIds";

export type DokuItemStatus = "AS_PLANNED"|"MODIFIED"|"SKIPPED"|"EXTRA";
export type DokuItem = {
  exerciseId: string;
  status: DokuItemStatus;
  planned: { reps: number|null; menge: number|null; einheit: string|null };
  actual?: { reps?: number|null; menge?: number|null; einheit?: string|null; gewicht?: number|null; strecke?: number|null; dauerMin?: number|null };
  comment?: string;
};
export type DokuDay = {
  startedAt?: string; finishedAt?: string;
  items: DokuItem[];
  summary?: any; // wird im Store berechnet
};
export type DokuData = { version: number; athleteId: string; logsByDate: Record<string, DokuDay> };

const folderId = () => IDS.TRAININGSDOKU_FOLDER_ID || import.meta.env.VITE_DRIVE_TRAININGSDOKU_FOLDER_ID;

async function resolveFileId(athleteId: string): Promise<string> {
  const name = `trainingsdoku_${athleteId}.json`;
  const res = await list({ q: `'${folderId()}' in parents and name='${name}' and trashed=false` });
  if (res?.files?.[0]?.id) return res.files[0].id;
  // neu anlegen
  const blob = new Blob([JSON.stringify({version:1, athleteId, logsByDate:{}}, null, 2)], { type: "application/json" });
  const up = await uploadFile({ name, mimeType: "application/json", body: blob, parents: [folderId()] });
  return up.fileId!;
}

export async function loadDoku(athleteId: string): Promise<DokuData> {
  const id = await resolveFileId(athleteId);
  return (await downloadJson<DokuData>(id))!;
}

export async function saveDoku(athleteId: string, data: DokuData): Promise<void> {
  const id = await resolveFileId(athleteId);
  await overwriteJsonContent(id, data);
}
