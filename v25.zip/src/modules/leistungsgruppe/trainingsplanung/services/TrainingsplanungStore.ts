import { downloadJson, overwriteJsonContent } from "@/lib/drive/DriveClientCore";
import { IDS } from "@/config/driveIds";

export type PlanTarget = { reps: number|null; menge: number|null; einheit: string|null };
export type PlanItem = {
  exerciseId: string;
  nameCache?: string;
  groupCache?: {haupt?: string; unter?: string};
  default: PlanTarget;
  target:  PlanTarget;
  pauseSec?: number|null;
  comment?: string;
};
export type PlanDay = { order: string[]; items: Record<string, PlanItem> };
export type PlansByAthlete = Record<string /*athleteId*/, Record<string /*YYYY-MM-DD*/, PlanDay>>;

export type TrainingsplanData = {
  version: number;
  updatedAt: string;
  plansByAthlete: PlansByAthlete;
};

const fileId = () => IDS.TRAININGSPLAN_FILE_ID || import.meta.env.VITE_DRIVE_TRAININGSPLAN_FILE_ID;

export async function loadPlans(): Promise<TrainingsplanData> {
  const data = await downloadJson<TrainingsplanData>(fileId());
  return data ?? { version: 1, updatedAt: new Date().toISOString(), plansByAthlete: {} };
}

export async function upsertAthleteDay(athleteId: string, dateISO: string, day: PlanDay): Promise<void> {
  const data = await loadPlans();
  data.plansByAthlete[athleteId] ??= {};
  data.plansByAthlete[athleteId][dateISO] = day;
  data.updatedAt = new Date().toISOString();
  await overwriteJsonContent(fileId(), data);
}
