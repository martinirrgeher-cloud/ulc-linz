import { useEffect, useMemo, useState } from "react";
import { loadPlans, upsertAthleteDay, PlanItem, PlanDay } from "../services/TrainingsplanungStore";
import { addDays, startOfISOWeek, toISODate, weekRangeFrom } from "../../common/date";

export type ExerciseLite = {
  id: string;
  name: string;
  haupt?: string|null;
  unter?: string|null;
  reps?: number|null;
  menge?: number|null;
  einheit?: string|null;
};

type SearchState = {
  text: string;
  haupt: string;
  unter: string;
};

export function useTrainingsplanung() {
  const today = toISODate(new Date());
  const [dateISO, setDateISO] = useState<string>(today);
  const [athleteId, setAthleteId] = useState<string>("");
  const [athleteName, setAthleteName] = useState<string>("");
  const [planDay, setPlanDay] = useState<PlanDay | null>(null);
  const [allExercises, setAllExercises] = useState<ExerciseLite[]>([]);
  const [search, setSearch] = useState<SearchState>({ text: "", haupt: "", unter: "" });
  const [onlyRegistered, setOnlyRegistered] = useState<boolean>(false);

  useEffect(() => {
    const w: any = (window as any);
    if (w?.ULC?.currentAthlete) {
      const { id, name } = w.ULC.currentAthlete;
      setAthleteId(id ?? "");
      setAthleteName(name ?? "");
    }
  }, []);

  useEffect(() => {
    async function loadExercises() {
      try {
        const w: any = (window as any);
        if (w?.ULC?.listExercisesLite) {
          const list = await w.ULC.listExercisesLite();
          setAllExercises(list);
          return;
        }
      } catch(e) {
        console.warn("exercise load failed (global)", e);
      }
      setAllExercises([]);
    }
    loadExercises();
  }, []);

  const filteredExercises = useMemo(() => {
    const t = search.text.trim().toLowerCase();
    return allExercises.filter(ex => {
      if (t && !(ex.name.toLowerCase().includes(t))) return false;
      if (search.haupt && (ex.haupt ?? "") !== search.haupt) return false;
      if (search.unter && (ex.unter ?? "") !== search.unter) return false;
      return true;
    });
  }, [allExercises, search]);

  useEffect(() => {
    async function load() {
      if (!athleteId || !dateISO) { setPlanDay(null); return; }
      const all = await loadPlans();
      const day = all.plansByAthlete?.[athleteId]?.[dateISO];
      setPlanDay(day ?? { order: [], items: {} });
    }
    load();
  }, [athleteId, dateISO]);

  function addExercise(ex: ExerciseLite) {
    if (!planDay) return;
    const id = crypto.randomUUID();
    const newItem: PlanItem = {
      exerciseId: ex.id,
      nameCache: ex.name,
      groupCache: { haupt: ex.haupt ?? undefined, unter: ex.unter ?? undefined },
      default: { reps: ex.reps ?? null, menge: ex.menge ?? null, einheit: ex.einheit ?? null },
      target:  { reps: ex.reps ?? null, menge: ex.menge ?? null, einheit: ex.einheit ?? null },
      pauseSec: null,
      comment: ""
    };
    setPlanDay({
      order: [...planDay.order, id],
      items: { ...planDay.items, [id]: newItem }
    });
  }

  function updateItem(itId: string, patch: Partial<PlanItem>) {
    if (!planDay) return;
    setPlanDay({
      ...planDay,
      items: { ...planDay.items, [itId]: { ...planDay.items[itId], ...patch } }
    });
  }

  function removeItem(itId: string) {
    if (!planDay) return;
    const { [itId]:_, ...rest } = planDay.items;
    setPlanDay({
      order: planDay.order.filter(id => id !== itId),
      items: rest
    });
  }

  function moveItem(itId: string, dir: -1|1) {
    if (!planDay) return;
    const idx = planDay.order.indexOf(itId);
    if (idx < 0) return;
    const newIdx = Math.max(0, Math.min(planDay.order.length-1, idx + dir));
    if (newIdx === idx) return;
    const arr = [...planDay.order];
    arr.splice(idx, 1);
    arr.splice(newIdx, 0, itId);
    setPlanDay({ ...planDay, order: arr });
  }

  async function save() {
    if (!athleteId || !dateISO || !planDay) return;
    await upsertAthleteDay(athleteId, dateISO, planDay);
  }

  function copyPlanTo(athleteIds: string[], dates: string[]) {
    return async () => {
      if (!planDay) return;
      for (const aId of athleteIds) {
        for (const d of dates) {
          await upsertAthleteDay(aId, d, planDay);
        }
      }
    };
  }

  function weekFromDate(): string[] {
    const start = startOfISOWeek(new Date(dateISO + "T00:00:00"));
    return weekRangeFrom(start);
  }

  return {
    dateISO, setDateISO,
    athleteId, setAthleteId,
    athleteName, setAthleteName,
    planDay, setPlanDay,
    addExercise, updateItem, removeItem, moveItem,
    save,
    filteredExercises, search, setSearch,
    onlyRegistered, setOnlyRegistered,
    copyPlanTo, weekFromDate
  };
}
