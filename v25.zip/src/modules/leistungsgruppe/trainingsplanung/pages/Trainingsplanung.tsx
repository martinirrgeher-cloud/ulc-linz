import React, { useMemo, useState } from "react";
import { useTrainingsplanung } from "../hooks/useTrainingsplanung";
import PlanEditor from "../components/PlanEditor";
import "../styles/Trainingsplanung.css";
import { toISODate } from "../../common/date";

type CandidateExercise = {
  id: string; name: string; haupt?: string|null; unter?: string|null; reps?: number|null; menge?: number|null; einheit?: string|null;
};

export default function TrainingsplanungPage(){
  const {
    dateISO, setDateISO,
    athleteId, setAthleteId,
    athleteName, setAthleteName,
    planDay, addExercise, updateItem, removeItem, moveItem, save,
    filteredExercises, search, setSearch,
    onlyRegistered, setOnlyRegistered,
    copyPlanTo, weekFromDate
  } = useTrainingsplanung();

  const [copyToIds, setCopyToIds] = useState<string>(""); // comma-separated ids
  const [copyScope, setCopyScope] = useState<"DAY"|"WEEK">("DAY");

  const planOrder = planDay?.order ?? [];
  const planItems = planDay?.items ?? {};

  const canSave = !!athleteId && !!dateISO && !!planDay;

  const [manualEx, setManualEx] = useState<CandidateExercise>({ id:"", name:"", reps:null, menge:null, einheit:null });
  function addManual(){
    if (!manualEx.id || !manualEx.name) return;
    addExercise(manualEx);
    setManualEx({ id:"", name:"", reps:null, menge:null, einheit:null });
  }

  const targetDates = useMemo(() => {
    if (copyScope === "DAY") return [dateISO];
    return weekFromDate();
  }, [copyScope, dateISO]);

  async function handleCopy(){
    const ids = copyToIds.split(",").map(s=>s.trim()).filter(Boolean);
    if (!ids.length) return;
    await copyPlanTo(ids, targetDates)();
    alert("Plan kopiert.");
  }

  return (
    <div className="tp-container">
      <div className="tp-left">
        <div className="tp-header">
          <div>
            <div className="tp-section-title">Datum</div>
            <input className="tp-input" type="date" value={dateISO} onChange={e=>setDateISO(e.target.value || toISODate(new Date()))} />
          </div>
          <div>
            <div className="tp-section-title">Athlet-ID</div>
            <input className="tp-input" placeholder="athlete-123" value={athleteId} onChange={e=>setAthleteId(e.target.value)} />
          </div>
          <div>
            <div className="tp-section-title">Name (optional)</div>
            <input className="tp-input" placeholder="Raphael Briel" value={athleteName} onChange={e=>setAthleteName(e.target.value)} />
          </div>
          <div style={{alignSelf:"flex-end"}}>
            <label style={{display:"flex",gap:6,alignItems:"center"}}>
              <input type="checkbox" checked={onlyRegistered} onChange={e=>setOnlyRegistered(e.target.checked)} />
              Nur angemeldet
            </label>
          </div>
          <div style={{marginLeft:"auto",alignSelf:"flex-end"}}>
            <button className={"tp-btn primary"} disabled={!canSave} onClick={save}>Speichern</button>
          </div>
        </div>

        <div className="tp-card">
          <div style={{display:"flex",justifyContent:"space-between",alignItems:"center"}}>
            <div style={{fontWeight:600}}>Übungssuche</div>
            <div className="tp-badge">Tip: <span className="tp-kbd">/</span> zum Fokussieren</div>
          </div>
          <div className="tp-row">
            <input
              className="tp-input"
              placeholder="Suche nach Name…"
              value={search.text}
              onChange={e=>setSearch(s=>({...s, text: e.target.value}))}
            />
            <input
              className="tp-input"
              placeholder="Hauptgruppe (optional)"
              value={search.haupt}
              onChange={e=>setSearch(s=>({...s, haupt: e.target.value}))}
            />
          </div>
          <div className="tp-row">
            <input
              className="tp-input"
              placeholder="Untergruppe (optional)"
              value={search.unter}
              onChange={e=>setSearch(s=>({...s, unter: e.target.value}))}
            />
            <div></div>
          </div>
          <div style={{marginTop:8}}>
            {filteredExercises.length>0 ? filteredExercises.slice(0,50).map(ex=>(
              <div key={ex.id} className="tp-card" style={{marginBottom:6}}>
                <div style={{display:"flex",justifyContent:"space-between",alignItems:"center"}}>
                  <div>
                    <div style={{fontWeight:600}}>{ex.name}</div>
                    <div className="tp-badge">{ex.haupt ?? "—"}{ex.unter?` / ${ex.unter}`:""}</div>
                  </div>
                  <button className="tp-btn" onClick={()=>addExercise(ex)}>Hinzufügen</button>
                </div>
                <div className="tp-row">
                  <input className="tp-input" readOnly value={ex.reps ?? ""} placeholder="Wdh." />
                  <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:8}}>
                    <input className="tp-input" readOnly value={ex.menge ?? ""} placeholder="Menge" />
                    <input className="tp-input" readOnly value={ex.einheit ?? ""} placeholder="Einheit" />
                  </div>
                </div>
              </div>
            )) : <div className="tp-badge">Kein Katalog verfügbar – du kannst unten manuell hinzufügen.</div>}
          </div>

          <div style={{marginTop:12}}>
            <div style={{fontWeight:600, marginBottom:6}}>Manuell hinzufügen</div>
            <div className="tp-row">
              <input className="tp-input" placeholder="Übungs-ID" value={manualEx.id} onChange={e=>setManualEx({...manualEx, id:e.target.value})} />
              <input className="tp-input" placeholder="Name" value={manualEx.name} onChange={e=>setManualEx({...manualEx, name:e.target.value})} />
            </div>
            <div className="tp-row">
              <input className="tp-input" type="number" placeholder="Wdh." value={manualEx.reps ?? ""} onChange={e=>setManualEx({...manualEx, reps:e.target.value===""?null:Number(e.target.value)})} />
              <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:8}}>
                <input className="tp-input" type="number" placeholder="Menge" value={manualEx.menge ?? ""} onChange={e=>setManualEx({...manualEx, menge:e.target.value===""?null:Number(e.target.value)})} />
                <input className="tp-input" placeholder="Einheit" value={manualEx.einheit ?? ""} onChange={e=>setManualEx({...manualEx, einheit:e.target.value||null})} />
              </div>
            </div>
            <div className="tp-actions" style={{marginTop:8}}>
              <button className="tp-btn" onClick={addManual}>Hinzufügen</button>
            </div>
          </div>
        </div>
      </div>

      <div className="tp-right">
        <div className="tp-card">
          <div style={{display:"flex",justifyContent:"space-between",alignItems:"center"}}>
            <div style={{fontWeight:600}}>Plan für {athleteName || athleteId || "—"} am {dateISO}</div>
          </div>
          <PlanEditor
            planOrder={planOrder}
            planItems={planItems}
            onUpdate={updateItem}
            onRemove={removeItem}
            onMove={moveItem}
          />
        </div>

        <div className="tp-card">
          <div style={{fontWeight:600, marginBottom:6}}>Plan kopieren</div>
          <div className="tp-row">
            <select className="tp-select" value={copyScope} onChange={e=>setCopyScope(e.target.value as any)}>
              <option value="DAY">Nur diesen Tag</option>
              <option value="WEEK">Ganze (ISO-)Woche ab Datum</option>
            </select>
            <input className="tp-input" placeholder="Ziel-Athleten-IDs (Komma-getrennt)" value={copyToIds} onChange={e=>setCopyToIds(e.target.value)} />
          </div>
          <div className="tp-actions" style={{marginTop:8}}>
            <button className="tp-btn" onClick={handleCopy}>Kopieren</button>
            <div className="tp-badge">Zieldaten: {copyScope==="DAY"?dateISO:weekFromDate().join(", ")}</div>
          </div>
        </div>
      </div>
    </div>
  );
}
