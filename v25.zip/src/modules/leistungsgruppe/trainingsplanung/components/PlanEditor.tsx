import React, { useMemo, useState } from "react";
import { PlanItem } from "../services/TrainingsplanungStore";

type Props = {
  planOrder: string[];
  planItems: Record<string, PlanItem>;
  onUpdate: (id: string, patch: Partial<PlanItem>) => void;
  onRemove: (id: string) => void;
  onMove: (id: string, dir: -1|1) => void;
};

export default function PlanEditor({ planOrder, planItems, onUpdate, onRemove, onMove }: Props){
  const [editing, setEditing] = useState<string|null>(null);

  const entries = useMemo(() => planOrder.map(id => ({ id, it: planItems[id] })), [planOrder, planItems]);

  function ensureConsistency(it: PlanItem) {
    const t = it.target;
    if (t.reps != null && t.reps !== undefined && t.reps !== (null as any)) {
      return { ...it, target: { ...t, menge: null, einheit: null } };
    }
    if (t.menge != null && t.menge !== undefined) {
      return { ...it, target: { ...t, reps: null } };
    }
    return it;
  }

  return (
    <div>
      {entries.map(({id, it}, idx) => {
        const editable = editing === id;
        const safe = ensureConsistency(it);
        return (
          <div key={id} className="tp-card">
            <div style={{display:"flex",justifyContent:"space-between",gap:8,alignItems:"center"}}>
              <div>
                <div style={{fontWeight:600}}>{safe.nameCache ?? safe.exerciseId}</div>
                <div className="tp-badge">{safe.groupCache?.haupt ?? "—"}{safe.groupCache?.unter ? ` / ${safe.groupCache.unter}`:""}</div>
              </div>
              <div className="tp-list-actions">
                <button className="tp-btn" title="nach oben" onClick={()=>onMove(id, -1)}>↑</button>
                <button className="tp-btn" title="nach unten" onClick={()=>onMove(id, +1)}>↓</button>
                <button className="tp-btn" onClick={()=>setEditing(editable?null:id)}>{editable?"Fertig":"Bearb."}</button>
                <button className="tp-btn" onClick={()=>onRemove(id)}>Entf</button>
              </div>
            </div>

            <div className="tp-row">
              <div>
                <div className="tp-section-title">Ziel (Target)</div>
                <div style={{display:"grid",gridTemplateColumns:"1fr 1fr 1fr",gap:8}}>
                  <input
                    className="tp-input"
                    type="number"
                    placeholder="Wdh."
                    value={safe.target.reps ?? ""}
                    onChange={e=>onUpdate(id, { target: { ...safe.target, reps: e.target.value===""?null:Number(e.target.value) } as any })}
                    disabled={!editable}
                  />
                  <input
                    className="tp-input"
                    type="number"
                    placeholder="Menge"
                    value={safe.target.menge ?? ""}
                    onChange={e=>onUpdate(id, { target: { ...safe.target, menge: e.target.value===""?null:Number(e.target.value) } as any })}
                    disabled={!editable}
                  />
                  <input
                    className="tp-input"
                    type="text"
                    placeholder="Einheit (min, km, m…)"
                    value={safe.target.einheit ?? ""}
                    onChange={e=>onUpdate(id, { target: { ...safe.target, einheit: e.target.value || null } as any })}
                    disabled={!editable}
                  />
                </div>
              </div>
              <div>
                <div className="tp-section-title">Rahmen</div>
                <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:8}}>
                  <input
                    className="tp-input"
                    type="number"
                    placeholder="Pause (Sek.)"
                    value={safe.pauseSec ?? ""}
                    onChange={e=>onUpdate(id, { pauseSec: e.target.value===""?null:Number(e.target.value) })}
                    disabled={!editable}
                  />
                  <input
                    className="tp-input"
                    type="text"
                    placeholder="Kommentar"
                    value={safe.comment ?? ""}
                    onChange={e=>onUpdate(id, { comment: e.target.value })}
                    disabled={!editable}
                  />
                </div>
              </div>
            </div>

            <div className="tp-spacer"></div>
            <div className="tp-badge">Default: {safe.default.reps ?? "—"} {safe.default.menge ?? ""} {safe.default.einheit ?? ""}</div>
          </div>
        );
      })}
      {entries.length===0 && <div className="tp-badge">Noch keine Übungen im Plan.</div>}
    </div>
  );
}
