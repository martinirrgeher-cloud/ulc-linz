// Uebungspflege.tsx (use token helper)
import { useCallback, useEffect, useMemo, useState } from "react";
import type { Exercise, MediaItem } from "./types/exercise";
import { addExercise, loadExercises, updateExercise, uploadExerciseMedia, linkMediaToExercise, unlinkMediaFromExercise } from "./services/exercisesStore";
import { toPreviewIframeUrl, buildDriveBlobObjectUrl } from "./services/mediaUrl";
import { getAccessToken } from "./services/authToken";
import "./Uebungspflege.css";

type Filter = { q: string; haupt?: string; unter?: string; onlyActive: boolean; };
const DEBOUNCE_MS = 300;

export default function UebungspflegePage() {
  const [all, setAll] = useState<Exercise[]>([]);
  const [flt, setFlt] = useState<Filter>({ q: "", onlyActive: true });
  const [sel, setSel] = useState<Exercise | null>(null);
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState<string | null>(null);
  const [preview, setPreview] = useState<MediaItem | null>(null);
  const [previewSrc, setPreviewSrc] = useState<string | null>(null);
  const [useIframe, setUseIframe] = useState(false);

  const reload = useCallback(async () => {
    setBusy(true); setErr(null);
    try { setAll(await loadExercises()); } catch (e:any) { setErr(e?.message || "Laden fehlgeschlagen"); }
    finally { setBusy(false); }
  }, []);

  useEffect(() => { reload(); }, [reload]);

  // Preview source builder (blob first, iframe fallback)
  useEffect(() => {
    let revoked: string | null = null;
    (async () => {
      if (!preview) { setPreviewSrc(null); setUseIframe(false); return; }
      const blobUrl = await buildDriveBlobObjectUrl(preview.url, getAccessToken).catch(() => null);
      if (blobUrl) {
        setPreviewSrc(blobUrl);
        setUseIframe(false);
        revoked = blobUrl;
      } else {
        setPreviewSrc(toPreviewIframeUrl(preview.url));
        setUseIframe(true);
      }
    })();
    return () => { if (revoked) URL.revokeObjectURL(revoked); };
  }, [preview]);

  const hauptgruppen = useMemo(() => Array.from(new Set(all.map(e => e.hauptgruppe).filter(Boolean))).sort((a,b)=>a.localeCompare(b,"de",{sensitivity:"base"})), [all]);
  const untergruppen = useMemo(() => {
    const base = flt.haupt ? all.filter(e => e.hauptgruppe === flt.haupt) : all;
    return Array.from(new Set(base.map(e => e.untergruppe).filter(Boolean))).sort((a,b)=>a.localeCompare(b,"de",{sensitivity:"base"}));
  }, [all, flt.haupt]);

  const [q, setQ] = useState(flt.q);
  useEffect(() => { const t=setTimeout(()=>setFlt(s=>({...s,q})), DEBOUNCE_MS); return ()=>clearTimeout(t); }, [q]);

  const list = useMemo(() => {
    let x = all.slice();
    if (flt.onlyActive) x = x.filter(e => e.active !== false);
    if (flt.haupt) x = x.filter(e => e.hauptgruppe === flt.haupt);
    if (flt.unter) x = x.filter(e => e.untergruppe === flt.unter);
    if (flt.q.trim()) {
      const s = flt.q.trim().toLowerCase();
      x = x.filter(e => (e.name||"").toLowerCase().includes(s) || (e.info||"").toLowerCase().includes(s) || (e.einheit||"").toLowerCase().includes(s));
    }
    return x.sort((a,b)=>a.name.localeCompare(b.name,"de",{sensitivity:"base"}));
  }, [all, flt]);

  const onCreate = useCallback(async () => {
    const name = prompt("Name der Übung?");
    if (!name) return;
    setBusy(true); setErr(null);
    try {
      const created = await addExercise({ name, hauptgruppe: flt.haupt || "", untergruppe: flt.unter || "", difficulty: 3, active: true });
      setAll(a => a.concat([created]));
      setSel(created);
    } catch (e:any) { setErr(e?.message || "Anlegen fehlgeschlagen"); }
    finally { setBusy(false); }
  }, [flt.haupt, flt.unter]);

  const onSave = useCallback(async (ex: Exercise) => {
    if (!ex.name.trim() || !ex.hauptgruppe.trim() || !ex.untergruppe.trim()) { alert("Name, Hauptgruppe und Untergruppe sind Pflichtfelder."); return; }
    setBusy(true); setErr(null);
    try {
      const upd = await updateExercise(ex);
      setAll(a => a.map(i => i.id===upd.id? upd : i));
      setSel(upd);
    } catch (e:any) { setErr(e?.message || "Speichern fehlgeschlagen"); }
    finally { setBusy(false); }
  }, []);

  const onUpload = useCallback(async (files: FileList | null) => {
    if (!sel || !files || !files.length) return;
    setBusy(true); setErr(null);
    try {
      for (const file of Array.from(files)) {
        const media: MediaItem = await uploadExerciseMedia(file);
        await linkMediaToExercise(sel.id, media);
      }
      const fresh = await loadExercises();
      const upd = fresh.find(e => e.id === sel.id) || null;
      setAll(fresh); setSel(upd);
    } catch (e:any) { setErr(e?.message || "Upload fehlgeschlagen"); }
    finally { setBusy(false); }
  }, [sel]);

  const onRemoveMedia = useCallback(async (m: MediaItem) => {
    if (!sel) return;
    if (!confirm(`Medien „${m.name}“ entfernen?`)) return;
    setBusy(true); setErr(null);
    try {
      await unlinkMediaFromExercise(sel.id, m.id, /*alsoDeleteOnDrive*/ false);
      const fresh = await loadExercises();
      setAll(fresh); setSel(fresh.find(e => e.id === sel.id) || null);
    } catch (e:any) { setErr(e?.message || "Entfernen fehlgeschlagen"); }
    finally { setBusy(false); }
  }, [sel]);

  const firstMedia: MediaItem | null = sel && (sel.media && sel.media.length > 0 ? sel.media[0] : null);

  return (
    <div className="ex-container">
      {/* UI unverändert; nur Token-Beschaffung angepasst */}
      {preview && (
        <div className="ex-modal" onClick={()=>setPreview(null)}>
          <div className="ex-modal-content" onClick={(e)=>e.stopPropagation()}>
            <button className="ex-modal-close" onClick={()=>setPreview(null)} aria-label="Schließen">×</button>
            {!useIframe && previewSrc ? (
              preview.type === "image" ? (
                <img src={previewSrc} alt={preview.name} className="ex-modal-media" />
              ) : (
                <video className="ex-modal-media" src={previewSrc} controls autoPlay playsInline preload="metadata" />
              )
            ) : (
              <iframe className="ex-modal-media" src={toPreviewIframeUrl(preview.url)} allow="autoplay" />
            )}
            <div className="ex-modal-caption">{preview.name}</div>
          </div>
        </div>
      )}
    </div>
  );
}

function imageIcon() {
  return (
    <svg viewBox="0 0 24 24" width="22" height="22" aria-hidden="true">
      <path d="M21 19V5a2 2 0 0 0-2-2H5a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2ZM8.5 11A2.5 2.5 0 1 1 11 8.5 2.5 2.5 0 0 1 8.5 11Zm-3 7 5-6 4 5 3-4 3 5Z"></path>
    </svg>
  );
}
function videoIcon() {
  return (
    <svg viewBox="0 0 24 24" width="22" height="22" aria-hidden="true">
      <path d="M17 10.5V7a2 2 0 0 0-2-2H5A2 2 0 0 0 3 7v10a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2v-3.5l4 2v-7l-4 2Z"></path>
    </svg>
  );
}
