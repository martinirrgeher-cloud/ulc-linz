import React, { useMemo, useState, useEffect } from "react";

interface Props {
  uebungen: any[];
  onSelect: (id: string) => void;
  gruppen: Record<string, string[]>;
}

export default function SearchCard({ uebungen = [], onSelect, gruppen }: Props) {
  const [search, setSearch] = useState("");
  const [hauptgruppe, setHauptgruppe] = useState("");
  const [untergruppe, setUntergruppe] = useState("");

  useEffect(() => {
    localStorage.setItem("uebungen_cache", JSON.stringify(uebungen));
  }, [uebungen]);

  const untergruppen = useMemo(() => {
    if (!hauptgruppe) return [];
    return gruppen[hauptgruppe] || [];
  }, [hauptgruppe, gruppen]);

  const filtered = useMemo(() => {
    const s = search.toLowerCase();
    return (uebungen ?? []).filter(
      (u) =>
        (!hauptgruppe || u.hauptgruppe === hauptgruppe) &&
        (!untergruppe || u.untergruppe === untergruppe) &&
        u.name.toLowerCase().includes(s)
    );
  }, [uebungen, search, hauptgruppe, untergruppe]);

  return (
    <div className="search-card">
      <h3>Übung suchen</h3>
      <input
        type="text"
        placeholder="Name..."
        value={search}
        onChange={(e) => setSearch(e.target.value)}
      />
      <select value={hauptgruppe} onChange={(e) => setHauptgruppe(e.target.value)}>
        <option value="">Alle Hauptgruppen</option>
        {Object.keys(gruppen).map((g) => (
          <option key={g} value={g}>
            {g}
          </option>
        ))}
      </select>
      {hauptgruppe && (
        <select
          value={untergruppe}
          onChange={(e) => setUntergruppe(e.target.value)}
        >
          <option value="">Alle Untergruppen</option>
          {untergruppen.map((u) => (
            <option key={u} value={u}>
              {u}
            </option>
          ))}
        </select>
      )}
      <div className="result-list">
        {filtered.map((u) => (
          <div key={u.id} className="result-item" onClick={() => onSelect(u.id)}>
            {u.name}{" "}
            <span className="small">
              ({u.hauptgruppe} / {u.untergruppe})
            </span>
          </div>
        ))}
        {!filtered.length && <div className="no-result">Keine Treffer</div>}
      </div>
    </div>
  );
}
