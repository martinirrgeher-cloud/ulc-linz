import React from "react";
import "./DifficultyStars.css";

interface Props {
  value: number;
  onChange: (value: number) => void;
}

export default function DifficultyStars({ value, onChange }: Props) {
  const stars = [1, 2, 3, 4, 5];

  return (
    <div className="difficulty-stars">
      {stars.map((s) => (
        <button
          key={s}
          type="button"
          className={`difficulty-star ${value >= s ? "active" : ""}`}
          onClick={() => onChange(s)}
        >
          ★
        </button>
      ))}
    </div>
  );
}