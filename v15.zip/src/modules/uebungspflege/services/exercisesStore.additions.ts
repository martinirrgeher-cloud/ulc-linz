// src/modules/uebungspflege/services/exercisesStore.additions.ts
import { uploadToDrive } from "./mediaUpload";
import { overwriteJsonContent, downloadJson } from "@/lib/drive/DriveClientCore";
import { IDS } from "@/config/driveIds";

export type MediaItem = {
  id: string;
  name: string;
  type: "image" | "video";
  url: string;
  previewUrl: string;
  resourceKey?: string;
};

export type Exercise = {
  id: string;
  name: string;
  hauptgruppe: string;
  untergruppe: string;
  info?: string;
  einheit?: string;
  difficulty?: number;
  active?: boolean;
  media?: MediaItem[];
};

type ExercisesJson = Exercise[];

export async function uploadExerciseMedia(file: File): Promise<MediaItem> {
  const folderId = IDS.UEBUNGEN_MEDIA_FOLDER_ID as string;
  if (!folderId) throw new Error("UEBUNGEN_MEDIA_FOLDER_ID fehlt (env/config).");

  const up = await uploadToDrive(file, { folderId, makeAnyoneWithLink: true });
  const type: "image" | "video" = (file.type || "").startsWith("video/") ? "video" : "image";

  return { id: up.id, name: up.name, type, url: up.directUrl, previewUrl: up.previewUrl, resourceKey: up.resourceKey };
}

export async function linkMediaToExercise(exerciseId: string, media: MediaItem): Promise<void> {
  const fileId = IDS.DRIVE_UEBUNGEN_JSON_FILE_ID as string;
  if (!fileId) throw new Error("DRIVE_UEBUNGEN_JSON_FILE_ID fehlt.");
  const list = (await downloadJson<ExercisesJson>(fileId)).data || [];

  const idx = list.findIndex(e => e.id === exerciseId);
  if (idx < 0) throw new Error("Übung nicht gefunden.");
  const ex = list[idx];
  const next = Array.isArray(ex.media) ? ex.media.filter(m => m.id !== media.id) : [];
  next.push(media);
  list[idx] = { ...ex, media: next };
  await overwriteJsonContent(fileId, list);
}

export async function unlinkMediaFromExercise(exerciseId: string, mediaId: string, alsoDeleteOnDrive = false): Promise<void> {
  const fileId = IDS.DRIVE_UEBUNGEN_JSON_FILE_ID as string;
  if (!fileId) throw new Error("DRIVE_UEBUNGEN_JSON_FILE_ID fehlt.");
  const list = (await downloadJson<ExercisesJson>(fileId)).data || [];
  const idx = list.findIndex(e => e.id === exerciseId);
  if (idx < 0) throw new Error("Übung nicht gefunden.");
  const ex = list[idx];
  const next = (ex.media || []).filter(m => m.id !== mediaId);
  list[idx] = { ...ex, media: next };
  await overwriteJsonContent(fileId, list);

  if (alsoDeleteOnDrive) {
    await fetch(`https://www.googleapis.com/drive/v3/files/${mediaId}?supportsAllDrives=true`, {
      method: "DELETE",
      headers: { Authorization: `Bearer ${await (await import('@/lib/drive/token')).getTokenFromProvider()}` as any } as any
    });
  }
}
