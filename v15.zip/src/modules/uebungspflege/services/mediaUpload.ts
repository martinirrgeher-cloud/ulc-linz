// src/modules/uebungspflege/services/mediaUpload.ts
import { getTokenFromProvider } from "@/lib/drive/token";

type UploadOpts = {
  folderId: string;
  makeAnyoneWithLink?: boolean;
};

export type UploadedMedia = {
  id: string;
  name: string;
  mimeType: string;
  resourceKey?: string;
  previewUrl: string;
  directUrl: string;
};

async function authHeader(): Promise<HeadersInit> {
  const at = await getTokenFromProvider();
  if (!at) throw new Error("Kein Google-Token verfügbar.");
  return { Authorization: `Bearer ${at}` };
}

export async function uploadToDrive(file: File, opts: UploadOpts): Promise<UploadedMedia> {
  const meta = { name: file.name, parents: [opts.folderId] };
  const boundary = "xxxxxxxxxx" + Math.random().toString(16).slice(2);
  const body = new Blob([
    `--${boundary}\r\nContent-Type: application/json; charset=UTF-8\r\n\r\n` + JSON.stringify(meta) + '\r\n' +
    `--${boundary}\r\nContent-Type: ${file.type || "application/octet-stream"}\r\n\r\n`,
    file,
    `\r\n--${boundary}--`,
  ], { type: `multipart/related; boundary=${boundary}` });

  const resp = await fetch("https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart&supportsAllDrives=true", {
    method: "POST",
    headers: { ...(await authHeader()) },
    body,
  });
  if (!resp.ok) throw new Error("Upload fehlgeschlagen: " + resp.status + " — " + await resp.text().catch(()=> ""));
  const j = await resp.json();
  const id: string = j.id;
  const resourceKey: string | undefined = j.resourceKey;

  if (opts.makeAnyoneWithLink) await setAnyoneWithLink(id);

  return {
    id,
    name: file.name,
    mimeType: file.type || "application/octet-stream",
    resourceKey,
    previewUrl: buildPreviewUrl(id, resourceKey),
    directUrl: buildDirectUrl(id, resourceKey),
  };
}

export async function setAnyoneWithLink(fileId: string): Promise<void> {
  const resp = await fetch(`https://www.googleapis.com/drive/v3/files/${fileId}/permissions?supportsAllDrives=true`, {
    method: "POST",
    headers: { "Content-Type": "application/json", ...(await authHeader()) },
    body: JSON.stringify({ role: "reader", type: "anyone", allowFileDiscovery: false }),
  });
  if (!resp.ok) throw new Error("Freigabe setzen fehlgeschlagen: " + resp.status + " — " + await resp.text().catch(()=> ""));
}

export function buildPreviewUrl(id: string, resourceKey?: string) {
  return `https://drive.google.com/file/d/${id}/preview${resourceKey ? `?resourcekey=${encodeURIComponent(resourceKey)}` : ""}`;
}
export function buildDirectUrl(id: string, resourceKey?: string) {
  return `https://www.googleapis.com/drive/v3/files/${id}?alt=media${resourceKey ? `&resourceKey=${encodeURIComponent(resourceKey)}` : ""}`;
}
