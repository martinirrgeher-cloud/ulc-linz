export interface Athlete {
  id: string;
  name: string;
  leistungsgruppe?: string;
  geburtsjahr?: number;
}