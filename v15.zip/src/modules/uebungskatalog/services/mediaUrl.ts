// services/mediaUrl.ts
import { resolveAccessTokenWithDiag, hasDriveScope } from "./authToken";

/** Extract Drive fileId and optional resourceKey from supported url forms. */
export function parseDriveRef(raw?: string): { id: string | null; resourceKey?: string | null } {
  if (!raw) return { id: null, resourceKey: null };
  try {
    const u = new URL(raw);
    const m1 = u.pathname.match(/\/file\/d\/([a-zA-Z0-9_-]+)/);
    const id = m1?.[1] || u.searchParams.get("id") || null;
    const resourceKey = u.searchParams.get("resourcekey") || u.searchParams.get("resourceKey") || null;
    return { id, resourceKey };
  } catch {
    if (/^[a-zA-Z0-9_-]{10,}$/.test(raw || "")) return { id: raw as string, resourceKey: null };
    return { id: null, resourceKey: null };
  }
}

export function toPreviewIframeUrl(raw?: string): string {
  const { id, resourceKey } = parseDriveRef(raw);
  if (!id) return "";
  const rk = resourceKey ? `?resourcekey=${encodeURIComponent(resourceKey)}` : "";
  return `https://drive.google.com/file/d/${id}/preview${rk}`;
}

export type MediaFetchResult =
  | { kind: "blob"; url: string }
  | { kind: "iframe"; url: string }
  | { kind: "error"; code: number; message: string; hint?: string; diag?: any };

async function tokenInfo(accessToken: string) {
  try {
    const r = await fetch(`https://www.googleapis.com/oauth2/v3/tokeninfo?access_token=${encodeURIComponent(accessToken)}`);
    const j = await r.json().catch(()=>null);
    return { ok: r.ok, status: r.status, data: j };
  } catch (e:any) {
    return { ok: false, status: 0, data: String(e?.message || e) };
  }
}

export async function buildMediaUrl(rawUrlOrId: string): Promise<MediaFetchResult> {
  const { id, resourceKey } = parseDriveRef(rawUrlOrId || "");
  if (!id) return { kind: "error", code: 0, message: "Keine Datei-ID erkannt." };
  const diag = await resolveAccessTokenWithDiag();
  const supports = "&supportsAllDrives=true";
  const rkParam = resourceKey ? `&resourceKey=${encodeURIComponent(resourceKey)}` : "";

  if (!diag.ok || !diag.accessToken) {
    // Kein Token → iFrame versuchen (nur wenn Browser-Session Zugriff hat)
    return { kind: "iframe", url: toPreviewIframeUrl(rawUrlOrId) };
  }
  const scopeOk = hasDriveScope(diag.scope || null);

  const url = `https://www.googleapis.com/drive/v3/files/${id}?alt=media${supports}${rkParam}`;
  try {
    const resp = await fetch(url, {
      method: "GET",
      headers: { Authorization: `Bearer ${diag.accessToken}` },
    });
    if (!resp.ok) {
      let hint = undefined;
      let extra: any = undefined;
      if (resp.status === 401) {
        const ti = await tokenInfo(diag.accessToken!);
        extra = { tokeninfo: ti, scope: diag.scope };
        if (!scopeOk) hint = "Drive-Scope fehlt. Login1 ausführen und Freigabe bestätigen.";
        else if (ti.ok === false) hint = "Token ungültig/abgelaufen. Login1 erneut ausführen.";
        else hint = "401 von Drive. Prüfe OAuth-Client/Projekt-Zuordnung.";
      }
      if (resp.status === 403) {
        hint = resourceKey
          ? "Kein Zugriff. Prüfe, ob der eingeloggte User auf die Datei berechtigt ist."
          : "Möglicherweise wird ein resourceKey benötigt. Link mit resourceKey verwenden oder Freigabe prüfen.";
      }
      return { kind: "error", code: resp.status, message: `Drive-Abruf fehlgeschlagen (${resp.status})`, hint, diag: extra };
    }
    const blob = await resp.blob();
    const objUrl = URL.createObjectURL(blob);
    return { kind: "blob", url: objUrl };
  } catch (e: any) {
    return { kind: "error", code: 0, message: String(e?.message || e) };
  }
}

// Backwards-compat shim for legacy imports
export async function buildDriveBlobObjectUrl(rawUrlOrId: string): Promise<string | null> {
  const r = await buildMediaUrl(rawUrlOrId);
  return r.kind === "blob" ? r.url : null;
}
