// services/categoriesStore.ts
import { downloadJson } from "@/lib/drive/DriveClientCore";
import { IDS } from "@/config/driveIds";
import type { KategorienJson } from "../types/exercise";

function getKategorienFileId(): string | undefined {
  const anyIDS = IDS as any;
  return anyIDS.UEBUNGEN_KATEGORIEN_FILE_ID || anyIDS.EXERCISES_KATEGORIEN_FILE_ID || import.meta.env.VITE_DRIVE_UEBUNGEN_KATEGORIEN_FILE_ID || undefined;
}

export async function loadKategorien(): Promise<KategorienJson | null> {
  const id = getKategorienFileId();
  if (!id) return null;
  try {
    const raw = await downloadJson<any>(id);
    const data = raw?.data ?? raw;
    if (data && typeof data.hauptgruppen === "object") return data as KategorienJson;
    return null;
  } catch (e) {
    console.warn("Kategorien laden fehlgeschlagen:", e);
    return null;
  }
}
