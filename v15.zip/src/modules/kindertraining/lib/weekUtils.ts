
export type WeekInfo = {
  weekId: string;
  dates: string[];
  labels: { short: string; long: string }[];
  rangeText: string;
  year: number;
  weekNumber: number;
};

function pad(n:number){ return n<10 ? "0"+n : ""+n; }

export function formatISO(d: Date){
  return d.getFullYear() + "-" + pad(d.getMonth()+1) + "-" + pad(d.getDate());
}

export function startOfISOWeek(date = new Date()){
  const d = new Date(Date.UTC(date.getFullYear(), date.getMonth(), date.getDate()));
  const day = (d.getUTCDay() + 6) % 7; // Mon=0..Sun=6
  d.setUTCDate(d.getUTCDate() - day);
  return d;
}

export function addDays(date: Date, days: number){
  const d = new Date(date);
  d.setUTCDate(d.getUTCDate() + days);
  return d;
}

export function getISOWeek(d: Date){
  const date = new Date(Date.UTC(d.getFullYear(), d.getMonth(), d.getDate()));
  date.setUTCDate(date.getUTCDate() + 3 - ((date.getUTCDay() + 6) % 7));
  const week1 = new Date(Date.UTC(date.getUTCFullYear(),0,4));
  return 1 + Math.round(((date.getTime() - week1.getTime()) / 86400000 - 3 + ((week1.getUTCDay() + 6) % 7)) / 7);
}

export function getWeekInfo(baseDate=new Date()): WeekInfo {
  const start = startOfISOWeek(baseDate);
  const dates: string[] = [];
  const labels: { short: string; long: string }[] = [];
  for(let i=0;i<7;i++){
    const d = addDays(start, i);
    const iso = formatISO(d);
    const dd = pad(d.getUTCDate());
    const mm = pad(d.getUTCMonth()+1);
    const yyyy = d.getUTCFullYear();
    const wd = ["Mo","Di","Mi","Do","Fr","Sa","So"][i];
    dates.push(iso);
    labels.push({ short: `${wd}`, long: `${wd} ${dd}.${mm}.${yyyy}` });
  }
  const end = addDays(start, 6);
  const rangeText = `${pad(start.getUTCDate())}.${pad(start.getUTCMonth()+1)}.${start.getUTCFullYear()} - ${pad(end.getUTCDate())}.${pad(end.getUTCMonth()+1)}.${end.getUTCFullYear()}`;
  const weekNumber = getISOWeek(start);
  const year = start.getUTCFullYear();
  const weekId = `${year}-KW${pad(weekNumber)}`;
  return { weekId, dates, labels, rangeText, year, weekNumber };
}

export function moveWeek(weekId: string, delta: number): string {
  const [yearStr, kwStr] = weekId.split("-KW");
  const year = parseInt(yearStr, 10);
  const week = parseInt(kwStr, 10);
  const jan4 = new Date(Date.UTC(year,0,4));
  const jan4Mon = startOfISOWeek(jan4);
  const base = addDays(jan4Mon, (week-1)*7);
  const target = addDays(base, delta*7);
  const info = getWeekInfo(target);
  return info.weekId;
}

export function datesForWeekId(weekId: string){
  const [yearStr, kwStr] = weekId.split("-KW");
  const year = parseInt(yearStr, 10);
  const week = parseInt(kwStr, 10);
  const jan4 = new Date(Date.UTC(year,0,4));
  const jan4Mon = startOfISOWeek(jan4);
  const base = addDays(jan4Mon, (week-1)*7);
  return getWeekInfo(base);
}
