# ULC Linz App v3 — Silent Refresh & Submenus

- Silent Token Refresh (no hard redirect; fallback zu /login1)
- Persistenter Login2 („Benutzer merken“)
- Modulstruktur mit Submenus (Kindertraining, Leistungsgruppe)

## Start
```bash
npm i
cp .env.example .env
npm run dev
```
