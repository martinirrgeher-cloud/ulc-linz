// src/routes.ts
export const ROUTES = {
  LOGIN: "/login",
  AUTH_CALLBACK: "/auth/callback",
  MAIN: "/",
};
