import { Navigate } from "react-router-dom";
import { hasAccessToken, isTokenValid } from "../lib/googleAuth";

interface ProtectedRouteProps {
  children: React.ReactNode;
}

export default function ProtectedRoute({ children }: ProtectedRouteProps) {
  const loggedIn = hasAccessToken() && isTokenValid();

  if (!loggedIn) {
    console.log("🚪 Kein/abgelaufener Token – redirect → Login");
    return <Navigate to="/login" replace />;
  }

  return <>{children}</>;
}
