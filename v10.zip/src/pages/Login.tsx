import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import {
  hasAccessToken,
  isTokenValid,
  signInWithGoogle,
  signInSilentWithGoogle,
  restoreAccessToken,
} from "../lib/googleAuth";

export default function Login() {
  const navigate = useNavigate();
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  useEffect(() => {
    const trySilentLogin = async () => {
      setError("");

      // 🔹 Bereits gespeicherten Token laden
      restoreAccessToken();

      // 🔸 Wenn ein gültiger Token da ist → direkt weiter
      if (hasAccessToken() && isTokenValid()) {
        console.log("✅ Gültiger Token vorhanden – weiterleiten");
        navigate("/");
        return;
      }

      // 🔸 Silent Login Versuch
      console.log("🔸 Versuche Silent Login…");
      const success = await signInSilentWithGoogle();

      if (success && isTokenValid()) {
        console.log("✅ Silent Login erfolgreich – weiterleiten");
        navigate("/");
      } else {
        console.log("❌ Silent Login fehlgeschlagen – Login Button anzeigen");
        setLoading(false);
      }
    };

    trySilentLogin();
    // ⚠ navigate nicht in Dependency → sonst Loop!
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const handleLogin = async () => {
    setError("");
    setLoading(true);
    try {
      await signInWithGoogle();
      if (isTokenValid()) {
        console.log("✅ Interaktiver Login erfolgreich");
        navigate("/");
      } else {
        setError("❌ Login fehlgeschlagen – bitte erneut versuchen.");
        setLoading(false);
      }
    } catch (err) {
      console.error("❌ Login Fehler:", err);
      setError("Fehler beim Google Login");
      setLoading(false);
    }
  };

  return (
    <div
      style={{
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        justifyContent: "center",
        height: "100vh",
        gap: "1rem",
      }}
    >
      <h1>🔐 Login</h1>
      {loading ? (
        <p>⏳ Login wird geprüft...</p>
      ) : (
        <button onClick={handleLogin}>Mit Google anmelden</button>
      )}
      {error && <p style={{ color: "red" }}>{error}</p>}
    </div>
  );
}
