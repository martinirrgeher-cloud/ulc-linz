// src/pages/MainMenu.tsx
import { Link, useNavigate } from "react-router-dom";
import { ROUTES } from "../routes";
import { forceLogout } from "../lib/googleAuth";
import logo from "../assets/logo.png";

// 📌 Modulübersicht – zentrale Definition aller Module
const MODULES = [
  { key: "KINDERTRAINING", label: "🏃 Kindertraining", route: ROUTES.KINDERTRAINING },
  { key: "U12", label: "👶 U12", route: ROUTES.U12 },
  { key: "U14", label: "🏃‍♂️ U14", route: ROUTES.U14 },
  { key: "LEISTUNGSGRUPPE", label: "🏋️ Leistungsgruppe", route: ROUTES.LEISTUNGSGRUPPE },
  { key: "STATISTIK", label: "📊 Statistik", route: ROUTES.STATISTIK },
  { key: "EINSTELLUNGEN", label: "⚙️ Einstellungen", route: ROUTES.EINSTELLUNGEN },
];

export default function MainMenu() {
  const navigate = useNavigate();

  // 🔸 Platzhalter — hier könntest du später echte Daten aus Google Drive / Backend laden
  const user = {
    username: "Google User",
    role: "trainer",
    modules: ["KINDERTRAINING", "U14", "STATISTIK"], // Berechtigungen
  };

  const handleLogout = () => {
    forceLogout();
    navigate(ROUTES.LOGIN);
  };

  const hasModule = (key: string) =>
    user.modules.some((m) => m.toLowerCase() === key.toLowerCase());

  return (
    <div
      className="container"
      style={{
        display: "flex",
        flexDirection: "column",
        gap: 12,
        maxWidth: 400,
        margin: "0 auto",
      }}
    >
      {/* 🖼 Logo + Überschrift */}
      <div style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 8 }}>
        <img src={logo} alt="Vereinslogo" style={{ height: 80, objectFit: "contain" }} />
        <h1 style={{ fontSize: "1.5rem", fontWeight: 600 }}>🏠 Modulübersicht</h1>
      </div>

      {/* 👤 Userinfo + Logout */}
      <div
        style={{
          display: "flex",
          justifyContent: "space-between",
          alignItems: "center",
          padding: "4px 0",
        }}
      >
        <span>
          👤 {user.username} ({user.role})
        </span>
        <button
          onClick={handleLogout}
          style={{
            background: "none",
            border: "none",
            color: "#444",
            cursor: "pointer",
            textDecoration: "underline",
            fontSize: "0.9rem",
          }}
        >
          Logout
        </button>
      </div>

      {/* 📚 Dynamische Modul-Links */}
      <nav style={{ display: "flex", flexDirection: "column", gap: 8 }}>
        {MODULES.filter((mod) => hasModule(mod.key)).map((mod) => (
          <Link key={mod.key} to={mod.route}>
            {mod.label}
          </Link>
        ))}

        {/* ⚙️ Adminbereich nur für Admins */}
        {user.role === "admin" && (
          <Link to={ROUTES.ADMIN}>🛠️ Adminbereich</Link>
        )}
      </nav>
    </div>
  );
}
