import { useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";
import { Home, Settings } from "lucide-react";
import { useUebungen } from "@/modules/uebungskatalog/hooks/useUebungen";
import { useUebungsGruppen } from "@/modules/uebungskatalog/hooks/useUebungsGruppen";
import { UploadField } from "../components/UploadField";
import "../styles/Uebungspflege.css";

export default function UebungHinzufuegen() {
  const navigate = useNavigate();
  const { uebungen, addUebung, uploadMedia, loading, saving } = useUebungen();
  const { gruppen, setGruppen } = useUebungsGruppen();

  const [name, setName] = useState("");
  const [hauptgruppe, setHauptgruppe] = useState("");
  const [untergruppe, setUntergruppe] = useState("");
  const [neueHauptgruppe, setNeueHauptgruppe] = useState("");
  const [neueUntergruppe, setNeueUntergruppe] = useState("");
  const [menge, setMenge] = useState<number>(0);
  const [einheit, setEinheit] = useState<string>("WH");
  const [mediaUrl, setMediaUrl] = useState("");
  const [mediaType, setMediaType] = useState<"image" | "video" | "">("");
  const [einstellungenOffen, setEinstellungenOffen] = useState(false);
  const [aktiv, setAktiv] = useState(true);

  const hauptgruppen = useMemo(() => {
    const all = new Set([...Object.keys(gruppen), ...uebungen.map(u => u.hauptgruppe)]);
    return Array.from(all);
  }, [gruppen, uebungen]);

  const untergruppen = useMemo(() => {
    const ausGruppe = gruppen[hauptgruppe] || [];
    const ausDaten = uebungen.filter(u => u.hauptgruppe === hauptgruppe).map(u => u.untergruppe);
    return Array.from(new Set([...ausGruppe, ...ausDaten]));
  }, [hauptgruppe, gruppen, uebungen]);

  const handleUpload = async (file: File) => {
    try {
      const result = await uploadMedia(file);
      setMediaUrl(result.url);
      setMediaType(result.type);
    } catch (err) {
      alert("Upload fehlgeschlagen. Bitte neu einloggen.");
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name || !hauptgruppe || !untergruppe || !mediaUrl) return;

    await addUebung({
      id: crypto.randomUUID(),
      name,
      hauptgruppe,
      untergruppe,
      menge,
      einheit: einheit as "WH" | "m" | "sec" | "kg",
      mediaUrl,
      mediaType: mediaType as "image" | "video",
      active: aktiv
    });

    setName("");
    setHauptgruppe("");
    setUntergruppe("");
    setMenge(0);
    setEinheit("WH");
    setMediaUrl("");
    setMediaType("");
    setAktiv(true);
    navigate("/uebungskatalog");
  };

  const addHauptgruppe = () => {
    if (!neueHauptgruppe) return;
    const updated = { ...gruppen, [neueHauptgruppe]: [] };
    setGruppen(updated);
    setNeueHauptgruppe("");
  };

  const addUntergruppe = () => {
    if (!neueHauptgruppe || !neueUntergruppe) return;
    const updated = {
      ...gruppen,
      [neueHauptgruppe]: [...(gruppen[neueHauptgruppe] || []), neueUntergruppe]
    };
    setGruppen(updated);
    setNeueUntergruppe("");
  };

  return (
    <div className="uebungspflege-container">
      {/* Header */}
      <header className="uebungspflege-header">
        <button className="icon-button" onClick={() => navigate("/dashboard")}>
          <Home size={22} />
        </button>
        <h1>Übung hinzufügen</h1>
        <button className="icon-button" onClick={() => setEinstellungenOffen(true)}>
          <Settings size={22} />
        </button>
      </header>

      {/* Formular */}
      <form className="uebungspflege-form" onSubmit={handleSubmit}>
        <label>
          Name
          <input type="text" value={name} onChange={(e) => setName(e.target.value)} required />
        </label>

        <label>
          Hauptgruppe
          <select value={hauptgruppe} onChange={(e) => setHauptgruppe(e.target.value)} required>
            <option value="">Bitte auswählen…</option>
            {hauptgruppen.map((g) => (
              <option key={g} value={g}>{g}</option>
            ))}
          </select>
        </label>

        <label>
          Untergruppe
          <select value={untergruppe} onChange={(e) => setUntergruppe(e.target.value)} required>
            <option value="">Bitte auswählen…</option>
            {untergruppen.map((g) => (
              <option key={g} value={g}>{g}</option>
            ))}
          </select>
        </label>

        <label>
          Menge
          <div className="menge-einheit">
            <input
              type="number"
              min="0"
              value={menge}
              onChange={(e) => setMenge(Number(e.target.value))}
            />
            <select value={einheit} onChange={(e) => setEinheit(e.target.value)}>
              <option value="WH">WH</option>
              <option value="m">m</option>
              <option value="sec">sec</option>
              <option value="kg">kg</option>
            </select>
          </div>
        </label>

        <UploadField onUpload={handleUpload} mediaUrl={mediaUrl} mediaType={mediaType} />

        <button type="submit" disabled={loading || saving}>
          {saving ? "Speichern..." : "Übung speichern"}
        </button>

        <button
          type="button"
          className="inactive-button"
          onClick={() => setAktiv(false)}
        >
          Inaktiv setzen
        </button>
      </form>

      {/* Einstellungsmenü */}
      {einstellungenOffen && (
        <div className="settings-overlay">
          <div className="settings-content">
            <h2>Gruppen verwalten</h2>

            <label>
              Neue Hauptgruppe
              <input
                type="text"
                value={neueHauptgruppe}
                onChange={(e) => setNeueHauptgruppe(e.target.value)}
              />
              <button type="button" onClick={addHauptgruppe}>Hinzufügen</button>
            </label>

            <label>
              Neue Untergruppe (für Hauptgruppe)
              <input
                type="text"
                value={neueUntergruppe}
                onChange={(e) => setNeueUntergruppe(e.target.value)}
              />
              <button type="button" onClick={addUntergruppe}>Hinzufügen</button>
            </label>

            <button onClick={() => setEinstellungenOffen(false)}>Schließen</button>
          </div>
        </div>
      )}
    </div>
  );
}
