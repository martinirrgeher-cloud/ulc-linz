import { useRef } from "react";

interface Props {
  onUpload: (file: File) => Promise<void>;
  mediaUrl: string;
  mediaType: string;
}

export function UploadField({ onUpload, mediaUrl, mediaType }: Props) {
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      await onUpload(file);
    }
  };

  return (
    <div className="upload-field">
      <label className="upload-label" onClick={() => fileInputRef.current?.click()}>
        {mediaUrl ? "Datei ändern" : "Datei auswählen"}
      </label>
      <input
        type="file"
        accept="image/*,video/*"
        style={{ display: "none" }}
        ref={fileInputRef}
        onChange={handleChange}
      />

      {mediaUrl && (
        <div className="upload-preview">
          {mediaType === "video" ? (
            <video controls src={mediaUrl} />
          ) : (
            <img src={mediaUrl} alt="Vorschau" />
          )}
        </div>
      )}
    </div>
  );
}
