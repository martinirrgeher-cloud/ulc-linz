import { Uebung } from "../hooks/useUebungen";

interface Props {
  uebung: Uebung;
}

export function UebungCard({ uebung }: Props) {
  const isVideo = uebung.mediaType === "video";

  return (
    <div className="uebung-card">
      <div className="uebung-media">
        {isVideo ? (
          <video controls src={uebung.mediaUrl} />
        ) : (
          <img src={uebung.mediaUrl} alt={uebung.name} />
        )}
      </div>
      <div className="uebung-info">
        <div className="uebung-name">{uebung.name}</div>
        <div className="uebung-wdh">{uebung.standardWdh} Wdh.</div>
      </div>
    </div>
  );
}
