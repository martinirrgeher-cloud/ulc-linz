// src/App.tsx
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import ProtectedRoute from "./components/ProtectedRoute";
import Login from "./pages/Login";
import MainMenu from "./pages/MainMenu";
import { handleCallback } from "./lib/googleAuth";
import { useEffect } from "react";

function AuthCallback() {
  useEffect(() => {
    handleCallback();
  }, []);

  return <p>🔄 Anmeldung wird verarbeitet...</p>;
}

export default function App() {
  return (
    <Router>
      <Routes>
        {/* Login ist öffentlich */}
        <Route path="/login" element={<Login />} />

        {/* Auth-Callback Seite wird nach Google Login einmalig aufgerufen */}
        <Route path="/auth/callback" element={<AuthCallback />} />

        {/* Hauptseite - geschützt */}
        <Route
          path="/"
          element={
            <ProtectedRoute>
              <MainMenu />
            </ProtectedRoute>
          }
        />

        {/* Fallback: alles andere -> Login */}
        <Route path="*" element={<Login />} />
      </Routes>
    </Router>
  );
}
