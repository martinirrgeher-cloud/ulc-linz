let accessToken: string | null = null;
let accessTokenExpiry: number | null = null;

const CLIENT_ID = import.meta.env.VITE_GOOGLE_CLIENT_ID;
const SCOPES = "https://www.googleapis.com/auth/drive.appdata";

// =============================
// 📌 Token speichern & prüfen
// =============================
export function saveAccessToken(token: string, expiresIn: number) {
  accessToken = token;
  accessTokenExpiry = Date.now() + expiresIn * 1000;
  localStorage.setItem("access_token", token);
  localStorage.setItem("access_token_expiry", accessTokenExpiry.toString());
  console.log(`🔐 Token gespeichert, gültig bis: ${new Date(accessTokenExpiry).toLocaleTimeString()}`);
}

export function restoreAccessToken() {
  const stored = localStorage.getItem("access_token");
  const storedExp = localStorage.getItem("access_token_expiry");
  if (stored && storedExp) {
    accessToken = stored;
    accessTokenExpiry = parseInt(storedExp, 10);
    console.log("🔐 Token wiederhergestellt");
  }
}

export function hasAccessToken(): boolean {
  return !!accessToken;
}

export function isTokenValid(): boolean {
  if (!accessToken || !accessTokenExpiry) return false;
  return Date.now() < accessTokenExpiry;
}

export function forceLogout() {
  console.log("🚪 Force Logout – Token wird gelöscht");
  accessToken = null;
  accessTokenExpiry = null;
  localStorage.removeItem("access_token");
  localStorage.removeItem("access_token_expiry");
}

// =============================
// 🔸 Silent Login
// =============================
export async function signInSilentWithGoogle(): Promise<boolean> {
  return new Promise((resolve) => {
    try {
      const tokenClient = google.accounts.oauth2.initTokenClient({
        client_id: CLIENT_ID,
        scope: SCOPES,
        prompt: "", // Silent Mode
        callback: (response) => {
          if (response && response.access_token) {
            saveAccessToken(response.access_token, response.expires_in);
            resolve(true);
          } else {
            console.log("❌ Silent Login fehlgeschlagen");
            resolve(false);
          }
        },
      });

      tokenClient.requestAccessToken();
    } catch (err) {
      console.log("⚠️ Silent Login Fehler:", err);
      resolve(false);
    }
  });
}

// =============================
// 🔸 Interaktiver Login
// =============================
export async function signInWithGoogle(): Promise<void> {
  return new Promise((resolve, reject) => {
    try {
      const tokenClient = google.accounts.oauth2.initTokenClient({
        client_id: CLIENT_ID,
        scope: SCOPES,
        prompt: "consent", // Popup aktiv
        callback: (response) => {
          if (response && response.access_token) {
            saveAccessToken(response.access_token, response.expires_in);
            resolve();
          } else {
            reject(new Error("❌ Kein Access Token erhalten"));
          }
        },
      });

      tokenClient.requestAccessToken();
    } catch (err) {
      reject(err);
    }
  });
}

// =============================
// 🔸 Callback-Handler (optional für Redirect Flows)
// =============================
export function handleCallback() {
  restoreAccessToken();
}
