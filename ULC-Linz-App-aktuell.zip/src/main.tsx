import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import { App } from "@/app/App";
import "@/styles/global.css";
import "@/styles/mobile.css";
import "@/styles/kindertraining.css";
import "@/styles/statistics.css";

const rootElement = document.getElementById("root");
if (!rootElement) throw new Error("Root-Element wurde nicht gefunden.");

createRoot(rootElement).render(
  <StrictMode>
    <App />
  </StrictMode>,
);
