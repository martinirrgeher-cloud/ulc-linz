import { useMemo, useState, type FormEvent } from "react";
import { Phone, Plus, Save, ShieldAlert, Trash2, X } from "lucide-react";
import type {
  Athlete,
  AthleteContact,
  AthleteInput,
  TrainingGroup,
} from "@/features/athletes/types";

export type AthleteEditorMode =
  | { type: "create" }
  | { type: "edit"; athlete: Athlete };

type AthleteEditorProps = {
  mode: AthleteEditorMode;
  groups: TrainingGroup[];
  busy: boolean;
  onCancel: () => void;
  onSubmit: (values: AthleteInput) => Promise<void>;
};

function emptyContact(): AthleteContact {
  return {
    id: null,
    contactName: "",
    relationship: "",
    phone: "",
    isEmergency: true,
    priority: 1,
    notes: "",
  };
}

function initialValues(mode: AthleteEditorMode): AthleteInput {
  if (mode.type === "create") {
    return {
      firstName: "",
      lastName: "",
      birthYear: null,
      notes: "",
      isActive: true,
      groupIds: [],
      contacts: [],
    };
  }

  return {
    firstName: mode.athlete.firstName,
    lastName: mode.athlete.lastName,
    birthYear: mode.athlete.birthYear,
    notes: mode.athlete.notes ?? "",
    isActive: mode.athlete.isActive,
    groupIds: mode.athlete.groups.map((group) => group.id),
    contacts: mode.athlete.contacts.map((contact) => ({ ...contact })),
  };
}

function parseBirthYear(value: string): number | null {
  if (!value.trim()) return null;
  const parsed = Number(value);
  return Number.isInteger(parsed) ? parsed : null;
}

export function AthleteEditor({
  mode,
  groups,
  busy,
  onCancel,
  onSubmit,
}: AthleteEditorProps) {
  const [values, setValues] = useState<AthleteInput>(() => initialValues(mode));
  const [error, setError] = useState<string | null>(null);
  const currentYear = new Date().getFullYear();

  const selectableGroups = useMemo(
    () => groups.filter((group) => group.isActive || values.groupIds.includes(group.id)),
    [groups, values.groupIds],
  );

  const contactsValid = values.contacts.every(
    (contact) => contact.contactName.trim().length > 0 && contact.phone.trim().length >= 3,
  );

  const canSave =
    values.firstName.trim().length > 0 &&
    values.lastName.trim().length > 0 &&
    contactsValid &&
    (values.birthYear === null ||
      (values.birthYear >= 1900 && values.birthYear <= currentYear));

  async function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (!canSave || busy) return;

    setError(null);
    try {
      await onSubmit(values);
    } catch (submitError) {
      setError(
        submitError instanceof Error
          ? submitError.message
          : "Der Athlet konnte nicht gespeichert werden.",
      );
    }
  }

  function toggleGroup(groupId: string, checked: boolean) {
    setValues((current) => ({
      ...current,
      groupIds: checked
        ? [...new Set([...current.groupIds, groupId])]
        : current.groupIds.filter((id) => id !== groupId),
    }));
  }

  function addContact() {
    setValues((current) => ({
      ...current,
      contacts: [...current.contacts, { ...emptyContact(), priority: current.contacts.length + 1 }],
    }));
  }

  function updateContact(index: number, changes: Partial<AthleteContact>) {
    setValues((current) => ({
      ...current,
      contacts: current.contacts.map((contact, contactIndex) =>
        contactIndex === index ? { ...contact, ...changes } : contact,
      ),
    }));
  }

  function removeContact(index: number) {
    setValues((current) => ({
      ...current,
      contacts: current.contacts
        .filter((_, contactIndex) => contactIndex !== index)
        .map((contact, contactIndex) => ({ ...contact, priority: contactIndex + 1 })),
    }));
  }

  return (
    <section className="management-editor athlete-editor" aria-labelledby="athlete-editor-title">
      <div className="management-editor-heading">
        <div>
          <p className="eyebrow">Athletenstammdaten</p>
          <h2 id="athlete-editor-title">
            {mode.type === "create" ? "Athlet anlegen" : "Athlet bearbeiten"}
          </h2>
          <p>Stammdaten, Gruppen und Notfallkontakte zentral verwalten.</p>
        </div>
        <button
          type="button"
          className="icon-button"
          onClick={onCancel}
          disabled={busy}
          aria-label="Bearbeitung schließen"
        >
          <X aria-hidden="true" />
        </button>
      </div>

      {error && <div className="alert error">{error}</div>}

      <form className="management-form" onSubmit={handleSubmit}>
        <div className="form-grid">
          <label>
            Vorname
            <input
              type="text"
              value={values.firstName}
              onChange={(event) =>
                setValues((current) => ({ ...current, firstName: event.target.value }))
              }
              maxLength={80}
              autoComplete="off"
              required
            />
          </label>

          <label>
            Nachname
            <input
              type="text"
              value={values.lastName}
              onChange={(event) =>
                setValues((current) => ({ ...current, lastName: event.target.value }))
              }
              maxLength={80}
              autoComplete="off"
              required
            />
          </label>

          <label>
            Geburtsjahr
            <input
              type="number"
              min={1900}
              max={currentYear}
              inputMode="numeric"
              value={values.birthYear ?? ""}
              onChange={(event) =>
                setValues((current) => ({
                  ...current,
                  birthYear: parseBirthYear(event.target.value),
                }))
              }
              placeholder="z. B. 2014"
            />
            <small>Das Geburtsjahr genügt für Altersklassen.</small>
          </label>

          {mode.type === "edit" && (
            <label>
              Status
              <select
                value={values.isActive ? "active" : "inactive"}
                onChange={(event) =>
                  setValues((current) => ({
                    ...current,
                    isActive: event.target.value === "active",
                  }))
                }
              >
                <option value="active">Aktiv</option>
                <option value="inactive">Inaktiv</option>
              </select>
              <small>Inaktive Athleten bleiben für Auswertungen erhalten.</small>
            </label>
          )}
        </div>

        <label className="full-width-field">
          Interne Notiz
          <textarea
            value={values.notes}
            onChange={(event) =>
              setValues((current) => ({ ...current, notes: event.target.value }))
            }
            maxLength={3000}
            rows={3}
            placeholder="Optional, nur für berechtigte Vereinsmitglieder"
          />
          <small>{values.notes.length} / 3000 Zeichen</small>
        </label>

        <fieldset className="contact-selection">
          <div className="fieldset-heading">
            <div>
              <legend>Kontakte und Notfallkontakte</legend>
              <p className="field-hint">
                Telefonnummern sind im Kindertraining direkt beim Kind abrufbar.
              </p>
            </div>
            <button
              type="button"
              className="secondary-button compact-button"
              onClick={addContact}
              disabled={values.contacts.length >= 10}
            >
              <Plus aria-hidden="true" /> Kontakt
            </button>
          </div>

          {values.contacts.length === 0 ? (
            <div className="inline-empty-state compact-empty-state">
              <Phone aria-hidden="true" /> Noch kein Kontakt hinterlegt.
            </div>
          ) : (
            <div className="contact-editor-list">
              {values.contacts.map((contact, index) => (
                <article className="contact-editor-card" key={contact.id ?? `new-${index}`}>
                  <div className="contact-editor-card-heading">
                    <strong>Kontakt {index + 1}</strong>
                    <button
                      type="button"
                      className="icon-button danger-icon-button"
                      onClick={() => removeContact(index)}
                      aria-label={`Kontakt ${index + 1} entfernen`}
                    >
                      <Trash2 aria-hidden="true" />
                    </button>
                  </div>
                  <div className="form-grid contact-grid">
                    <label>
                      Name
                      <input
                        type="text"
                        value={contact.contactName}
                        onChange={(event) => updateContact(index, { contactName: event.target.value })}
                        maxLength={120}
                        placeholder="z. B. Maria Mustermann"
                        required
                      />
                    </label>
                    <label>
                      Beziehung
                      <input
                        type="text"
                        value={contact.relationship}
                        onChange={(event) => updateContact(index, { relationship: event.target.value })}
                        maxLength={80}
                        placeholder="z. B. Mutter"
                      />
                    </label>
                    <label>
                      Telefonnummer
                      <input
                        type="tel"
                        value={contact.phone}
                        onChange={(event) => updateContact(index, { phone: event.target.value })}
                        maxLength={40}
                        autoComplete="tel"
                        placeholder="+43 …"
                        required
                      />
                    </label>
                    <label className="contact-emergency-toggle">
                      <input
                        type="checkbox"
                        checked={contact.isEmergency}
                        onChange={(event) => updateContact(index, { isEmergency: event.target.checked })}
                      />
                      <span>
                        <ShieldAlert aria-hidden="true" />
                        <strong>Notfallkontakt</strong>
                      </span>
                    </label>
                  </div>
                  <label className="full-width-field">
                    Kurze Notiz
                    <input
                      type="text"
                      value={contact.notes}
                      onChange={(event) => updateContact(index, { notes: event.target.value })}
                      maxLength={500}
                      placeholder="Optional"
                    />
                  </label>
                </article>
              ))}
            </div>
          )}
        </fieldset>

        <fieldset className="group-selection">
          <legend>Aktuelle Trainingsgruppen</legend>
          <p className="field-hint">
            Ein Athlet kann mehreren Gruppen gleichzeitig zugeordnet sein. Änderungen werden
            historisch nachvollziehbar gespeichert.
          </p>

          {selectableGroups.length === 0 ? (
            <div className="inline-empty-state">
              Noch keine aktive Trainingsgruppe vorhanden. Lege zuerst eine Gruppe an.
            </div>
          ) : (
            <div className="group-checkbox-grid">
              {selectableGroups.map((group) => (
                <label className="group-checkbox" key={group.id}>
                  <input
                    type="checkbox"
                    checked={values.groupIds.includes(group.id)}
                    onChange={(event) => toggleGroup(group.id, event.target.checked)}
                  />
                  <span>
                    <strong>{group.name}</strong>
                    <small>
                      {[group.shortName, group.isActive ? null : "Inaktiv"]
                        .filter(Boolean)
                        .join(" · ")}
                    </small>
                  </span>
                </label>
              ))}
            </div>
          )}
        </fieldset>

        <div className="management-actions">
          <button type="button" className="secondary-button" onClick={onCancel} disabled={busy}>
            Abbrechen
          </button>
          <button type="submit" className="primary-button" disabled={!canSave || busy}>
            <Save aria-hidden="true" />
            {busy ? "Speichert …" : "Speichern"}
          </button>
        </div>
      </form>
    </section>
  );
}
