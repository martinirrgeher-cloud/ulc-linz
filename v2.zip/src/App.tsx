import { useEffect, useState } from "react";
import { BrowserRouter as Router, Routes, Route, Navigate } from "react-router-dom";
import {
  hasAccessToken,
  restoreAccessToken,
  verifyAccessToken,
} from "./lib/googleAuth";

import Dashboard from "./pages/Dashboard";
import Login from "./pages/Login";
import Kindertraining from "./modules/Kindertraining/Kindertraining";

export default function App() {
  const [isLoading, setIsLoading] = useState(true);
  const [isAuthenticated, setIsAuthenticated] = useState(false);

  useEffect(() => {
    const init = async () => {
      try {
        if (hasAccessToken()) {
          restoreAccessToken();
          const valid = await verifyAccessToken();
          if (valid) {
            console.log("✅ Token gültig – Benutzer bleibt eingeloggt");
            setIsAuthenticated(true);
          } else {
            console.warn("⚠️ Token ungültig – bitte neu anmelden");
            setIsAuthenticated(false);
          }
        } else {
          console.log("ℹ️ Kein Token vorhanden – Login erforderlich");
          setIsAuthenticated(false);
        }
      } catch (err) {
        console.error("❌ Fehler bei Token-Restore:", err);
        setIsAuthenticated(false);
      } finally {
        setIsLoading(false);
      }
    };

    init();
  }, []);

  if (isLoading) {
    return (
      <div className="flex justify-center items-center h-screen text-gray-700">
        ⏳ Verbindung mit Google Drive wird hergestellt …
      </div>
    );
  }

  if (!isAuthenticated) {
    return <Login />;
  }

  return (
    <Router>
      <Routes>
        <Route path="/" element={<Dashboard />} />
        <Route path="/kindertraining" element={<Kindertraining />} />
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </Router>
  );
}
