import React from 'react';
import ReactDOM from 'react-dom/client';
import App from './App';
import './index.css';  // ⬅️ Tailwind wird hier aktiviert

// Root-Element im DOM finden
const rootElement = document.getElementById('root');

// React-Root erstellen und App einbinden
ReactDOM.createRoot(rootElement).render(
  <React.StrictMode>
    <App />
  </React.StrictMode>
);
