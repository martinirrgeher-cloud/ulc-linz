import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
// src/App.tsx
import { useState } from "react";
import Login from "./modules/auth/Login";
import Kindertraining from "./modules/kindertraining/Kindertraining";
import { APP_TITLE } from "./config";
console.log("✅ App.tsx wird geladen!");
export default function App() {
    const [user, setUser] = useState(JSON.parse(localStorage.getItem("loggedInUser") || "null"));
    const [activeModule, setActiveModule] = useState(null);
    // Wenn kein Benutzer eingeloggt → Login-Seite anzeigen
    if (!user)
        return _jsx(Login, { onLogin: setUser });
    // Wenn ein Modul aktiv ist → direkt dieses Modul anzeigen
    if (activeModule === "Kindertraining") {
        return (_jsxs("div", { style: { padding: 20 }, children: [_jsxs("div", { style: { textAlign: "right", marginBottom: 10 }, children: ["Eingeloggt als ", _jsx("b", { children: user.username }), " (", user.role, ")", " ", _jsx("button", { onClick: () => {
                                localStorage.removeItem("loggedInUser");
                                setUser(null);
                            }, children: "Abmelden" })] }), _jsx("button", { style: {
                        marginBottom: 15,
                        background: "#eef2ff",
                        border: "none",
                        padding: "6px 12px",
                        borderRadius: 6,
                        cursor: "pointer"
                    }, onClick: () => setActiveModule(null), children: "\u2B05\uFE0F Zur\u00FCck zur \u00DCbersicht" }), _jsx(Kindertraining, {})] }));
    }
    // Standard: Modulübersicht anzeigen
    return (_jsxs("div", { style: { padding: 20 }, children: [_jsxs("div", { style: { textAlign: "right" }, children: ["Eingeloggt als ", _jsx("b", { children: user.username }), " (", user.role, ")", " ", _jsx("button", { onClick: () => {
                            localStorage.removeItem("loggedInUser");
                            setUser(null);
                        }, children: "Abmelden" })] }), _jsx("h1", { children: APP_TITLE }), _jsx("h2", { children: "Verf\u00FCgbare Module" }), _jsx("div", { style: { display: "flex", flexWrap: "wrap", gap: 12 }, children: user.modules.map((m) => (_jsxs("div", { style: {
                        border: "1px solid #ddd",
                        borderRadius: 8,
                        padding: 12,
                        cursor: "pointer",
                        width: 220,
                        background: "#f9fafb",
                        transition: "0.2s",
                    }, onClick: () => {
                        if (m === "Kindertraining")
                            setActiveModule("Kindertraining");
                        else
                            alert(`Modul "${m}" ist noch in Entwicklung.`);
                    }, children: [_jsx("strong", { children: m }), _jsx("p", { style: { fontSize: 13, color: "#555" }, children: m === "Kindertraining"
                                ? "Anwesenheitsverwaltung & Statistik"
                                : "in Vorbereitung" })] }, m))) })] }));
}
