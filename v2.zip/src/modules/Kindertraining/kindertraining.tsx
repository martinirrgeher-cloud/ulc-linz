import { useEffect, useMemo, useRef, useState } from "react";
import { loadTrainingState, saveTrainingState } from "../../lib/training/kindertrainingData";
import { FiChevronLeft, FiChevronRight, FiFileText, FiEdit2 } from "react-icons/fi";
import { Chart } from "chart.js/auto";

interface Person {
  firstName: string;
  lastName: string;
  active: boolean;
}

interface NoteEdit {
  date: string;
  value: string;
}

function useDebouncedCallback(fn: (...args: any[]) => void, delay = 500) {
  const t = useRef<number | null>(null);
  return (...args: any[]) => {
    if (t.current) clearTimeout(t.current);
    t.current = window.setTimeout(() => fn(...args), delay);
  };
}

// ---------- Kalender-Utils ----------
function getISOWeek(date: Date) {
  const tmp = new Date(date.getTime());
  tmp.setHours(0, 0, 0, 0);
  tmp.setDate(tmp.getDate() + 3 - ((tmp.getDay() + 6) % 7));
  const week1 = new Date(tmp.getFullYear(), 0, 4);
  return 1 + Math.round(((tmp.getTime() - week1.getTime()) / 86400000 - 3 + ((week1.getDay() + 6) % 7)) / 7);
}

function getMonthKey(date: Date) {
  return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}`;
}

function getSessionsForMonth(firstOfMonth: Date, weekdays: number[]) {
  const d0 = new Date(firstOfMonth.getFullYear(), firstOfMonth.getMonth(), 1);
  const d1 = new Date(firstOfMonth.getFullYear(), firstOfMonth.getMonth() + 1, 0);
  const result: Date[] = [];
  for (const weekday of weekdays) {
    const shift = (weekday - d0.getDay() + 7) % 7;
    const first = new Date(d0.getFullYear(), d0.getMonth(), d0.getDate() + shift);
    for (let d = new Date(first); d <= d1; d = new Date(d.getFullYear(), d.getMonth(), d.getDate() + 7)) {
      result.push(new Date(d));
    }
  }
  return result.sort((a, b) => a.getTime() - b.getTime());
}

function fmtISO(date: Date) {
  return date.toISOString().slice(0, 10);
}

// ============ Hauptkomponente ============
export default function Kindertraining() {
  const [state, setState] = useState<{ people: Person[]; records: any; notes: any }>({
    people: [],
    records: {},
    notes: {},
  });

  const [sortMode, setSortMode] = useState<"first" | "last">("first");
  const [search, setSearch] = useState("");
  const [newName, setNewName] = useState("");
  const [monthStart, setMonthStart] = useState(() => new Date(new Date().getFullYear(), new Date().getMonth(), 1));
  const [noteEdit, setNoteEdit] = useState<NoteEdit | null>(null);
  const [columnState, setColumnState] = useState<Record<string, boolean>>({});
  const [editIndex, setEditIndex] = useState<number | null>(null);

  // Monatsbasierte Wochentage (Mo-Start)
  const [weekdaysByMonth, setWeekdaysByMonth] = useState<Record<string, number[]>>({
    [getMonthKey(new Date())]: [2], // Standard: Dienstag
  });
  const weekdayLabels = ["Mo", "Di", "Mi", "Do", "Fr", "Sa", "So"];
  const weekdayMap = [1, 2, 3, 4, 5, 6, 0]; // Mapping auf JS getDay()

  const currentMonthKey = getMonthKey(monthStart);
  const selectedWeekdays = weekdaysByMonth[currentMonthKey] || [2];
  const updateWeekdaysForMonth = (newDays: number[]) => {
    setWeekdaysByMonth((prev) => ({ ...prev, [currentMonthKey]: newDays }));
  };

  // Ansicht: Monat/Woche
  const [viewMode, setViewMode] = useState<"month" | "week">("month");
  const [selectedWeek, setSelectedWeek] = useState<number>(getISOWeek(new Date()));

  // Statistik
  const [showStats, setShowStats] = useState(false);
  const [statsTab, setStatsTab] = useState<"person" | "day">("person");
  const now = new Date();
  const [statsStartMonth, setStatsStartMonth] = useState<string>(
    () => localStorage.getItem("statsStart") || `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, "0")}`
  );
  const [statsEndMonth, setStatsEndMonth] = useState<string>(
    () => localStorage.getItem("statsEnd") || `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, "0")}`
  );

  const allSessions = useMemo(() => getSessionsForMonth(monthStart, selectedWeekdays), [monthStart, selectedWeekdays]);
  const sessions = useMemo(() => {
    if (viewMode === "week") return allSessions.filter((d) => getISOWeek(d) === selectedWeek);
    return allSessions;
  }, [allSessions, viewMode, selectedWeek]);

  const debouncedSave = useDebouncedCallback(async (next) => {
    try {
      await saveTrainingState(next);
    } catch (e) {
      console.error(e);
    }
  }, 600);

  // Daten laden + Migration
  useEffect(() => {
    (async () => {
      const loaded = await loadTrainingState();
      let people = loaded?.people || [];
      people = people.map((p: any) => {
        if (p.firstName !== undefined && p.lastName !== undefined) return p;
        const parts = (p.name || "").trim().split(" ");
        return { firstName: parts[0] || "", lastName: parts.slice(1).join(" ") || "", active: p.active ?? true };
      });
      setState({ people, records: loaded?.records || {}, notes: loaded?.notes || {} });
    })();
  }, []);

  const setAndSave = (producer: (prev: any) => any) => {
    setState((prev) => {
      const next = producer(prev);
      debouncedSave(next);
      return next;
    });
  };

  // Personen
  const addPerson = () => {
    const name = newName.trim();
    if (!name) return;
    const parts = name.split(" ");
    const firstName = parts[0];
    const lastName = parts.slice(1).join(" ");
    setNewName("");
    setAndSave((prev) => ({ ...prev, people: [...prev.people, { firstName, lastName, active: true }] }));
  };

  const renamePerson = (index: number, value: string) => {
    const parts = value.trim().split(" ");
    const firstName = parts[0] || "";
    const lastName = parts.slice(1).join(" ");
    setAndSave((prev) => ({
      ...prev,
      people: prev.people.map((p, i) => (i === index ? { ...p, firstName, lastName } : p)),
    }));
    setEditIndex(null);
  };

  const togglePersonActive = (person: Person) => {
    setAndSave((prev) => ({
      ...prev,
      people: prev.people.map((p) => (p === person ? { ...p, active: !p.active } : p)),
    }));
  };

  const toggleAttendance = (dateISO: string, person: Person) => {
    const fullName = `${person.firstName} ${person.lastName}`.trim();
    setAndSave((prev) => {
      const records = { ...prev.records };
      const dayRecords = { ...(records[dateISO] || {}) };
      dayRecords[fullName] = !dayRecords[fullName];
      records[dateISO] = dayRecords;
      return { ...prev, records };
    });
  };

  const toggleColumnActive = (dateISO: string) => {
    setColumnState((prev) => ({ ...prev, [dateISO]: !prev[dateISO] }));
  };

  // Sortierung
  const sortedPeople = useMemo(() => {
    const safe = (v?: string) => (v || "").toLowerCase();
    const active = state.people.filter((p) => p.active);
    const inactive = state.people.filter((p) => !p.active);
    const sorter = (a: Person, b: Person) => {
      const fa = safe(a.firstName), fb = safe(b.firstName);
      const la = safe(a.lastName), lb = safe(b.lastName);
      if (sortMode === "first") {
        const prim = fa.localeCompare(fb);
        return prim !== 0 ? prim : la.localeCompare(lb);
      } else {
        const prim = la.localeCompare(lb);
        return prim !== 0 ? prim : fa.localeCompare(fb);
      }
    };
    return [...active.sort(sorter), ...inactive.sort(sorter)];
  }, [state.people, sortMode]);

  const visiblePeople = useMemo(() => {
    const q = search.trim().toLowerCase();
    return q
      ? sortedPeople.filter((p) => (p.firstName || "").toLowerCase().includes(q) || (p.lastName || "").toLowerCase().includes(q))
      : sortedPeople;
  }, [sortedPeople, search]);

  // Statistik
  useEffect(() => {
    localStorage.setItem("statsStart", statsStartMonth);
    localStorage.setItem("statsEnd", statsEndMonth);
  }, [statsStartMonth, statsEndMonth]);

  const startDate = new Date(statsStartMonth + "-01");
  const endDate = new Date(statsEndMonth + "-01");
  endDate.setMonth(endDate.getMonth() + 1);
  endDate.setDate(0);

  const filteredRecords = Object.entries(state.records).filter(([date]) => {
    const d = new Date(date);
    return d >= startDate && d <= endDate;
  });

  const monthsInRange: string[] = [];
  const temp = new Date(startDate);
  while (temp <= endDate) {
    monthsInRange.push(`${temp.getFullYear()}-${String(temp.getMonth() + 1).padStart(2, "0")}`);
    temp.setMonth(temp.getMonth() + 1);
  }

  const statsPerPerson: Record<string, Record<string, number>> = {};
  state.people.forEach((p) => (statsPerPerson[`${p.firstName} ${p.lastName}`.trim()] = {}));
  filteredRecords.forEach(([date, day]: any) => {
    const mKey = date.slice(0, 7);
    Object.entries(day).forEach(([name, checked]) => {
      if (checked) {
        statsPerPerson[name][mKey] = (statsPerPerson[name][mKey] || 0) + 1;
      }
    });
  });

  const totalsPerPerson: Record<string, number> = {};
  Object.entries(statsPerPerson).forEach(([name, months]) => {
    totalsPerPerson[name] = Object.values(months).reduce((a: number, b: number) => a + b, 0);
  });
  const maxTotal = Math.max(...Object.values(totalsPerPerson), 0);

  const statsPerDay: Record<string, number> = {};
  filteredRecords.forEach(([date, day]: any) => {
    statsPerDay[date] = Object.values(day).filter(Boolean).length;
  });

  const chartRef = useRef<HTMLCanvasElement | null>(null);
  const chartInstance = useRef<Chart | null>(null);
  useEffect(() => {
    if (showStats && statsTab === "day" && chartRef.current) {
      if (chartInstance.current) chartInstance.current.destroy();
      const labels = Object.keys(statsPerDay).sort();
      const values = labels.map((l) => statsPerDay[l]);
      chartInstance.current = new Chart(chartRef.current, {
        type: "bar",
        data: { labels, datasets: [{ label: "Teilnehmer pro Training", data: values, backgroundColor: "#0b5cff" }] },
        options: { responsive: true, plugins: { legend: { display: false } } },
      });
    }
  }, [statsTab, statsPerDay, showStats]);

  // ----------- Render -----------
  return (
    <div className="container">
      {/* Kopfzeile */}
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 12 }}>
        <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
          <button className="ghost" onClick={() => setMonthStart((m) => new Date(m.getFullYear(), m.getMonth() - 1, 1))}>
            <FiChevronLeft />
          </button>
          <h1 style={{ fontSize: "1.6rem", fontWeight: "bold" }}>
            Kindertraining – {monthStart.toLocaleDateString(undefined, { year: "numeric", month: "long" })}
          </h1>
          <button className="ghost" onClick={() => setMonthStart((m) => new Date(m.getFullYear(), m.getMonth() + 1, 1))}>
            <FiChevronRight />
          </button>
        </div>
        <button className="ghost" onClick={() => setShowStats(true)}>📊 Statistik</button>
      </div>

      {/* Kalenderkonfiguration */}
      <div className="card" style={{ marginBottom: "1rem" }}>
        <div style={{ display: "flex", flexWrap: "wrap", gap: "1rem" }}>
          <div>
            <label><strong>Wochentage:</strong></label>
            <div style={{ display: "flex", gap: 6, flexWrap: "wrap" }}>
              {weekdayLabels.map((label, i) => {
                const weekday = weekdayMap[i];
                const checked = selectedWeekdays.includes(weekday);
                return (
                  <label key={weekday} style={{ display: "inline-flex", alignItems: "center", gap: 4 }}>
                    <input
                      type="checkbox"
                      checked={checked}
                      onChange={() => {
                        const newDays = checked
                          ? selectedWeekdays.filter((d) => d !== weekday)
                          : [...selectedWeekdays, weekday];
                        updateWeekdaysForMonth(newDays);
                      }}
                    />
                    {label}
                  </label>
                );
              })}
            </div>
          </div>

          <div>
            <label><strong>Ansicht:</strong></label>
            <div>
              <label style={{ marginRight: 8 }}>
                <input
                  type="radio"
                  name="viewMode"
                  value="month"
                  checked={viewMode === "month"}
                  onChange={() => setViewMode("month")}
                />{" "}
                Monat
              </label>
              <label>
                <input
                  type="radio"
                  name="viewMode"
                  value="week"
                  checked={viewMode === "week"}
                  onChange={() => setViewMode("week")}
                />{" "}
                Woche
              </label>
            </div>
          </div>

          {viewMode === "week" && (
            <div>
              <label><strong>Kalenderwoche:</strong></label>
              <select value={selectedWeek} onChange={(e) => setSelectedWeek(parseInt(e.target.value))}>
                {Array.from(new Set(allSessions.map((d) => getISOWeek(d)))).map((kw) => (
                  <option key={kw} value={kw}>{`KW ${kw}`}</option>
                ))}
              </select>
            </div>
          )}
        </div>
      </div>

      {/* Sortierung / Suche / Hinzufügen */}
      <div className="card controls-column">
        <div style={{ display: "flex", gap: 8, flexWrap: "wrap", alignItems: "center" }}>
          <button className={`ghost ${sortMode === "first" ? "note-active" : ""}`} onClick={() => setSortMode("first")}>
            Sortiere nach Vorname
          </button>
          <button className={`ghost ${sortMode === "last" ? "note-active" : ""}`} onClick={() => setSortMode("last")}>
            Sortiere nach Nachname
          </button>
        </div>

        <div className="input-inline" style={{ marginTop: 8 }}>
          <input
            type="text"
            placeholder="Vor- und Nachname eingeben"
            value={newName}
            onChange={(e) => setNewName(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && addPerson()}
          />
          <button onClick={addPerson}>Hinzufügen</button>
        </div>

        <input
          type="text"
          placeholder="Name suchen…"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          style={{ marginTop: 8 }}
        />
      </div>

      {/* Tabelle */}
      <div className="table-wrap card" style={{ overflowX: "auto" }}>
        <table>
          <thead>
            <tr>
              <th className="sticky-col">Name</th>
              {sessions.map((d) => {
                const iso = fmtISO(d);
                const colActive = columnState[iso] !== false;
                const noteVal = state.notes?.[iso] || "";
                return (
                  <th key={iso} className={!colActive ? "inactive-col" : ""}>
                    <div className="header-controls">
                      <input type="checkbox" checked={colActive} onChange={() => toggleColumnActive(iso)} />
                      <div>
                        <div>{d.getDate()}</div>
                        <div className="small">{d.toLocaleDateString(undefined, { weekday: "short" })}</div>
                      </div>
                      <button
                        className={`icon-btn ${noteVal ? "note-active" : ""}`}
                        title={noteVal ? noteVal : "Notiz hinzufügen"}
                        onClick={() => setNoteEdit({ date: iso, value: noteVal })}
                      >
                        <FiFileText />
                      </button>
                    </div>
                  </th>
                );
              })}
            </tr>
          </thead>
          <tbody>
            {visiblePeople.map((p, index) => (
              <tr key={`${p.firstName}-${p.lastName}-${index}`} className={p.active ? "" : "inactive-row"}>
                <td className="sticky-col">
                  {editIndex === index ? (
                    <div className="input-inline">
                      <input
                        autoFocus
                        defaultValue={`${p.firstName} ${p.lastName}`}
                        onKeyDown={(e) => {
                          if (e.key === "Enter") renamePerson(index, (e.target as HTMLInputElement).value);
                          if (e.key === "Escape") setEditIndex(null);
                        }}
                      />
                      <button onClick={() => setEditIndex(null)}>✖</button>
                    </div>
                  ) : (
                    <div className="name-cell">
                      <div className="name-row">
                        <strong>{p.firstName}</strong>
                        <button className="icon-btn edit-btn" onClick={() => setEditIndex(index)} title="Bearbeiten">
                          <FiEdit2 />
                        </button>
                      </div>
                      <div className="name-row">
                        <span>{p.lastName}</span>
                        <button
                          className="icon-btn status-btn"
                          onClick={() => togglePersonActive(p)}
                          title={p.active ? "aktiv" : "inaktiv"}
                        >
                          {p.active ? "🟢" : "🟡"}
                        </button>
                      </div>
                    </div>
                  )}
                </td>

                {sessions.map((d) => {
                  const iso = fmtISO(d);
                  const fullName = `${p.firstName} ${p.lastName}`.trim();
                  const checked = !!state.records?.[iso]?.[fullName];
                  const colActive = columnState[iso] !== false;
                  return (
                    <td key={iso} className={!colActive ? "inactive-col" : ""}>
                      {colActive && (
                        <input
                          type="checkbox"
                          checked={checked}
                          onChange={() => toggleAttendance(iso, p)}
                          title={`${fullName} – ${iso}`}
                        />
                      )}
                    </td>
                  );
                })}
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Statistik-Modal */}
      {showStats && (
        <div className="modal-backdrop">
          <div className="modal" style={{ maxWidth: 1000 }}>
            <h3>📊 Statistik</h3>

            <div style={{ display: "flex", gap: 12, marginBottom: 12 }}>
              <div>
                <label>Von Monat</label>
                <input type="month" value={statsStartMonth} onChange={(e) => setStatsStartMonth(e.target.value)} />
              </div>
              <div>
                <label>Bis Monat</label>
                <input type="month" value={statsEndMonth} onChange={(e) => setStatsEndMonth(e.target.value)} />
              </div>
            </div>

            <div style={{ display: "flex", gap: 8, marginBottom: 12 }}>
              <button className={`ghost ${statsTab === "person" ? "note-active" : ""}`} onClick={() => setStatsTab("person")}>
                👤 Teilnahmen pro Person
              </button>
              <button className={`ghost ${statsTab === "day" ? "note-active" : ""}`} onClick={() => setStatsTab("day")}>
                📅 Teilnehmer pro Tag
              </button>
            </div>

            {statsTab === "person" && (
              <div style={{ overflowX: "auto" }}>
                <table style={{ width: "100%" }}>
                  <thead>
                    <tr>
                      <th>Name</th>
                      <th>Gesamt</th>
                      {monthsInRange.map((m) => (
                        <th key={m}>{m}</th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {Object.keys(statsPerPerson).map((name) => (
                      <tr key={name}>
                        <td>
                          {name} {totalsPerPerson[name] === maxTotal && maxTotal > 0 ? "⭐" : ""}
                        </td>
                        <td>{totalsPerPerson[name] || 0}</td>
                        {monthsInRange.map((m) => (
                          <td key={m}>{statsPerPerson[name][m] || 0}</td>
                        ))}
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}

            {statsTab === "day" && (
              <>
                <table style={{ width: "100%" }}>
                  <thead>
                    <tr>
                      <th>Datum</th>
                      <th>Teilnehmer</th>
                    </tr>
                  </thead>
                  <tbody>
                    {Object.entries(statsPerDay)
                      .sort(([a], [b]) => new Date(a).getTime() - new Date(b).getTime())
                      .map(([date, count]) => (
                        <tr key={date}>
                          <td>
                            {date}
                            {state.notes?.[date] && (
                              <div
                                style={{
                                  fontSize: 12,
                                  color: "#555",
                                  background: "#f0f4ff",
                                  padding: "6px 8px",
                                  marginTop: 6,
                                  borderRadius: 6,
                                  border: "1px solid #d7e2ff",
                                  lineHeight: 1.35,
                                }}
                              >
                                📝 {state.notes[date]}
                              </div>
                            )}
                          </td>
                          <td>{count}</td>
                        </tr>
                      ))}
                  </tbody>
                </table>
                <div style={{ marginTop: 20 }}>
                  <canvas ref={chartRef}></canvas>
                </div>
              </>
            )}

            <div style={{ textAlign: "right", marginTop: 16 }}>
              <button className="ghost" onClick={() => setShowStats(false)}>
                Schließen
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Notiz-Modal */}
      {noteEdit && (
        <div className="modal-backdrop">
          <div className="modal">
            <h3>Notiz für {noteEdit.date}</h3>
            <textarea
              value={noteEdit.value}
              onChange={(e) => setNoteEdit({ ...noteEdit, value: e.target.value })}
            />
            <div style={{ display: "flex", justifyContent: "flex-end", gap: 8, marginTop: 8 }}>
              <button className="ghost" onClick={() => setNoteEdit(null)}>
                Abbrechen
              </button>
              <button
                onClick={() => {
                  setAndSave((prev) => ({ ...prev, notes: { ...prev.notes, [noteEdit.date]: noteEdit.value } }));
                  setNoteEdit(null);
                }}
              >
                Speichern
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
