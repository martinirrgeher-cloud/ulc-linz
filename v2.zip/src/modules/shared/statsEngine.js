export function filterByDateRange(data, from, to) {
    return data.filter(d => d.date >= from && d.date <= to);
}
export function aggregateByKey(data, keyField) {
    const result = {};
    for (const item of data) {
        const key = String(item[keyField]);
        result[key] = (result[key] || 0) + 1;
    }
    return result;
}
export function prepareChartData(obj) {
    return { labels: Object.keys(obj), values: Object.values(obj) };
}
