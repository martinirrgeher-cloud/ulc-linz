export default function Uebersicht() {
  return (
    <div>
      <h1 className="text-xl font-semibold mb-2">Übersicht</h1>
      <p className="text-sm text-gray-600">Auswertung & Historie.</p>
    </div>
  )
}
