export default function Katalog() {
  return (
    <div>
      <h1 className="text-xl font-semibold mb-2">Trainingskatalog</h1>
      <p className="text-sm text-gray-600">Übungen, Kategorien, Filter.</p>
    </div>
  )
}
