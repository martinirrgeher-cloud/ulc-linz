// src/lib/googleAuth.ts
// Voll kompatibel zu deinem bisherigen Projekt, aber intern mit Google Identity Services (GIS)

declare global {
  interface Window {
    google?: any;
  }
}

let gisInitialized = false;

/** Base64URL → JSON dekodieren (für JWT) */
function decodeJwt(token: string): any | null {
  try {
    const parts = token.split(".");
    if (parts.length !== 3) return null;
    const payload = parts[1]
      .replace(/-/g, "+")
      .replace(/_/g, "/")
      .padEnd(Math.ceil(parts[1].length / 4) * 4, "=");
    const json = atob(payload);
    return JSON.parse(json);
  } catch {
    return null;
  }
}

function getJwtExp(token: string): number | null {
  const data = decodeJwt(token);
  return data && typeof data.exp === "number" ? data.exp : null;
}

function nowEpoch(): number {
  return Math.floor(Date.now() / 1000);
}

// -------------------------------------------------------
// Initialisierung GIS
// -------------------------------------------------------
export async function initGoogleAuth(): Promise<void> {
  if (gisInitialized) return;
  await new Promise<void>((resolve) => {
    const check = () => {
      if (window.google && window.google.accounts && window.google.accounts.id) {
        window.google.accounts.id.initialize({
          client_id: import.meta.env.VITE_GOOGLE_CLIENT_ID,
          callback: handleCredentialResponse,
          auto_select: false,
        });
        gisInitialized = true;
        resolve();
      } else {
        setTimeout(check, 100);
      }
    };
    check();
  });
}

/** Callback – Token speichern */
function handleCredentialResponse(response: any) {
  if (response && response.credential) {
    localStorage.setItem("google_access_token", response.credential);
  }
}

// -------------------------------------------------------
// Login Flow mit aktivem Warten auf Token
// -------------------------------------------------------
export async function loginGoogle(): Promise<void> {
  if (!gisInitialized) {
    await initGoogleAuth();
  }

  // GIS Prompt anzeigen
  if (window.google?.accounts?.id) {
    window.google.accounts.id.prompt();
  } else {
    console.error("Google Identity Services nicht verfügbar.");
    return;
  }

  // Token aktiv abwarten (max. 10 Sekunden)
  const maxWait = 10000;
  const interval = 100;
  let waited = 0;

  while (waited < maxWait) {
    const token = getAccessToken();
    if (token) return;
    await new Promise((r) => setTimeout(r, interval));
    waited += interval;
  }

  console.error("Kein Token erhalten");
}

// -------------------------------------------------------
// Tokenprüfung / Logout
// -------------------------------------------------------
export async function validateGoogleToken(token: string): Promise<boolean> {
  try {
    const res = await fetch(
      `https://oauth2.googleapis.com/tokeninfo?id_token=${encodeURIComponent(token)}`
    );
    if (!res.ok) return false;
    const exp = getJwtExp(token);
    if (exp !== null && exp < nowEpoch()) return false;
    return true;
  } catch {
    return false;
  }
}

export function logoutGoogle(): void {
  try {
    if (window.google?.accounts?.id) {
      window.google.accounts.id.disableAutoSelect();
    }
  } catch {
    // ignorieren
  } finally {
    clearStorage();
  }
}

// Alias für Kompatibilität
export const signOutGoogle = logoutGoogle;

// -------------------------------------------------------
// Abwärtskompatibilität – alle alten Exporte
// -------------------------------------------------------
export function getAccessToken(): string | null {
  return loadFromStorage();
}

export function loadFromStorage(): string | null {
  return localStorage.getItem("google_access_token");
}

export function clearStorage(): void {
  localStorage.removeItem("google_access_token");
}

export function tokenExpired(): boolean {
  const token = loadFromStorage();
  if (!token) return true;
  const exp = getJwtExp(token);
  if (exp === null) return true;
  return exp <= nowEpoch();
}

export async function silentRefreshIfNeeded(): Promise<string | null> {
  const token = loadFromStorage();
  if (!token) return null;
  if (tokenExpired()) return null;
  return token;
}
