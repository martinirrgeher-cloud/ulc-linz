import { loadJsonByName } from "./googleDrive";
import { hasAccessToken, signInWithGoogle } from "./googleAuth";

interface User {
  username: string;
  password: string;
  role: "admin" | "trainer" | "athlet";
}

/**
 * Stellt sicher, dass ein gültiger Access Token vorhanden ist.
 * Wenn nicht, wird automatisch ein Google-Login gestartet.
 */
async function ensureAccessToken() {
  if (!hasAccessToken()) {
    console.log("🔐 Kein Token vorhanden – starte Google Login…");
    await signInWithGoogle();
  }
}

/**
 * Lädt die Benutzerliste aus users.json (Google Drive)
 */
export async function loadUsers(): Promise<User[]> {
  try {
    await ensureAccessToken();  // 🔸 hier neu
    const data = await loadJsonByName("users.json");
    if (Array.isArray(data)) return data as User[];
    if (data && Array.isArray(data.users)) return data.users as User[];
    console.warn("⚠️ users.json hat ein unerwartetes Format");
    return [];
  } catch (err) {
    console.error("❌ Fehler beim Laden der users.json:", err);
    return [];
  }
}

/**
 * Validiert Benutzername und Passwort gegen users.json
 */
export async function validateUser(username: string, password: string) {
  await ensureAccessToken();  // 🔸 hier ebenfalls neu
  const users = await loadUsers();
  const user = users.find(
    (u) => u.username === username && u.password === password
  );
  return user || null;
}
