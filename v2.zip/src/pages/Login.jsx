import { useState } from "react";
import { validateUser } from "../lib/users";

export default function Login() {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [errorMessage, setErrorMessage] = useState("");

  const handleLogin = async (e) => {
    e.preventDefault();
    setErrorMessage("");

    try {
      const user = await validateUser(username.trim(), password.trim());
      if (user) {
        // ✅ Login erfolgreich → Session speichern
        localStorage.setItem("loggedInUser", JSON.stringify(user));
        console.log("✅ Login erfolgreich:", user);

        // → Weiterleitung (z. B. Dashboard oder Startseite)
        window.location.href = "/";
      } else {
        setErrorMessage("❌ Benutzername oder Passwort ist falsch.");
      }
    } catch (err) {
      console.error("Fehler beim Login:", err);
      setErrorMessage("Ein unerwarteter Fehler ist aufgetreten.");
    }
  };

  return (
    <div className="flex flex-col items-center justify-center h-screen bg-gray-100">
      <div className="bg-white shadow-lg rounded-lg p-8 w-full max-w-sm">
        <h1 className="text-2xl font-semibold mb-6 text-ulc-blue text-center">
          🔐 ULC Linz Login
        </h1>

        {errorMessage && (
          <div className="bg-red-100 text-red-700 px-4 py-2 rounded mb-4 text-sm">
            {errorMessage}
          </div>
        )}

        <form onSubmit={handleLogin} className="flex flex-col space-y-4">
          <input
            type="text"
            placeholder="Benutzername"
            value={username}
            onChange={(e) => setUsername(e.target.value)}
            className="border rounded px-3 py-2 focus:outline-none focus:ring-2 focus:ring-ulc-lightblue"
            required
          />
          <input
            type="password"
            placeholder="Passwort"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            className="border rounded px-3 py-2 focus:outline-none focus:ring-2 focus:ring-ulc-lightblue"
            required
          />

          <button
            type="submit"
            className="bg-ulc-blue hover:bg-ulc-lightblue text-white font-semibold py-2 rounded transition"
          >
            Anmelden
          </button>
        </form>
      </div>
    </div>
  );
}
