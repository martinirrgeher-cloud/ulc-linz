import { useEffect, useState } from "react";
import { loginWithCredentials } from "../lib/auth";

export default function Login() {
  const [errorMessage, setErrorMessage] = useState("");

  useEffect(() => {
    // Prüfen, ob wir evtl. von einem abgelaufenen Token kommen
    const reason = sessionStorage.getItem("login_error_reason");
    if (reason) {
      setErrorMessage(reason);
      sessionStorage.removeItem("login_error_reason"); // nach Anzeige löschen
    }
  }, []);

  const handleLogin = async () => {
    try {
      await loginWithCredentials();
    } catch (err) {
      console.error("❌ Fehler beim Login:", err);
      setErrorMessage("Die Anmeldung ist fehlgeschlagen. Bitte versuche es erneut.");
    }
  };

  return (
    <div className="flex flex-col items-center justify-center h-screen bg-gray-100 px-4">
      <div className="bg-white rounded-lg shadow-lg p-8 w-full max-w-sm text-center">
        <h1 className="text-2xl font-semibold mb-4 text-ulc-blue">
          🔐 ULC Linz Login
        </h1>

        {errorMessage && (
          <div className="bg-red-100 text-red-700 px-4 py-2 rounded mb-4">
            {errorMessage}
          </div>
        )}

        <button
          onClick={handleLogin}
          className="bg-ulc-blue hover:bg-ulc-lightblue text-white font-semibold px-4 py-2 rounded w-full transition"
        >
          Mit Google anmelden
        </button>
      </div>
    </div>
  );
}
