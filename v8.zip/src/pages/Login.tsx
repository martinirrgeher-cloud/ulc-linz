// src/pages/Login.tsx
import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { ROUTES } from "../routes";
import { validateUser, ensureUsersFileExists } from "../lib/users";
import { setCurrentUser } from "../lib/authStore";
import {
  isTokenValid,
  triggerLogin,
  triggerSilentLogin,
} from "../lib/googleAuth";

export default function Login() {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  const [redirected, setRedirected] = useState(false);
  const navigate = useNavigate();

  /**
   * Wenn Token bereits gültig ist → EINMAL weiterleiten
   */
  useEffect(() => {
    if (isTokenValid() && !redirected) {
      console.log("✅ Token vorhanden – weiterleiten");
      setRedirected(true);
      navigate(ROUTES.MENU, { replace: true });
    }
  }, [navigate, redirected]);

  /**
   * Silent Login beim Laden versuchen
   */
  useEffect(() => {
    const runSilentLogin = async () => {
      if (!isTokenValid()) {
        try {
          const ok = await triggerSilentLogin();
          if (ok) {
            console.log("✅ Silent Login erfolgreich");
            await ensureUsersFileExists(); // Seed users.json falls nötig
            navigate(ROUTES.MENU, { replace: true });
          }
        } catch {
          console.log("ℹ️ Silent Login nicht möglich – Benutzer muss sich einloggen.");
        }
      }
    };
    runSilentLogin();
  }, [navigate]);

  /**
   * Handle Login per Formular
   */
  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    setLoading(true);

    try {
      if (!isTokenValid()) {
        const silent = await triggerSilentLogin();
        if (!silent) {
          console.log("🔐 Popup Login erforderlich");
          await triggerLogin();
        }
      }

      await ensureUsersFileExists();
      const user = await validateUser(username, password);
      if (!user) {
        setError("❌ Benutzername oder Passwort ist ungültig");
        setLoading(false);
        return;
      }

      setCurrentUser(user);
      console.log("✅ Login erfolgreich für", user.username);
      navigate(ROUTES.MENU, { replace: true });
    } catch (err) {
      console.error("❌ Login Fehler:", err);
      setError("Fehler beim Login");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="container" style={{ maxWidth: 400, margin: "0 auto" }}>
      <h1>🔐 Login</h1>
      <form
        onSubmit={handleLogin}
        style={{ display: "flex", flexDirection: "column", gap: 8 }}
      >
        <input
          type="text"
          placeholder="Benutzername (E-Mail)"
          value={username}
          onChange={(e) => setUsername(e.target.value)}
        />
        <input
          type="password"
          placeholder="Passwort"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
        />
        {error && <div style={{ color: "red" }}>{error}</div>}
        <button type="submit" disabled={loading}>
          {loading ? "Anmelden..." : "Login"}
        </button>
      </form>

      {/* Optionaler Seed-Button für die Entwicklung */}
      <div style={{ marginTop: "1rem" }}>
        <button
          type="button"
          onClick={async () => {
            if (!isTokenValid()) {
              alert("Bitte zuerst Google Login durchführen.");
              return;
            }
            await ensureUsersFileExists();
            alert("✅ users.json geprüft/angelegt");
          }}
        >
          🧪 users.json anlegen/prüfen (Dev)
        </button>
      </div>
    </div>
  );
}
