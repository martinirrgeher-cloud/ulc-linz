// src/App.tsx
import { useEffect } from "react";
import { BrowserRouter as Router, Routes, Route, Navigate } from "react-router-dom";
import { restoreAccessToken, initGoogleAuth, isTokenValid } from "./lib/googleAuth";
import Login from "./pages/Login";
import MainMenu from "./pages/MainMenu"; // ✅ Wichtig
import Kindertraining from "./modules/Kindertraining/Kindertraining";
import U12 from "./modules/U12/U12";
import U14 from "./modules/U14/U14";
import Leistungsgruppe from "./modules/Leistungsgruppe/Leistungsgruppe";
import { ROUTES } from "./routes";

function ProtectedRoute({ children }: { children: React.ReactNode }) {
  // Wenn kein gültiger Token vorhanden → immer zur Login-Seite
  if (!isTokenValid()) {
    return <Navigate to={ROUTES.LOGIN} replace />;
  }
  return <>{children}</>;
}

export default function App() {
  useEffect(() => {
    // Token beim Laden wiederherstellen und Google Auth initialisieren
    initGoogleAuth();
    restoreAccessToken();
    // ❌ kein forceLogout hier – sonst Loop beim Start
  }, []);

  return (
    <Router>
      <Routes>
        {/* Login ist NICHT geschützt */}
        <Route path={ROUTES.LOGIN} element={<Login />} />

        {/* Geschützte Bereiche */}
        <Route
        path={ROUTES.MENU}
        element={
       <ProtectedRoute>
      <MainMenu />
       </ProtectedRoute>
       }
        />
        <Route
          path={ROUTES.KINDERTRAINING}
          element={
            <ProtectedRoute>
              <Kindertraining />
            </ProtectedRoute>
          }
        />
        <Route
          path={ROUTES.U12}
          element={
            <ProtectedRoute>
              <U12 />
            </ProtectedRoute>
          }
        />
        <Route
          path={ROUTES.U14}
          element={
            <ProtectedRoute>
              <U14 />
            </ProtectedRoute>
          }
        />
        <Route
          path={ROUTES.LEISTUNGSGRUPPE}
          element={
            <ProtectedRoute>
              <Leistungsgruppe />
            </ProtectedRoute>
          }
        />

        {/* Fallback → Login */}
        <Route path="*" element={<Navigate to={ROUTES.LOGIN} replace />} />
      </Routes>
    </Router>
  );
}
