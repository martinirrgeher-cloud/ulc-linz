export const ROUTES = {
  ROOT: "/",
  MENU: "/menu",  // 🆗 jetzt ist das erlaubt, weil wir MainMenu.tsx einbauen

  LOGIN: "/login",

  KINDERTRAINING: "/kindertraining",
  KINDERTRAINING_WOCHENTAGE: "/kindertraining/wochentage",
  KINDERTRAINING_STATISTIK: "/kindertraining/statistik",

  U12: "/u12",
  U14: "/u14",
  LEISTUNGSGRUPPE: "/leistungsgruppe",
};
