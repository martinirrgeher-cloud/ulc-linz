let accessToken: string | null = null;
let tokenExpiresAt: number | null = null;
let refreshTimeout: ReturnType<typeof setTimeout> | null = null;

const CLIENT_ID = import.meta.env.VITE_GOOGLE_CLIENT_ID;
const SCOPES = "https://www.googleapis.com/auth/drive.file";

let tokenClient: any = null;

/**
 * Google Auth initialisieren
 */
export function initGoogleAuth() {
  tokenClient = google.accounts.oauth2.initTokenClient({
    client_id: CLIENT_ID,
    scope: SCOPES,
    callback: (response: any) => {
      if (response.error) {
        console.error("❌ Token Error:", response);
        return;
      }
      setAccessToken(response.access_token, response.expires_in);
    },
  });
  restoreAccessToken();
}

/**
 * Access Token speichern + Ablaufzeit + Auto-Refresh starten
 */
export function setAccessToken(token: string, expiresIn: number) {
  accessToken = token;
  tokenExpiresAt = Date.now() + expiresIn * 1000;
  localStorage.setItem("gAccessToken", token);
  localStorage.setItem("gAccessTokenExpires", tokenExpiresAt.toString());
  console.log("✅ Token gespeichert, gültig bis:", new Date(tokenExpiresAt).toLocaleTimeString());
  scheduleRefresh(expiresIn);
}

/**
 * Token-Refresh kurz vor Ablauf
 */
function scheduleRefresh(expiresIn: number) {
  if (refreshTimeout) clearTimeout(refreshTimeout);
  const refreshTime = Math.max(0, (expiresIn - 120) * 1000);
  refreshTimeout = setTimeout(() => {
    console.log("🔄 Token läuft bald ab – Silent Refresh");
    triggerSilentLogin().catch(() => {
      console.warn("❌ Silent Refresh fehlgeschlagen → forceLogout()");
      forceLogout();
    });
  }, refreshTime);
}

/**
 * Token aus localStorage wiederherstellen
 */
export function restoreAccessToken() {
  const saved = localStorage.getItem("gAccessToken");
  const savedExp = localStorage.getItem("gAccessTokenExpires");
  if (saved && savedExp) {
    accessToken = saved;
    tokenExpiresAt = parseInt(savedExp);
    const remaining = tokenExpiresAt - Date.now();
    if (remaining > 0) {
      console.log("🔐 Token wiederhergestellt");
      scheduleRefresh(remaining / 1000);
    } else {
      console.warn("⚠️ Token ist abgelaufen");
      clearAccessToken();
    }
  }
}

/**
 * Token löschen
 */
export function clearAccessToken() {
  accessToken = null;
  tokenExpiresAt = null;
  localStorage.removeItem("gAccessToken");
  localStorage.removeItem("gAccessTokenExpires");
  if (refreshTimeout) clearTimeout(refreshTimeout);
  refreshTimeout = null;
}

/**
 * Token-Gültigkeit prüfen
 */
export function isTokenValid(): boolean {
  return accessToken !== null && tokenExpiresAt !== null && Date.now() < tokenExpiresAt;
}

/**
 * Silent Login ohne Popup
 */
export function triggerSilentLogin() {
  return new Promise<void>((resolve, reject) => {
    tokenClient.callback = (response: any) => {
      if (response.error) {
        reject(response.error);
        return;
      }
      setAccessToken(response.access_token, response.expires_in);
      resolve();
    };
    tokenClient.requestAccessToken({ prompt: "none" });
  });
}

/**
 * Popup Login
 */
export function triggerLogin() {
  return new Promise<void>((resolve, reject) => {
    tokenClient.callback = (response: any) => {
      if (response.error) {
        reject(response.error);
        return;
      }
      setAccessToken(response.access_token, response.expires_in);
      resolve();
    };
    tokenClient.requestAccessToken();
  });
}

/**
 * Aktuellen Token abrufen
 */
export function getAccessToken() {
  return accessToken;
}

/**
 * forceLogout → Token löschen + Redirect zur Login-Seite
 */
export function forceLogout() {
  console.warn("🚪 forceLogout → zurück zur Login-Seite");
  clearAccessToken();
  localStorage.clear();
  window.location.href = "/login";
}
