// src/lib/users.ts
import { loadJsonByName } from "./googleDrive";
import { isTokenValid } from "./googleAuth";

export interface User {
  username: string;
  password: string;
  role: "admin" | "trainer" | "athlet";
  modules?: string[];
}

export async function loadUsers(): Promise<User[]> {
  // Token wird bereits vor dem Login geholt
  if (!isTokenValid()) {
    console.warn("⚠️ Kein Google Token – users.json kann evtl. nicht geladen werden.");
  }
  const data = await loadJsonByName("users.json");
  if (Array.isArray(data)) return data as User[];
  if (data && Array.isArray(data.users)) return data.users as User[];
  console.warn("⚠️ users.json hat ein unerwartetes Format");
  return [];
}

export async function validateUser(username: string, password: string) {
  const users = await loadUsers();
  return (
    users.find(
      (u) => u.username === username && u.password === password
    ) || null
  );
}


// src/lib/users.ts (am Ende der Datei)
import { saveJsonByName, loadJsonByName } from "./googleDrive";

// Legt users.json an, wenn sie fehlt – mit einem Default-Admin
export async function ensureUsersFileExists() {
  const existing = await loadJsonByName("users.json");
  if (existing) return; // existiert bereits

  const defaultUsers = [
    { username: "admin@example.com", password: "admin", role: "admin" },
    // weitere Trainer kannst du hier ergänzen
  ];

  await saveJsonByName("users.json", defaultUsers);
  console.log("✅ users.json wurde neu erstellt (Default-Admin: admin@example.com / admin)");
}
