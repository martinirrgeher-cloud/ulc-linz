import { FileImage, PlayCircle } from "lucide-react";
import "../styles/Uebungskatalog.css";

export default function UebungCard({ uebung }: { uebung: any }) {
  const hasMedia = uebung.mediaUrl && uebung.mediaUrl.trim() !== "";
  const difficulty = uebung.difficulty || 1;

  return (
    <div className="uebung-row">
      <div className="uebung-info">
        <span className="uebung-name">{uebung.name}</span>
        <span className="uebung-einheit">
          {uebung.menge} {uebung.einheit}
        </span>
      </div>

      <div className="uebung-icons">
        <div className={`media-icon ${hasMedia ? "active" : ""}`}>
          {uebung.mediaType === "video" ? <PlayCircle size={18} /> : <FileImage size={18} />}
        </div>
        <div className="uebung-difficulty">
          {[1, 2, 3].map((n) => (
            <span key={n} className={difficulty >= n ? "star active" : "star"}>
              ★
            </span>
          ))}
        </div>
      </div>
    </div>
  );
}
