// src/modules/leistungsgruppe/trainingsplanung/pages/Trainingsplanung.tsx
import React, { useEffect, useMemo, useState } from "react";
import "../styles/Trainingsplanung.css";
import {
  startOfISOWeek as startOfISOWeekStr,
  weekRangeFrom,
  toISODate,
  addDays,
} from "../../common/date";
import {
  loadAthleten,
} from "../../../athleten/services/AthletenStore";
import type { Athlete } from "../../../athleten/types/athleten";
import {
  loadAnmeldung,
  DayStatus,
  AnmeldungData,
} from "../../anmeldung/services/AnmeldungStore";
import {
  loadPlans,
  upsertAthleteDay,
  PlanDay,
  PlanItem,
  PlanBlock,
} from "../services/TrainingsplanungStore";
import {
  listExercisesLite,
  ExerciseLite,
} from "../../../uebungskatalog/services/ExercisesLite";

type AthleteLite = {
  id: string;
  name: string;
  active?: boolean;
};

type StatusMap = Record<string, DayStatus>;

function formatAthleteName(a: Athlete): string {
  if (a.firstName || a.lastName) {
    return `${a.lastName ?? ""} ${a.firstName ?? ""}`.trim();
  }
  return a.name ?? a.id;
}

function toAthleteLite(a: Athlete): AthleteLite {
  return {
    id: a.id,
    name: formatAthleteName(a),
    active: a.active ?? true,
  };
}

function startOfISOWeek(date: Date): string {
  // Wrapper für String-Version
  return startOfISOWeekStr(date);
}

function ensureDay(base: PlanDay | null): PlanDay {
  if (!base) {
    return {
      order: [],
      items: {},
      blocks: {},
      blockOrder: [],
    };
  }
  const blocks = base.blocks ?? {};
  let blockOrder = base.blockOrder ?? Object.keys(blocks);

  // Falls es noch keine Blöcke gibt, aber eine flache order, alles in einen Default-Block legen
  if ((!blockOrder || blockOrder.length === 0) && base.order && base.order.length > 0) {
    const id = "block-standard";
    const blk: PlanBlock = {
      id,
      title: "Plan",
      type: "SONSTIGES",
      targetDurationMin: null,
      itemOrder: [...base.order],
    };
    return {
      ...base,
      blocks: { [id]: blk },
      blockOrder: [id],
    };
  }

  return {
    ...base,
    blocks,
    blockOrder: blockOrder ?? [],
  };
}

function normalizeOrder(day: PlanDay): PlanDay {
  if (!day.blocks || !day.blockOrder || day.blockOrder.length === 0) {
    return day;
  }
  const order: string[] = [];
  for (const bid of day.blockOrder) {
    const blk = day.blocks[bid];
    if (!blk) continue;
    for (const iid of blk.itemOrder) {
      if (!order.includes(iid)) order.push(iid);
    }
  }
  return { ...day, order };
}

function statusBadgeClass(s: DayStatus | undefined): string {
  if (s === "YES") return "tp-day-status yes";
  if (s === "MAYBE") return "tp-day-status maybe";
  if (s === "NO") return "tp-day-status no";
  return "tp-day-status none";
}

type PickerTab = "KATALOG" | "MANUAL";

type ManualExerciseDraft = {
  name: string;
  haupt: string;
  unter: string;
  reps: string;
  menge: string;
  einheit: string;
};

export default function TrainingsplanungPage() {
  const [athletes, setAthletes] = useState<AthleteLite[]>([]);
  const [selectedAthleteId, setSelectedAthleteId] = useState<string>("");
  const [weekStartISO, setWeekStartISO] = useState<string>(() =>
    startOfISOWeek(new Date())
  );
  const [dateISO, setDateISO] = useState<string>(() => toISODate(new Date()));

  const [plansByAthlete, setPlansByAthlete] = useState<
    Record<string, Record<string, PlanDay>>
  >({});
  const [currentDay, setCurrentDay] = useState<PlanDay | null>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [saving, setSaving] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  const [anmeldung, setAnmeldung] = useState<AnmeldungData | null>(null);
  const [anmeldungLoading, setAnmeldungLoading] = useState(false);

  const [exercises, setExercises] = useState<ExerciseLite[]>([]);
  const [exerciseLoading, setExerciseLoading] = useState(false);

  const [pickerOpen, setPickerOpen] = useState(false);
  const [pickerTab, setPickerTab] = useState<PickerTab>("KATALOG");
  const [pickerBlockId, setPickerBlockId] = useState<string | null>(null);

  const [searchText, setSearchText] = useState("");
  const [searchHaupt, setSearchHaupt] = useState("");
  const [searchUnter, setSearchUnter] = useState("");

  const [manualDraft, setManualDraft] = useState<ManualExerciseDraft>({
    name: "",
    haupt: "",
    unter: "",
    reps: "",
    menge: "",
    einheit: "",
  });
  const [collapsedBlocks, setCollapsedBlocks] = useState<Record<string, boolean>>({});

  // -------------------------------------------------------
  // Initial: Athleten, Pläne, Anmeldung, Katalog laden
  // -------------------------------------------------------
  useEffect(() => {
    let cancelled = false;

    async function loadAll() {
      try {
        setLoading(true);

        // Athleten
        try {
          const ath = await loadAthleten();
          if (!cancelled) {
            const lite = ath.map(toAthleteLite).sort((a, b) =>
              a.name.localeCompare(b.name, "de", { sensitivity: "base" })
            );
            setAthletes(lite);
            if (!selectedAthleteId && lite.length > 0) {
              setSelectedAthleteId(lite[0].id);
            }
          }
        } catch (err) {
          console.error("Trainingsplanung: loadAthleten fehlgeschlagen", err);
        }

        // Pläne
        try {
          const data = await loadPlans();
          if (!cancelled) {
            setPlansByAthlete(data.plansByAthlete ?? {});
          }
        } catch (err) {
          console.error("Trainingsplanung: loadPlans fehlgeschlagen", err);
          if (!cancelled) {
            setPlansByAthlete({});
          }
        }

        // Anmeldung
        try {
          setAnmeldungLoading(true);
          const a = await loadAnmeldung();
          if (!cancelled) setAnmeldung(a);
        } catch (err) {
          console.error("Trainingsplanung: loadAnmeldung fehlgeschlagen", err);
        } finally {
          if (!cancelled) setAnmeldungLoading(false);
        }

        // Übungskatalog (Lite)
        try {
          setExerciseLoading(true);
          const ex = await listExercisesLite();
          if (!cancelled) setExercises(ex);
        } catch (err) {
          console.error("Trainingsplanung: listExercisesLite fehlgeschlagen", err);
        } finally {
          if (!cancelled) setExerciseLoading(false);
        }
      } finally {
        if (!cancelled) setLoading(false);
      }
    }

    loadAll();

    return () => {
      cancelled = true;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // -------------------------------------------------------
  // Week / days
  // -------------------------------------------------------
  const weekDates: string[] = useMemo(
    () => weekRangeFrom(weekStartISO),
    [weekStartISO]
  );

  // Falls aktuelles Datum nicht in der Woche liegt → auf Wochenstart setzen
  useEffect(() => {
    if (!weekDates.includes(dateISO)) {
      setDateISO(weekDates[0]);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [weekStartISO]);

  const weekLabel = useMemo(() => {
    const d = new Date(weekStartISO + "T00:00:00");
    // einfache KW-Bestimmung über Index in Jahr; reicht hier als Orientierung
    const jan1 = new Date(d.getFullYear(), 0, 1);
    const diff = d.getTime() - jan1.getTime();
    const day = Math.floor(diff / (1000 * 60 * 60 * 24));
    const kw = Math.floor((day + jan1.getDay()) / 7) + 1;
    return `KW ${kw.toString().padStart(2, "0")} / ${d.getFullYear()}`;
  }, [weekStartISO]);

  // -------------------------------------------------------
  // Anmeldung-Status-Map
  // -------------------------------------------------------
  const statusMap: StatusMap = useMemo(() => {
    const result: StatusMap = {};
    if (!anmeldung || !selectedAthleteId) return result;
    const statuses = anmeldung.statuses ?? {};
    for (const [key, val] of Object.entries(statuses)) {
      // Format in Anmeldung: `${athletId}:${isoDate}`
      if (typeof val === "string" || val === null) {
        result[key] = val as DayStatus;
      }
    }
    return result;
  }, [anmeldung, selectedAthleteId]);

  // -------------------------------------------------------
  // Aktuellen Tagesplan ableiten
  // -------------------------------------------------------
  useEffect(() => {
    if (!selectedAthleteId) {
      setCurrentDay(null);
      return;
    }
    const byAth = plansByAthlete[selectedAthleteId] ?? {};
    const base = byAth[dateISO] ?? null;
    const norm = ensureDay(base);
    setCurrentDay(norm);
  }, [plansByAthlete, selectedAthleteId, dateISO]);

  // -------------------------------------------------------
  // Hilfsfunktionen zum Speichern
  // -------------------------------------------------------
  function saveDay(athleteId: string, iso: string, day: PlanDay) {
    if (!athleteId) return;
    (async () => {
      try {
        setSaving(true);
        const normalized = normalizeOrder(day);
        await upsertAthleteDay(athleteId, iso, normalized);
      } catch (err) {
        console.error("Trainingsplanung: Speichern fehlgeschlagen", err);
        setError("Fehler beim Speichern des Plans.");
      } finally {
        setSaving(false);
      }
    })();
  }

  function updateDay(mutator: (prev: PlanDay) => PlanDay) {
    if (!selectedAthleteId) return;
    setCurrentDay((prev) => {
      const base = ensureDay(prev);
      const next = normalizeOrder(mutator(base));
      setPlansByAthlete((prevPlans) => {
        const copy = { ...prevPlans };
        const inner = { ...(copy[selectedAthleteId] ?? {}) };
        inner[dateISO] = next;
        copy[selectedAthleteId] = inner;
        return copy;
      });
      saveDay(selectedAthleteId, dateISO, next);
      return next;
    });
  }

  // -------------------------------------------------------
  // Block-Operationen
  // -------------------------------------------------------
  function handleAddBlock() {
    const id = `blk-${Date.now().toString(36)}-${Math.random()
      .toString(36)
      .slice(2, 6)}`;
    setCollapsedBlocks((prev) => ({
      ...prev,
      [id]: true,
    }));
    updateDay((prev) => {
      const blocks = { ...(prev.blocks ?? {}) };
      const blockOrder = [...(prev.blockOrder ?? [])];
      blocks[id] = {
        id,
        title: "Neuer Block",
        type: "SONSTIGES",
        targetDurationMin: null,
        itemOrder: [],
      };
      blockOrder.push(id);
      return { ...prev, blocks, blockOrder };
    });
  }

  function handleRemoveBlock(blockId: string) {
    updateDay((prev) => {
      const blocks = { ...(prev.blocks ?? {}) };
      const removed = blocks[blockId];
      delete blocks[blockId];

      // Items des Blocks optional auch aus items entfernen
      const items = { ...prev.items };
      if (removed) {
        for (const iid of removed.itemOrder) {
          delete items[iid];
        }
      }

      const blockOrder = (prev.blockOrder ?? []).filter((id) => id !== blockId);
      return { ...prev, blocks, blockOrder, items };
    setCollapsedBlocks((prev) => {
      const copy = { ...prev };
      delete copy[blockId];
      return copy;
    });
    });
  }

  function handleUpdateBlockTitle(blockId: string, title: string) {
    updateDay((prev) => {
      const blocks = { ...(prev.blocks ?? {}) };
      const blk = blocks[blockId];
      if (!blk) return prev;
      blocks[blockId] = { ...blk, title };
      return { ...prev, blocks };
    });
  }

  function handleUpdateBlockDuration(blockId: string, durationMin: string) {
    const val = durationMin.trim();
    const num = val === "" ? null : Number(val.replace(",", "."));
    updateDay((prev) => {
      const blocks = { ...(prev.blocks ?? {}) };
      const blk = blocks[blockId];
      if (!blk) return prev;
      blocks[blockId] = {
        ...blk,
        targetDurationMin:
          num !== null && !Number.isNaN(num) && num >= 0 ? num : null,
      };
      return { ...prev, blocks };
    });
  }

  function handleUpdateBlockNotes(blockId: string, notes: string) {
    // notes wird einfach als zusätzliches Feld am Block abgelegt
    updateDay((prev) => {
      const blocks = { ...(prev.blocks ?? {}) };
      const blk = blocks[blockId];
      if (!blk) return prev;
      blocks[blockId] = { ...(blk as any), notes };
      return { ...prev, blocks };
    });
  }

  function toggleBlockCollapsed(blockId: string) {
    setCollapsedBlocks((prev) => ({
      ...prev,
      [blockId]: !prev[blockId],
    }));
  }
  // -------------------------------------------------------
  // Exercise Picker öffnen
  // -------------------------------------------------------
  function openPickerForBlock(blockId: string) {
    setPickerBlockId(blockId);
    setPickerOpen(true);
    setPickerTab("KATALOG");
  }

  function closePicker() {
    setPickerOpen(false);
    setPickerBlockId(null);
    setSearchText("");
    setSearchHaupt("");
    setSearchUnter("");
    setManualDraft({
      name: "",
      haupt: "",
      unter: "",
      reps: "",
      menge: "",
      einheit: "",
    });
  }

  // -------------------------------------------------------
  // Übungen filtern (Katalog)
  // -------------------------------------------------------
  const filteredExercises = useMemo(() => {
    const q = searchText.trim().toLowerCase();
    const h = searchHaupt.trim().toLowerCase();
    const u = searchUnter.trim().toLowerCase();
    return exercises.filter((ex) => {
      if (q) {
        const hay = `${ex.name} ${ex.haupt ?? ""} ${ex.unter ?? ""}`.toLowerCase();
        if (!hay.includes(q)) return false;
      }
      if (h && (ex.haupt ?? "").toLowerCase() !== h) return false;
      if (u && (ex.unter ?? "").toLowerCase() !== u) return false;
      return true;
    });
  }, [exercises, searchText, searchHaupt, searchUnter]);

  const allHauptgruppen = useMemo(() => {
    const set = new Set<string>();
    exercises.forEach((ex) => {
      if (ex.haupt) set.add(ex.haupt);
    });
    return Array.from(set).sort((a, b) =>
      a.localeCompare(b, "de", { sensitivity: "base" })
    );
  }, [exercises]);

  const allUntergruppen = useMemo(() => {
    const set = new Set<string>();
    exercises.forEach((ex) => {
      if (ex.unter) set.add(ex.unter);
    });
    return Array.from(set).sort((a, b) =>
      a.localeCompare(b, "de", { sensitivity: "base" })
    );
  }, [exercises]);

  // -------------------------------------------------------
  // Übung zu Block hinzufügen (Katalog)
  // -------------------------------------------------------
  function handleAddCatalogExercise(ex: ExerciseLite) {
    if (!pickerBlockId) return;
    const id = `it-${Date.now().toString(36)}-${Math.random()
      .toString(36)
      .slice(2, 6)}`;

    const baseTarget = {
      reps: ex.reps ?? null,
      menge: ex.menge ?? null,
      einheit: ex.einheit ?? null,
      sets: null,
      distanceM: null,
      weightKg: null,
      durationSec: null,
    };

    const item: PlanItem = {
      exerciseId: ex.id,
      nameCache: ex.name,
      groupCache: {
        haupt: ex.haupt ?? undefined,
        unter: ex.unter ?? undefined,
      },
      default: baseTarget,
      target: { ...baseTarget },
      pauseSec: null,
      comment: "",
    };

    updateDay((prev) => {
      const items = { ...prev.items, [id]: item };
      const blocks = { ...(prev.blocks ?? {}) };
      const blk = blocks[pickerBlockId];
      if (!blk) return prev;
      const itemOrder = [...blk.itemOrder, id];
      blocks[pickerBlockId] = { ...blk, itemOrder };
      return { ...prev, items, blocks };
    });

    // nach Auswahl Picker offen lassen (für mehrere Übungen) oder schließen -> hier offen lassen
  }

  // -------------------------------------------------------
  // Übung zu Block hinzufügen (manuell)
  // -------------------------------------------------------
  function handleAddManualExercise() {
    if (!pickerBlockId) return;
    const name = manualDraft.name.trim();
    if (!name) return;

    const reps =
      manualDraft.reps.trim() === ""
        ? null
        : Number(manualDraft.reps.replace(",", "."));
    const menge =
      manualDraft.menge.trim() === ""
        ? null
        : Number(manualDraft.menge.replace(",", "."));
    const einheit = manualDraft.einheit.trim() || null;

    const id = `manual-${Date.now().toString(36)}-${Math.random()
      .toString(36)
      .slice(2, 6)}`;

    const baseTarget = {
      reps: !Number.isNaN(reps ?? NaN) ? reps : null,
      menge: !Number.isNaN(menge ?? NaN) ? menge : null,
      einheit,
      sets: null,
      distanceM: null,
      weightKg: null,
      durationSec: null,
    };

    const item: PlanItem = {
      exerciseId: id,
      nameCache: name,
      groupCache: {
        haupt: manualDraft.haupt || undefined,
        unter: manualDraft.unter || undefined,
      },
      default: baseTarget,
      target: { ...baseTarget },
      pauseSec: null,
      comment: "",
    };

    updateDay((prev) => {
      const items = { ...prev.items, [id]: item };
      const blocks = { ...(prev.blocks ?? {}) };
      const blk = blocks[pickerBlockId];
      if (!blk) return prev;
      const itemOrder = [...blk.itemOrder, id];
      blocks[pickerBlockId] = { ...blk, itemOrder };
      return { ...prev, items, blocks };
    });

    setManualDraft({
      name: "",
      haupt: manualDraft.haupt,
      unter: manualDraft.unter,
      reps: "",
      menge: "",
      einheit: manualDraft.einheit,
    });
  }

  // -------------------------------------------------------
  // Items in Blöcken bearbeiten
  // -------------------------------------------------------
  function handleRemoveItem(blockId: string, itemId: string) {
    updateDay((prev) => {
      const blocks = { ...(prev.blocks ?? {}) };
      const blk = blocks[blockId];
      if (!blk) return prev;
      const itemOrder = blk.itemOrder.filter((id) => id !== itemId);
      blocks[blockId] = { ...blk, itemOrder };
      const items = { ...prev.items };
      delete items[itemId];
      return { ...prev, blocks, items };
    });
  }

  function handleMoveItem(blockId: string, itemId: string, dir: -1 | 1) {
    updateDay((prev) => {
      const blocks = { ...(prev.blocks ?? {}) };
      const blk = blocks[blockId];
      if (!blk) return prev;
      const idx = blk.itemOrder.indexOf(itemId);
      if (idx === -1) return prev;
      const target = idx + dir;
      if (target < 0 || target >= blk.itemOrder.length) return prev;
      const itemOrder = [...blk.itemOrder];
      const [spliced] = itemOrder.splice(idx, 1);
      itemOrder.splice(target, 0, spliced);
      blocks[blockId] = { ...blk, itemOrder };
      return { ...prev, blocks };
    });
  }

  function handleUpdateItemComment(itemId: string, comment: string) {
    updateDay((prev) => {
      const items = { ...prev.items };
      const it = items[itemId];
      if (!it) return prev;
      items[itemId] = { ...it, comment };
      return { ...prev, items };
    });
  }

  function handleUpdateItemTarget(
    itemId: string,
    patch: Partial<PlanItem["target"]>
  ) {
    updateDay((prev) => {
      const items = { ...prev.items };
      const it = items[itemId];
      if (!it) return prev;
      items[itemId] = {
        ...it,
        target: { ...it.target, ...patch },
      };
      return { ...prev, items };
    });
  }

  // -------------------------------------------------------
  // UI Hilfsdaten
  // -------------------------------------------------------
  const selectedAthlete = useMemo(
    () => athletes.find((a) => a.id === selectedAthleteId) ?? null,
    [athletes, selectedAthleteId]
  );

  const blocks: PlanBlock[] = useMemo(() => {
    if (!currentDay || !currentDay.blocks || !currentDay.blockOrder) return [];
    return currentDay.blockOrder
      .map((id) => currentDay.blocks![id])
      .filter((b): b is PlanBlock => Boolean(b));
  }, [currentDay]);

  const isBusy = loading || saving;

  // -------------------------------------------------------
  // Rendering
  // -------------------------------------------------------
  return (
    <div className="tp-root">
      <div className="tp-header">
        <div className="tp-header-row">
          <div className="tp-field">
            <label className="tp-label">Athlet</label>
            <select
              className="tp-input"
              value={selectedAthleteId}
              onChange={(e) => setSelectedAthleteId(e.target.value)}
            >
              <option value="">– auswählen –</option>
              {athletes.map((a) => (
                <option key={a.id} value={a.id}>
                  {a.name}
                  {a.active === false ? " (inaktiv)" : ""}
                </option>
              ))}
            </select>
          </div>
          <div className="tp-field tp-week-nav">
            <button
              type="button"
              className="tp-btn"
              onClick={() =>
                setWeekStartISO(
                  startOfISOWeek(new Date(addDays(weekStartISO, -7) + "T00:00:00"))
                )
              }
            >
              ◀
            </button>
            <div className="tp-week-label">{weekLabel}</div>
            <button
              type="button"
              className="tp-btn"
              onClick={() =>
                setWeekStartISO(
                  startOfISOWeek(new Date(addDays(weekStartISO, 7) + "T00:00:00"))
                )
              }
            >
              ▶
            </button>
          </div>
        </div>

        <div className="tp-days-row">
          {weekDates.map((d) => {
            const isSelected = d === dateISO;
            const dateObj = new Date(d + "T00:00:00");
            const weekdayNames = ["Mo", "Di", "Mi", "Do", "Fr", "Sa", "So"];
            const weekdayIndex =
              ((dateObj.getDay() + 6) % 7); // Montag=0
            const weekdayShort = weekdayNames[weekdayIndex] ?? "";
            const label = `${d.slice(8, 10)}.${d.slice(5, 7)}.`;

            const statusKey = selectedAthleteId
              ? `${selectedAthleteId}:${d}`
              : "";
            const status = statusMap[statusKey];

            const cls = [
              "tp-day-button",
              isSelected ? "selected" : "",
            ]
              .filter(Boolean)
              .join(" ");

            return (
              <button
                key={d}
                type="button"
                className={cls}
                onClick={() => setDateISO(d)}
              >
                <div className="tp-day-weekday">{weekdayShort}</div>
                <div className="tp-day-date">{label}</div>
                <div className={statusBadgeClass(status)} />
              </button>
            );
          })}
        </div>

        {anmeldungLoading && (
          <div className="tp-badge">Anmeldedaten werden geladen …</div>
        )}
      </div>

      {!selectedAthlete && (
        <div className="tp-info">Bitte zuerst einen Athleten auswählen.</div>
      )}

      {selectedAthlete && (
        <div className="tp-body">
          <div className="tp-body-header">
            <div className="tp-body-title">
              Trainingsplan für {selectedAthlete.name} – {dateISO}
            </div>
            <div className="tp-body-actions">
              <button
                type="button"
                className="tp-btn"
                onClick={handleAddBlock}
              >
                Neuer Block
              </button>
              {/* Block aus Vorlage – können wir als nächsten Schritt an Trainingsblöcke anbinden */}
              {/* <button type="button" className="tp-btn">Block aus Vorlage</button> */}
            </div>
          </div>

          {error && <div className="tp-error">{error}</div>}

          {blocks.length === 0 && (
            <div className="tp-empty">
              Noch keine Blöcke angelegt. Lege einen neuen Block an.
            </div>
          )}

          <div className="tp-blocks">
            {blocks.map((blk) => (
              <div key={blk.id} className="tp-block-card">
                <div className="tp-block-header">
                  <input
                    className="tp-input tp-block-title"
                    value={blk.title}
                    onChange={(e) =>
                      handleUpdateBlockTitle(blk.id, e.target.value)
                    }
                    placeholder="Blocktitel (z.B. Aufwärmen, Sprint …)"
                  />
                  <div className="tp-block-header-right">
                    <button
                      type="button"
                      className="tp-icon-btn"
                      onClick={() => toggleBlockCollapsed(blk.id)}
                    >
                      {collapsedBlocks[blk.id] ? "▸" : "▾"}
                    </button>
                    <label className="tp-label-small">
                      Dauer (min)
                      <input
                        className="tp-input tp-input-small"
                        value={
                          blk.targetDurationMin != null
                            ? String(blk.targetDurationMin)
                            : ""
                        }
                        onChange={(e) =>
                          handleUpdateBlockDuration(blk.id, e.target.value)
                        }
                        placeholder="-"
                      />
                    </label>
                    <button
                      type="button"
                      className="tp-btn tp-btn-danger"
                      onClick={() => handleRemoveBlock(blk.id)}
                    >
                      Block löschen
                    </button>
                  </div>
                </div>
                {!collapsedBlocks[blk.id] && (
                  <div className="tp-block-body">
                  <div className="tp-block-items">
                    {(blk.itemOrder ?? []).map((iid) => {
                      const it = currentDay?.items[iid];
                      if (!it) return null;
                      const t = it.target ?? it.default;
                      return (
                        <div key={iid} className="tp-item-row">
                          <div className="tp-item-main">
                            <div className="tp-item-title">
                              {it.nameCache ?? "Ohne Name"}
                            </div>
                            <div className="tp-item-groups">
                              {it.groupCache?.haupt ?? "—"}
                              {it.groupCache?.unter
                                ? ` / ${it.groupCache.unter}`
                                : ""}
                            </div>
                            <div className="tp-item-comment">
                              <input
                                className="tp-input"
                                value={it.comment ?? ""}
                                onChange={(e) =>
                                  handleUpdateItemComment(iid, e.target.value)
                                }
                                placeholder="Kommentar / Hinweis"
                              />
                            </div>
                          </div>
                          <div className="tp-item-target">
                            <input
                              className="tp-input tp-input-xs"
                              value={
                                t.sets != null && !Number.isNaN(t.sets)
                                  ? String(t.sets)
                                  : ""
                              }
                              onChange={(e) =>
                                handleUpdateItemTarget(iid, {
                                  sets:
                                    e.target.value.trim() === ""
                                      ? null
                                      : Number(
                                          e.target.value.replace(",", ".")
                                        ),
                                })
                              }
                              placeholder="Sätze"
                            />
                            <input
                              className="tp-input tp-input-xs"
                              value={
                                t.reps != null && !Number.isNaN(t.reps)
                                  ? String(t.reps)
                                  : ""
                              }
                              onChange={(e) =>
                                handleUpdateItemTarget(iid, {
                                  reps:
                                    e.target.value.trim() === ""
                                      ? null
                                      : Number(
                                          e.target.value.replace(",", ".")
                                        ),
                                })
                              }
                              placeholder="Wdh."
                            />
                            <input
                              className="tp-input tp-input-xs"
                              value={
                                t.menge != null && !Number.isNaN(t.menge)
                                  ? String(t.menge)
                                  : ""
                              }
                              onChange={(e) =>
                                handleUpdateItemTarget(iid, {
                                  menge:
                                    e.target.value.trim() === ""
                                      ? null
                                      : Number(
                                          e.target.value.replace(",", ".")
                                        ),
                                })
                              }
                              placeholder="Menge"
                            />
                            <input
                              className="tp-input tp-input-xs"
                              value={t.einheit ?? ""}
                              onChange={(e) =>
                                handleUpdateItemTarget(iid, {
                                  einheit:
                                    e.target.value.trim() === ""
                                      ? null
                                      : e.target.value.trim(),
                                })
                              }
                              placeholder="Einheit"
                            />
                            <div className="tp-item-actions">
                              <button
                                type="button"
                                className="tp-btn tp-btn-mini"
                                onClick={() => handleMoveItem(blk.id, iid, -1)}
                                title="nach oben"
                              >
                                ↑
                              </button>
                              <button
                                type="button"
                                className="tp-btn tp-btn-mini"
                                onClick={() => handleMoveItem(blk.id, iid, +1)}
                                title="nach unten"
                              >
                                ↓
                              </button>
                              <button
                                type="button"
                                className="tp-btn tp-btn-mini tp-btn-danger"
                                onClick={() => handleRemoveItem(blk.id, iid)}
                                title="Entfernen"
                              >
                                ✕
                              </button>
                            </div>
                          </div>
                        </div>
                      );
                    })}
                  </div>

                  <div className="tp-block-notes">
                    <label className="tp-label-small">
                      Block-Notizen / Pausen
                      <textarea
                        className="tp-textarea"
                        value={(blk as any).notes ?? ""}
                        onChange={(e) =>
                          handleUpdateBlockNotes(blk.id, e.target.value)
                        }
                        placeholder="z.B. Pausen, Hinweise, Ablauf …"
                      />
                    </label>
                  </div>

                  <div className="tp-block-footer">
                    <button
                      type="button"
                      className="tp-btn"
                      onClick={() => openPickerForBlock(blk.id)}
                    >
                      Übung hinzufügen
                    </button>
                  </div>
                </div>
                )}
              </div>
            ))}
          </div>

          {isBusy && (
            <div className="tp-badge" style={{ marginTop: 8 }}>
              Änderungen werden gespeichert …
            </div>
          )}
        </div>
      )}

      {/* Übungsauswahl als Overlay / Drawer */}
      {pickerOpen && (
        <div className="tp-picker-overlay" onClick={closePicker}>
          <div
            className="tp-picker-dialog"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="tp-picker-header">
              <div className="tp-picker-tabs">
                <button
                  type="button"
                  className={
                    "tp-picker-tab" +
                    (pickerTab === "KATALOG" ? " active" : "")
                  }
                  onClick={() => setPickerTab("KATALOG")}
                >
                  Aus Katalog
                </button>
                <button
                  type="button"
                  className={
                    "tp-picker-tab" +
                    (pickerTab === "MANUAL" ? " active" : "")
                  }
                  onClick={() => setPickerTab("MANUAL")}
                >
                  Manuell
                </button>
              </div>
              <button
                type="button"
                className="tp-btn tp-btn-mini"
                onClick={closePicker}
              >
                ✕
              </button>
            </div>

            {pickerTab === "KATALOG" && (
              <div className="tp-picker-body">
                <div className="tp-picker-filters">
                  <input
                    className="tp-input"
                    placeholder="Suche nach Name / Text"
                    value={searchText}
                    onChange={(e) => setSearchText(e.target.value)}
                  />
                  <select
                    className="tp-input"
                    value={searchHaupt}
                    onChange={(e) => setSearchHaupt(e.target.value)}
                  >
                    <option value="">– Hauptgruppe –</option>
                    {allHauptgruppen.map((h) => (
                      <option key={h} value={h.toLowerCase()}>
                        {h}
                      </option>
                    ))}
                  </select>
                  <select
                    className="tp-input"
                    value={searchUnter}
                    onChange={(e) => setSearchUnter(e.target.value)}
                  >
                    <option value="">– Untergruppe –</option>
                    {allUntergruppen.map((u) => (
                      <option key={u} value={u.toLowerCase()}>
                        {u}
                      </option>
                    ))}
                  </select>
                </div>

                <div className="tp-picker-list">
                  {exerciseLoading && (
                    <div className="tp-info">Übungen werden geladen …</div>
                  )}
                  {!exerciseLoading && filteredExercises.length === 0 && (
                    <div className="tp-info">
                      Keine Übungen mit diesen Filtern gefunden.
                    </div>
                  )}
                  {filteredExercises.map((ex) => (
                    <button
                      key={ex.id}
                      type="button"
                      className="tp-picker-item"
                      onClick={() => handleAddCatalogExercise(ex)}
                    >
                      <div className="tp-picker-item-main">
                        <div className="tp-picker-item-title">{ex.name}</div>
                        <div className="tp-picker-item-groups">
                          {ex.haupt ?? "—"}
                          {ex.unter ? ` / ${ex.unter}` : ""}
                        </div>
                      </div>
                      <div className="tp-picker-item-meta">
                        {ex.reps != null ? `${ex.reps}× ` : ""}
                        {ex.menge != null ? ex.menge : ""}
                        {ex.einheit ? ` ${ex.einheit}` : ""}
                      </div>
                    </button>
                  ))}
                </div>
              </div>
            )}

            {pickerTab === "MANUAL" && (
              <div className="tp-picker-body">
                <div className="tp-picker-manual-grid">
                  <label className="tp-label-small">
                    Name
                    <input
                      className="tp-input"
                      value={manualDraft.name}
                      onChange={(e) =>
                        setManualDraft((prev) => ({
                          ...prev,
                          name: e.target.value,
                        }))
                      }
                    />
                  </label>
                  <label className="tp-label-small">
                    Hauptgruppe
                    <input
                      className="tp-input"
                      value={manualDraft.haupt}
                      onChange={(e) =>
                        setManualDraft((prev) => ({
                          ...prev,
                          haupt: e.target.value,
                        }))
                      }
                    />
                  </label>
                  <label className="tp-label-small">
                    Untergruppe
                    <input
                      className="tp-input"
                      value={manualDraft.unter}
                      onChange={(e) =>
                        setManualDraft((prev) => ({
                          ...prev,
                          unter: e.target.value,
                        }))
                      }
                    />
                  </label>
                  <label className="tp-label-small">
                    Sätze
                    <input
                      className="tp-input"
                      value={manualDraft.reps}
                      onChange={(e) =>
                        setManualDraft((prev) => ({
                          ...prev,
                          reps: e.target.value,
                        }))
                      }
                    />
                  </label>
                  <label className="tp-label-small">
                    Menge
                    <input
                      className="tp-input"
                      value={manualDraft.menge}
                      onChange={(e) =>
                        setManualDraft((prev) => ({
                          ...prev,
                          menge: e.target.value,
                        }))
                      }
                    />
                  </label>
                  <label className="tp-label-small">
                    Einheit
                    <input
                      className="tp-input"
                      value={manualDraft.einheit}
                      onChange={(e) =>
                        setManualDraft((prev) => ({
                          ...prev,
                          einheit: e.target.value,
                        }))
                      }
                    />
                  </label>
                </div>

                <div className="tp-picker-footer">
                  <button
                    type="button"
                    className="tp-btn tp-btn-primary"
                    onClick={handleAddManualExercise}
                  >
                    Übung hinzufügen
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}