
import React, { useState, useEffect } from "react";


type Props = {
  mode: "create" | "edit";
  isOpen: boolean;
  onClose: () => void;
  onCreate?: (name: string) => void;
  onSaveEdit?: (patch: { name: string; inactive?: boolean; generalNote?: string; }) => void;
  person?: { name: string; inactive?: boolean; generalNote?: string; };
};

export default function NamePopup({ mode, isOpen, onClose, onCreate, onSaveEdit, person }: Props){
  const [name, setName] = useState(person?.name || "");
  const [inactive, setInactive] = useState(!!person?.inactive);
  const [paid, setPaid] = useState(person?.paid !== false);
  const [note, setNote] = useState(person?.generalNote || "");

  useEffect(()=>{
    setName(person?.name || "");
    setInactive(!!person?.inactive);
    setPaid(person?.paid !== false);
    setNote(person?.generalNote || "");
  }, [person, isOpen]);

  if(!isOpen) return null;

  const save = () => {
    if(mode === "create"){
      if(name.trim() && onCreate) onCreate(name.trim());
    }else{
      if(onSaveEdit && person) onSaveEdit({ name: person.name, inactive, generalNote: note, paid });
    }
    onClose();
  };

  return (
    <div className="kt-modal-backdrop" onClick={onClose}>
      <div className="kt-modal" onClick={e=>e.stopPropagation()}>
        <div className="kt-modal-header">
          <div>{mode === "create" ? "Neuer Athlet" : "Athlet bearbeiten"}</div>
          <button className="kt-icon-btn" onClick={onClose}>✕</button>
        </div>
        <div className="kt-modal-body">
          {mode === "create" ? (
            <input className="kt-input" placeholder="Name" value={name} onChange={e=>setName(e.target.value)} />
          ) : (
            <div className="kt-popup-body">
              <input
  className="kt-input"
  value={name}
  onChange={(e)=>setName(e.target.value)}
  placeholder="Name"
/>
              <div className="kt-popup-row">
                                <label className="kt-check"><input type="checkbox" checked={!paid} onChange={e=>setPaid(!e.target.checked)} /> nicht bezahlt</label>
              </div>
              
              <textarea
                style={{minHeight:120, width:'100%', border:'1px solid #e5e7eb', borderRadius:10, padding:10}}
                placeholder="Info / Notiz"
                value={note} onChange={e=>setNote(e.target.value)}
              />
            </div>
          )}


          <div style={{display:'flex', gap:8, justifyContent:'flex-end'}}>
 <label style={{display:'flex', alignItems:'center', gap:6}}>
    <input type="checkbox" checked={inactive} onChange={e=>setInactive(e.target.checked)} />
    Inaktiv
  </label>
            <button className="kt-btn kt-btn--secondary" onClick={onClose}>Abbrechen</button>
            <button className="kt-btn kt-btn--primary" onClick={save}>Speichern</button>
          </div>
        </div>
      </div>
    </div>
  );
}
