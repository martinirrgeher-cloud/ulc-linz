
import React from "react";

type Props = {
  year: number;
  weekNumber: number;
  prevWeek: () => void;
  nextWeek: () => void;
};

export default function KTHeader({ year, weekNumber, prevWeek, nextWeek }: Props) {
  return (
    <div className="kt-header calendar-only">
      <div className="kt-calendar-bar">
        <button className="calendar-btn" onClick={prevWeek} aria-label="Vorherige Woche">‹</button>
        <span className="calendar-label">{year} – KW {weekNumber}</span>
        <button className="calendar-btn" onClick={nextWeek} aria-label="Nächste Woche">›</button>
      </div>
    </div>
  );
}
