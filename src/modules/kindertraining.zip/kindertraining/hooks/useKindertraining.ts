
import { useEffect, useMemo, useState } from "react";
import { downloadJson, overwriteJsonContent } from "@/lib/drive/DriveClient";
import { datesForWeekId, getWeekInfo, moveWeek } from "../lib/weekUtils";

export type DayState = true | false | null;

export type Person = {
  name: string;
  paid?: boolean;
  inactive?: boolean;
  generalNote?: string;
};

type AttendanceMap = Record<string, DayState>;
type WeekEntry = {
  attendance: Record<string, AttendanceMap>;
};

type WeekMeta = {
  activeDays?: string[];
  inactiveDays?: Record<string, boolean>;
  dayNotes?: Record<string, string>;
};

type TrainingData = {
  personsByWeek?: Record<string, { name: string; attendance?: AttendanceMap; note?: string; notPaid?: boolean; inactive?: boolean; }[]>;
  __settings__?: {
    activeDays?: string[];
    sortOrder?: "vorname"|"nachname";
    showInactive?: boolean;
  };
  weekMeta?: Record<string, WeekMeta>;
  attendance?: Record<string, WeekEntry>;
};

const defaultData: TrainingData = {
  __settings__: { activeDays: ["Montag","Dienstag","Mittwoch","Donnerstag","Freitag"], sortOrder: "nachname", showInactive: false },
  attendance: {},
  weekMeta: {}
};

const WEEKDAYS = ["Montag","Dienstag","Mittwoch","Donnerstag","Freitag","Samstag","Sonntag"] as const;
type WeekdayName = typeof WEEKDAYS[number];

function weekdayFromIndex(i:number): WeekdayName {
  return WEEKDAYS[i] as WeekdayName;
}

export function useKindertraining(){
  const personsFileId = import.meta.env.VITE_DRIVE_KINDERTRAINING_PERSONEN_FILE_ID;
  const dataFileId = import.meta.env.VITE_DRIVE_KINDERTRAINING_FILE_ID;

  const [persons, setPersons] = useState<Person[]>([]);
  const [data, setData] = useState<TrainingData>(defaultData);
  const [week, setWeek] = useState<string>(getWeekInfo().weekId);
  const [search, setSearch] = useState<string>("");

  useEffect(()=>{
    (async()=>{
      try{
        const p = await downloadJson(personsFileId);
        if(Array.isArray(p)) setPersons(p);
      }catch(e){ console.error("load persons failed", e); }
    })();
  },[personsFileId]);

  useEffect(()=>{
    (async()=>{
      try{
        const d = await downloadJson(dataFileId);
        if(d && typeof d === "object"){
          setData({ ...defaultData, ...d });
        }
      }catch(e){ console.error("load data failed", e); }
    })();
  },[dataFileId]);

  const info = useMemo(()=>datesForWeekId(week), [week]);

  const activeDaysForWeek = useMemo(()=>{
    const wm = data.weekMeta?.[week];
    let names: string[] | undefined = wm?.activeDays;
    if(!names) names = data.__settings?.activeDays;
    if(!names || names.length===0) names = ["Montag","Dienstag","Mittwoch","Donnerstag","Freitag"];
    const items = info.dates.map((dateStr, idx)=>{
      const name = weekdayFromIndex(idx);
      const isActive = names!.includes(name);
      const isInactiveCol = !!(data.weekMeta?.[week]?.inactiveDays?.[dateStr]);
      return { idx, name, dateStr, visible: isActive, disabled: isInactiveCol };
    });
    return items;
  }, [data, week, info]);

  const setActiveDaysForWeek = (names: WeekdayName[]) => {
    const next: TrainingData = { ...data, weekMeta: { ...(data.weekMeta||{}) } };
    next.weekMeta![week] = { ...(next.weekMeta![week]||{}) , activeDays: names as string[] };
    setData(next);
    overwriteJsonContent(dataFileId, next).catch(e=>console.error("save activeDays failed", e));
  };

  const setInactiveForDate = (dateStr: string, value: boolean) => {
    const next: TrainingData = { ...data, weekMeta: { ...(data.weekMeta||{}) } };
    const wm = next.weekMeta![week] = { ...(next.weekMeta![week]||{}) };
    wm.inactiveDays = { ...(wm.inactiveDays||{}) , [dateStr]: value };
    setData(next);
    overwriteJsonContent(dataFileId, next).catch(e=>console.error("save inactiveDays failed", e));
  };

  const getDayNote = (dateStr: string): string => {
    return data.weekMeta?.[week]?.dayNotes?.[dateStr] ?? "";
  };
  const setDayNote = (dateStr: string, text: string) => {
    const next: TrainingData = { ...data, weekMeta: { ...(data.weekMeta||{}) } };
    const wm = next.weekMeta![week] = { ...(next.weekMeta![week]||{}) };
    wm.dayNotes = { ...(wm.dayNotes||{}), [dateStr]: text };
    setData(next);
    overwriteJsonContent(dataFileId, next).catch(e=>console.error("save dayNotes failed", e));
  };

  const getAttendance = (personName: string, dateStr: string): DayState => {
    const w = data.attendance?.[week];
    const state = w?.attendance?.[personName]?.[dateStr];
    if(state === true || state === false || state === null) return state;
    const legacy = data.personsByWeek?.[week]?.find(x=>x.name===personName)?.attendance?.[dateStr];
    return typeof legacy === "boolean" ? legacy : null;
  };

  const setAttendance = (personName: string, dateStr: string, value: DayState) => {
    if (data.weekMeta?.[week]?.inactiveDays?.[dateStr]) return;
    const next: TrainingData = { ...data, attendance: { ...(data.attendance||{}) } };
    const w: WeekEntry = next.attendance![week] = (next.attendance?.[week]) || { attendance: {} };
    const map = w.attendance[personName] = { ...(w.attendance[personName]||{}) };
    map[dateStr] = value;
    setData(next);
    overwriteJsonContent(dataFileId, next).catch(e=>console.error("save attendance failed", e));
  };

  const toggleAttendance = (personName: string, dateStr: string) => {
    const curr = getAttendance(personName, dateStr);
    const next = curr === null ? true : curr === true ? false : null;
    setAttendance(personName, dateStr, next);
  };

  const sortOrder = data.__settings?.sortOrder ?? "nachname";
  const setSortOrder = (v: "vorname"|"nachname") => {
    const next = { ...data, __settings__: { ...(data.__settings||{}), sortOrder: v } };
    setData(next);
    overwriteJsonContent(dataFileId, next).catch(e=>console.error("save sortOrder failed", e));
  };
  const showInactive = data.__settings?.showInactive ?? false;
  const setShowInactive = (v:boolean) => {
    const next = { ...data, __settings__: { ...(data.__settings||{}), showInactive: v } };
    setData(next);
    overwriteJsonContent(dataFileId, next).catch(e=>console.error("save showInactive failed", e));
  };

  const addPerson = async (name: string) => {
    const exists = persons.some(p=>p.name.toLowerCase()===name.toLowerCase());
    if(exists) return;
    const next = [...persons, { name, paid: true, inactive: false, generalNote: "" }];
    setPersons(next);
    try{ await overwriteJsonContent(personsFileId, next); }catch(e){ console.error("save persons failed", e); }
  };

  const updatePerson = async (name: string, patch: Partial<Person>) => {
    const next = persons.map(p => p.name === name ? { ...p, ...patch } : p);
    setPersons(next);
    try{ await overwriteJsonContent(personsFileId, next); }catch(e){ console.error("update person failed", e); }
  };

  const filteredPersons = useMemo(()=>{
    const q = (search||"").trim().toLowerCase();
    let list = persons.map(p=>p);
    if(q){
      list = list.filter(p => p.name.toLowerCase().includes(q));
    }
    list.sort((a,b)=>{
      const ia = !!a.inactive;
      const ib = !!b.inactive;
      if(ia !== ib) return ia ? 1 : -1;
      const getVor = (n:string)=> n.split(" ")[0] || n;
      const getNach = (n:string)=> (n.split(" ").slice(-1)[0]) || n;
      const av = (sortOrder==="nachname") ? getNach(a.name) : getVor(a.name);
      const bv = (sortOrder==="nachname") ? getNach(b.name) : getVor(b.name);
      return av.localeCompare(bv, "de");
    });
    if(!showInactive){
      list = list.filter(p=>!p.inactive);
    }
    return list;
  }, [persons, sortOrder, showInactive, search]);

  return {
    week, info,
    prevWeek: ()=> setWeek(moveWeek(week, -1)),
    nextWeek: ()=> setWeek(moveWeek(week, +1)),

    persons: filteredPersons,
    rawPersons: persons,
    setSearch,

    activeDaysForWeek,
    setActiveDaysForWeek,
    setInactiveForDate,
    getDayNote,
    setDayNote,

    getAttendance,
    toggleAttendance,

    sortOrder, setSortOrder,
    showInactive, setShowInactive,

    addPerson, updatePerson,
  };
}
