import React, { useState, useMemo } from "react";
import { FileIcon, VideoIcon, ImageIcon } from "lucide-react";
import "../styles/Uebungskatalog.css";
import { MediaViewerModal } from "./MediaViewerModal";

interface Uebung {
  id: string;
  name: string;
  haupt?: string | null;
  unter?: string | null;
  reps?: number | null;
  menge?: number | null;
  einheit?: string | null;
  active?: boolean;
  difficulty?: 1 | 2 | 3 | 4 | 5 | null;
  mediaId?: string;
  mediaUrl?: string;
  mediaType?: "image" | "video" | string;
}

const Stars: React.FC<{ value?: number | null }> = ({ value }) => {
  const v = typeof value === "number" ? value : 0;
  const arr = Array.from({ length: 5 });
  return (
    <div className="uk-stars">
      {arr.map((_, i) => (
        <span key={i} className={i < v ? "on" : ""}>
          ★
        </span>
      ))}
    </div>
  );
};

export default function UebungCard({ uebung }: { uebung: Uebung }) {
  const [viewerOpen, setViewerOpen] = useState(false);

  const mediaUrl = useMemo(
    () =>
      uebung.mediaUrl ||
      (uebung.mediaId
        ? `https://drive.google.com/uc?id=${encodeURIComponent(
            uebung.mediaId
          )}&export=download`
        : ""),
    [uebung.mediaUrl, uebung.mediaId]
  );

  const hasMedia = !!(uebung.mediaId || uebung.mediaUrl);

  const mengeEinheit =
    uebung.menge != null && uebung.einheit
      ? `${uebung.menge} ${uebung.einheit}`
      : uebung.menge != null
      ? String(uebung.menge)
      : uebung.einheit ?? "";

  return (
    <div className={"uk-card" + (uebung.active === false ? " inactive" : "")}>
      {/* Erste Zeile: Name + Sterne + Medien-Icon */}
      <div className="uk-head">
        <div className="uk-title">{uebung.name}</div>
        <div className="uk-icons">
          <Stars value={uebung.difficulty ?? null} />
          {hasMedia && (
            <button
              type="button"
              className="uk-media-icon"
              title="Vorschau öffnen"
              onClick={() => setViewerOpen(true)}
            >
              {uebung.mediaType === "video" ? (
                <VideoIcon size={16} />
              ) : uebung.mediaType === "image" ? (
                <ImageIcon size={16} />
              ) : (
                <FileIcon size={16} />
              )}
            </button>
          )}
        </div>
      </div>

      {/* Zweite Zeile: Haupt • Unter • Menge Einheit */}
      <div className="uk-sub">
        {uebung.haupt || "–"} • {uebung.unter || "–"}
        {mengeEinheit && <> • {mengeEinheit}</>}
      </div>

      <MediaViewerModal
        open={viewerOpen}
        onClose={() => setViewerOpen(false)}
        fileId={uebung.mediaId}
        url={mediaUrl}
        name={uebung.name}
        type={uebung.mediaType === "video" ? "video" : "image"}
      />
    </div>
  );
}
