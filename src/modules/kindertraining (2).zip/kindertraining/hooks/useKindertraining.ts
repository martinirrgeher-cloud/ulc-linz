// src/modules/kindertraining/hooks/useKindertraining.ts
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import type { DayKey, Person, Settings, WeekData, WeekId } from "../lib/types";
import { loadPersons, addPerson, renamePerson, setInactive as setInactivePerson, setPaid as setPaidPerson, setGeneralNote as setGeneralNotePerson } from "../services/persons";
import { loadWeekData, toggleAttendance, setDayNote, setInactiveDay } from "../services/weeks";
import { loadSettings, saveSettings } from "../services/settings";
import { datesForISOWeek, getISOWeekId, moveISOWeek } from "../lib/weekUtils";

type State = {
  persons: Person[];
  settings: Settings;
  weekId: WeekId;
  dates: string[];
  week: WeekData;
  busy: boolean;
};

const DEFAULT_SETTINGS: Settings = { activeDays: ["mon","tue","wed","thu","fri"], sortOrder: "nachname", showInactive: false };
const KEYS: DayKey[] = ["mon","tue","wed","thu","fri","sat","sun"];
const NAMES_DE = ["Mo","Di","Mi","Do","Fr","Sa","So"] as const;

export function useKindertraining() {
  const [state, setState] = useState<State>({
    persons: [],
    settings: DEFAULT_SETTINGS,
    weekId: getISOWeekId(new Date()),
    dates: datesForISOWeek(getISOWeekId(new Date())),
    week: { attendanceByPersonId: {} },
    busy: false,
  });

  // debounce timer
  const saveTimer = useRef<number | null>(null);

  // Initial load
  useEffect(() => {
    (async () => {
      setState(s => ({ ...s, busy: true }));
      try {
        const [persons, settings, week] = await Promise.all([
          loadPersons(),
          loadSettings(),
          loadWeekData(state.weekId),
        ]);
        setState(s => ({
          ...s,
          persons,
          settings: settings || DEFAULT_SETTINGS,
          week,
          dates: datesForISOWeek(s.weekId),
        }));
      } finally {
        setState(s => ({ ...s, busy: false }));
      }
    })();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // Navigation
  const goWeek = useCallback(async (dir: -1|0|1) => {
    const target = dir === 0 ? getISOWeekId(new Date()) : moveISOWeek(state.weekId, dir);
    setState(s => ({ ...s, weekId: target, dates: datesForISOWeek(target), busy: true }));
    const week = await loadWeekData(target);
    setState(s => ({ ...s, week, busy: false }));
  }, [state.weekId]);
  const prevWeek = useCallback(() => { void goWeek(-1); }, [goWeek]);
  const nextWeek = useCallback(() => { void goWeek(1); }, [goWeek]);

  // Personen
  const refreshPersons = useCallback(async () => {
    const persons = await loadPersons();
    setState(s => ({ ...s, persons }));
  }, []);

  const addNewPerson = useCallback(async (name: string) => {
    await addPerson(name);
    await refreshPersons();
  }, [refreshPersons]);

  const rename = useCallback(async (id: string, name: string) => {
    await renamePerson(id, name);
    await refreshPersons();
  }, [refreshPersons]);

  const setInactive = useCallback(async (id: string, inactive: boolean) => {
    await setInactivePerson(id, inactive);
    await refreshPersons();
  }, [refreshPersons]);

  const setPaid = useCallback(async (id: string, paid: boolean) => {
    await setPaidPerson(id, paid);
    await refreshPersons();
  }, [refreshPersons]);

  const setGeneralNote = useCallback(async (id: string, note: string) => {
    await setGeneralNotePerson(id, note);
    await refreshPersons();
  }, [refreshPersons]);

  // Attendance/Notes
  const toggle = useCallback(async (personId: string, day: DayKey) => {
    const next = await toggleAttendance(state.weekId, personId, day);
    setState(s => ({ ...s, week: next }));
  }, [state.weekId]);

  const setNote = useCallback(async (isoDate: string, text: string) => {
    const next = await setDayNote(state.weekId, isoDate, text);
    setState(s => ({ ...s, week: next }));
  }, [state.weekId]);

  const setInactiveDayFlag = useCallback(async (isoDate: string, inactive: boolean) => {
    const next = await setInactiveDay(state.weekId, isoDate, inactive);
    setState(s => ({ ...s, week: next }));
  }, [state.weekId]);

  // ---- Settings with optimistic update + debounced persist ----
  const persistSettings = useCallback((next: Settings) => {
    if (saveTimer.current) window.clearTimeout(saveTimer.current);
    // debounce 300ms to batch rapid toggles
    saveTimer.current = window.setTimeout(() => { void saveSettings(next); }, 300);
  }, []);

  const setActiveDaysForWeek = useCallback((keysOrNames: string[]) => {
    // normalize to keys
    const keys = Array.from(new Set(keysOrNames.map(v => {
      const idxK = KEYS.indexOf(v as DayKey);
      if (idxK >= 0) return KEYS[idxK];
      const idxN = NAMES_DE.indexOf(v as any);
      return idxN >= 0 ? KEYS[idxN] : null;
    }).filter(Boolean))) as DayKey[];

    if (!keys.length) return;
    const next: Settings = { ...state.settings, activeDays: keys };
    // optimistic state update (fast UI)
    setState(s => ({ ...s, settings: next }));
    // debounced persist (slow I/O)
    persistSettings(next);
  }, [state.settings, persistSettings]);

  const setSortOrder = useCallback((order: "vorname"|"nachname") => {
    const next = { ...state.settings, sortOrder: order };
    setState(st => ({ ...st, settings: next }));
    persistSettings(next);
  }, [state.settings, persistSettings]);

  const setShowInactive = useCallback((v: boolean) => {
    const next = { ...state.settings, showInactive: v };
    setState(st => ({ ...st, settings: next }));
    persistSettings(next);
  }, [state.settings, persistSettings]);

  // Views
  const visiblePersons = useMemo(() => {
    const showInactive = state.settings.showInactive;
    const order = state.settings.sortOrder;
    const list = state.persons.filter(p => showInactive || !p.inactive);
    if (order === "vorname") return [...list].sort((a,b) => a.name.localeCompare(b.name, "de"));
    const ln = (n: string) => (n.trim().split(/\s+/).pop() || "").toLowerCase();
    return [...list].sort((a,b) => ln(a.name).localeCompare(ln(b.name), "de"));
  }, [state.persons, state.settings.showInactive, state.settings.sortOrder]);

  const activeDaysForWeek = useMemo(() => {
    const keysSet = new Set(state.settings.activeDays);
    const dates = state.dates;
    return dates.map((dateStr, idx) => ({
      idx,
      key: KEYS[idx] as DayKey,
      name: NAMES_DE[idx],
      dateStr,
      visible: keysSet.has(KEYS[idx]),
      disabled: false,
    }));
  }, [state.dates, state.settings.activeDays]);

  return {
    persons: visiblePersons,
    week: state.week,
    weekId: state.weekId,
    info: { year: Number(state.weekId.slice(0,4)), weekNumber: Number(state.weekId.slice(6)) },
    activeDaysForWeek,

    prevWeek, nextWeek,

    addNewPerson, rename, setInactive, setPaid, setGeneralNote,

    getAttendance: (personName: string, dateStr: string) => {
      const p = state.persons.find(x => x.name === personName);
      if (!p) return null;
      const map = state.week.attendanceByPersonId[p.id] || {};
      const dayKey = dateToDayKey(dateStr);
      return !!(map as any)[dayKey];
    },
    toggleAttendance: (personName: string, dateStr: string) => {
      const p = state.persons.find(x => x.name === personName);
      if (!p) return;
      const dayKey = dateToDayKey(dateStr) as any;
      void toggle(p.id, dayKey);
    },
    getDayNote: (dateStr: string) => state.week?.dayNotes?.[dateStr] || "",
    setNote: (dateStr: string, text: string) => { void setNote(dateStr, text); },
    setInactiveForDate: (dateStr: string, inactive: boolean) => { void setInactiveDayFlag(dateStr, inactive); },

    sortOrder: state.settings.sortOrder,
    setSortOrder,
    showInactive: state.settings.showInactive,
    setShowInactive,
    setActiveDaysForWeek,
  };
}

function dateToDayKey(iso: string): DayKey {
  const d = new Date(iso + "T00:00:00");
  const wd = ((d.getDay() + 6) % 7);
  return ["mon","tue","wed","thu","fri","sat","sun"][wd] as DayKey;
}
