// src/modules/kindertraining/services/weeks.ts
import { downloadJson, overwriteJsonContent } from "@/lib/drive/DriveClientCore";
import type { KindertrainingRoot, WeekData, WeekId } from "../lib/types";
import { normalizeRoot, writeBack } from "./mapper";

function getDataFileId(): string {
  const id = import.meta.env.VITE_DRIVE_KINDERTRAINING_DATA_FILE_ID;
  if (!id) throw new Error("VITE_DRIVE_KINDERTRAINING_DATA_FILE_ID fehlt");
  return String(id);
}

async function loadRoot(): Promise<KindertrainingRoot> {
  const json = await downloadJson<any>(getDataFileId()).catch(() => ({}));
  return normalizeRoot(json || {});
}

async function saveRoot(root: KindertrainingRoot): Promise<void> {
  const out = writeBack(root);
  await overwriteJsonContent(getDataFileId(), out);
}

export async function loadWeekData(weekId: WeekId): Promise<WeekData> {
  const root = await loadRoot();
  return root.weeks?.[weekId] || { attendanceByPersonId: {} };
}

/** Patch-Merge Speichern: nur übergebene Felder werden geschrieben. */
export async function saveWeekData(weekId: WeekId, patch: Partial<WeekData>): Promise<WeekData> {
  const root = await loadRoot();
  const prev = root.weeks?.[weekId] || { attendanceByPersonId: {} };
  const next: WeekData = {
    attendanceByPersonId: { ...prev.attendanceByPersonId, ...patch.attendanceByPersonId },
    dayNotes: { ...(prev.dayNotes || {}), ...(patch.dayNotes || {}) },
    inactiveDays: { ...(prev.inactiveDays || {}), ...(patch.inactiveDays || {}) },
    notPaid: { ...(prev.notPaid || {}), ...(patch.notPaid || {}) },
  };
  root.weeks = root.weeks || {};
  root.weeks[weekId] = next;
  await saveRoot(root);
  return next;
}

export async function toggleAttendance(weekId: WeekId, personId: string, dayKey: keyof WeekData["attendanceByPersonId"][string]) {
  const root = await loadRoot();
  const prev = root.weeks?.[weekId] || { attendanceByPersonId: {} };
  const map = { ...prev.attendanceByPersonId };
  const days = { mon:false,tue:false,wed:false,thu:false,fri:false,sat:false,sun:false, ...(map[personId] || {}) };
  days[dayKey] = !days[dayKey];
  map[personId] = days;
  root.weeks = root.weeks || {};
  root.weeks[weekId] = { ...prev, attendanceByPersonId: map };
  await saveRoot(root);
  return root.weeks[weekId];
}

export async function setDayNote(weekId: WeekId, isoDate: string, text: string) {
  const root = await loadRoot();
  const prev = root.weeks?.[weekId] || { attendanceByPersonId: {} };
  const dayNotes = { ...(prev.dayNotes || {}) };
  if (!text) delete dayNotes[isoDate];
  else dayNotes[isoDate] = text;
  root.weeks = root.weeks || {};
  root.weeks[weekId] = { ...prev, dayNotes };
  await saveRoot(root);
  return root.weeks[weekId];
}

export async function setInactiveDay(weekId: WeekId, isoDate: string, inactive: boolean) {
  const root = await loadRoot();
  const prev = root.weeks?.[weekId] || { attendanceByPersonId: {} };
  const inactiveDays = { ...(prev.inactiveDays || {}) };
  if (!inactive) delete inactiveDays[isoDate];
  else inactiveDays[isoDate] = true;
  root.weeks = root.weeks || {};
  root.weeks[weekId] = { ...prev, inactiveDays };
  await saveRoot(root);
  return root.weeks[weekId];
}
