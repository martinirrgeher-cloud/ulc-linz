// src/modules/kindertraining/services/persons.ts
import { downloadJson, overwriteJsonContent } from "@/lib/drive/DriveClientCore";
import type { Person } from "../lib/types";

function getPersonsFileId(): string {
  const id = import.meta.env.VITE_DRIVE_KINDERTRAINING_PERSONEN_FILE_ID;
  if (!id) throw new Error("VITE_DRIVE_KINDERTRAINING_PERSONEN_FILE_ID fehlt");
  return String(id);
}

export async function loadPersons(): Promise<Person[]> {
  const raw = await downloadJson<any>(getPersonsFileId());
  // Akzeptiere { persons: [] } oder [] oder Map
  if (Array.isArray(raw)) {
    return raw.map(toPerson);
  }
  if (raw && Array.isArray(raw.persons)) {
    return raw.persons.map(toPerson);
  }
  if (raw && typeof raw === "object") {
    // map -> array
    return Object.values(raw).map(toPerson);
  }
  return [];
}

export async function savePersons(list: Person[]): Promise<void> {
  // Speichere als Array (stabil)
  await overwriteJsonContent(getPersonsFileId(), list);
}

export async function addPerson(name: string): Promise<Person> {
  const list = await loadPersons();
  const p: Person = { id: crypto.randomUUID(), name: name.trim() };
  list.push(p);
  await savePersons(list);
  return p;
}

export async function renamePerson(id: string, name: string): Promise<void> {
  const list = await loadPersons();
  const idx = list.findIndex(x => x.id === id);
  if (idx >= 0) {
    list[idx] = { ...list[idx], name: name.trim() };
    await savePersons(list);
  }
}

export async function setInactive(id: string, inactive: boolean): Promise<void> {
  const list = await loadPersons();
  const idx = list.findIndex(x => x.id === id);
  if (idx >= 0) {
    list[idx] = { ...list[idx], inactive: !!inactive };
    await savePersons(list);
  }
}

export async function setPaid(id: string, paid: boolean): Promise<void> {
  const list = await loadPersons();
  const idx = list.findIndex(x => x.id === id);
  if (idx >= 0) {
    list[idx] = { ...list[idx], paid: !!paid };
    await savePersons(list);
  }
}

export async function setGeneralNote(id: string, note: string): Promise<void> {
  const list = await loadPersons();
  const idx = list.findIndex(x => x.id === id);
  if (idx >= 0) {
    const clean = note?.trim() || "";
    // leere Notiz entfernen
    if (clean) {
      list[idx] = { ...list[idx], generalNote: clean };
    } else {
      const { generalNote, ...rest } = list[idx] as any;
      list[idx] = rest;
    }
    await savePersons(list);
  }
}

function toPerson(x: any): Person {
  return {
    id: String(x?.id ?? crypto.randomUUID()),
    name: String(x?.name ?? ""),
    inactive: !!x?.inactive,
    paid: !!x?.paid,
    generalNote: x?.generalNote ? String(x.generalNote) : undefined,
  };
}
