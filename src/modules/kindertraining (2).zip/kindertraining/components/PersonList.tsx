import React, { useState } from "react";

type Person = {
  name: string;
  inactive?: boolean;
  paid?: boolean;
  generalNote?: string;
};

type Props = {
  persons: Person[];
  visibleDays?: string[];
  getAttendance: (p: string, d: string) => boolean | undefined;
  toggleAttendance: (p: string, d: string) => void;
  onClickName: (p: Person) => void;
  nameColWidth: number;
  inactiveDays: Record<string, boolean>;
  setInactiveForDate: (d: string, val: boolean) => void;
  currentWeek: string; // z. B. "2025-KW44"
};

export default function PersonList({
  persons,
  visibleDays = [],
  getAttendance,
  toggleAttendance,
  onClickName,
  nameColWidth,
  inactiveDays,
  setInactiveForDate,
  currentWeek,
}: Props) {
  const [activeDayNote, setActiveDayNote] = useState<string | null>(null);
  const [noteText, setNoteText] = useState("");
  const [saving, setSaving] = useState(false);

  // === Notiz öffnen (Popup anzeigen + Text aus JSON laden) ===
  async function openDayNote(day: string) {
    try {
      const fileId = import.meta.env.VITE_DRIVE_KINDERTRAINING_FILE_ID;
      const data = await downloadJson(fileId);
      const text =
        data?.weekMeta?.[currentWeek]?.dayNotes?.[day] ?? "";
      setNoteText(text);
      setActiveDayNote(day);
    } catch (err) {
      console.error("Fehler beim Laden der Notiz:", err);
    }
  }

  // === Notiz speichern ===
  async function saveDayNote() {
    if (!activeDayNote) return;
    setSaving(true);
    try {
      const fileId = import.meta.env.VITE_DRIVE_KINDERTRAINING_FILE_ID;
      const data = await downloadJson(fileId);

      if (!data.weekMeta) data.weekMeta = {};
      if (!data.weekMeta[currentWeek]) data.weekMeta[currentWeek] = {};
      if (!data.weekMeta[currentWeek].dayNotes)
        data.weekMeta[currentWeek].dayNotes = {};

      data.weekMeta[currentWeek].dayNotes[activeDayNote] = noteText;

      await overwriteJsonContent(fileId, data);
      console.log("✅ Notiz gespeichert:", currentWeek, activeDayNote);
      setActiveDayNote(null);
    } catch (err) {
      console.error("❌ Fehler beim Speichern der Notiz:", err);
    } finally {
      setSaving(false);
    }
  }

  return (
    <div
      className="kt-person-table"
      style={{
        gridTemplateColumns: `${nameColWidth}px repeat(${visibleDays.length}, 56px)`,
      }}
    >
      {/* Kopfzeile */}
      <div
        className="kt-person-row header"
        style={{
          gridTemplateColumns: `${nameColWidth}px repeat(${visibleDays.length}, 56px)`,
        }}
      >
        <div className="kt-cell kt-cell--name"></div>
        {visibleDays.map((d) => {
          const dateObj = new Date(d);
          const weekday = dateObj
            .toLocaleDateString("de-DE", { weekday: "short" })
            .slice(0, 2);
          const dateNum = dateObj
            .toLocaleDateString("de-DE", { day: "2-digit", month: "2-digit" });
          return (
            <div key={d} className="kt-cell kt-cell--day">
              {/* Checkbox „inaktiv“ */}
              <input
                type="checkbox"
                checked={inactiveDays[d] || false}
                onChange={(e) => {
                  setInactiveForDate(d, e.target.checked);
                  if (e.target.checked) openDayNote(d); // automatisch öffnen
                }}
                title="Trainingstag deaktivieren"
              />
              {/* Datum */}
              <div className="kt-day-date">{dateNum}</div>
              {/* Wochentag */}
              <div className="kt-day-short">{weekday}</div>
              {/* Notizsymbol */}
              <button
                className="kt-icon-note"
                title="Notiz für diesen Tag"
                onClick={() => openDayNote(d)}
              >
                📝
              </button>
            </div>
          );
        })}
      </div>

      {/* Personenzeilen */}
      {persons.map((p) => {
        const rowCls = `kt-person-row${p.inactive ? " inactive" : ""}`;
        return (
          <div
            key={p.name}
            className={rowCls}
            style={{
              gridTemplateColumns: `${nameColWidth}px repeat(${visibleDays.length}, 56px)`,
            }}
          >
            <button
              className="kt-cell kt-cell--name"
              onClick={() => onClickName(p)}
              title="Details anzeigen / bearbeiten"
            >
              <>
                <span className="kt-name-prefix">
                  {p.paid === false ? (
                    <span className="kt-icon-euro" title="nicht bezahlt">
                      €
                    </span>
                  ) : null}
                </span>
                <span className="kt-name-text">{p.name}</span>
                <span className="kt-name-suffix">
                  {p.generalNote && p.generalNote.trim() !== "" ? (
                    <span
                      className="kt-icon-note"
                      title="Info/Notiz vorhanden"
                    >
                      ✏️
                    </span>
                  ) : null}
                </span>
              </>
            </button>

            {visibleDays.map((d) => {
              const inactiveDay = inactiveDays[d];
              const checked = getAttendance(p.name, d);
              return (
                <div
                  key={d}
                  className={`kt-cell kt-cell--check${
                    inactiveDay ? " day-inactive" : ""
                  }`}
                >
                  {!inactiveDay && (
                    <input
                      type="checkbox"
                      checked={!!checked}
                      onChange={() => toggleAttendance(p.name, d)}
                    />
                  )}
                </div>
              );
            })}
          </div>
        );
      })}

      {/* Notiz-Popup */}
      {activeDayNote && (
        <div
          className="kt-modal-backdrop"
          onClick={() => setActiveDayNote(null)}
        >
          <div
            className="kt-modal"
            onClick={(e) => e.stopPropagation()}
            style={{ textAlign: "left" }}
          >
            <div className="kt-modal-header">
              <span>
                Notiz für{" "}
                {new Date(activeDayNote).toLocaleDateString("de-DE", {
                  weekday: "long",
                  day: "2-digit",
                  month: "2-digit",
                })}
              </span>
              <button
                className="kt-btn kt-btn--secondary"
                onClick={() => setActiveDayNote(null)}
              >
                ✕
              </button>
            </div>
            <textarea
              placeholder="Notiz eingeben …"
              rows={4}
              value={noteText}
              onChange={(e) => setNoteText(e.target.value)}
              style={{
                width: "100%",
                border: "1px solid #dadada",
                borderRadius: "8px",
                padding: "8px",
                fontFamily: "inherit",
              }}
            ></textarea>
            <div style={{ textAlign: "right", marginTop: "10px" }}>
              <button
                className="kt-btn kt-btn--primary"
                disabled={saving}
                onClick={saveDayNote}
              >
                {saving ? "Speichern…" : "Speichern"}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
