import { useEffect, useState } from "react";
import DriveClientCore from "@/lib/drive/DriveClientCore";

export type GruppenMap = { [hauptgruppe: string]: string[] };

export function useUebungsgruppenPflege(fileId: string) {
  const [gruppen, setGruppen] = useState<GruppenMap>({});
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    let mounted = true;
    (async () => {
      try {
        setLoading(true);
        const data = await DriveClientCore.downloadJson<GruppenMap>(fileId);
        if (mounted) setGruppen(data || {});
      } catch (e: any) {
        if (mounted) setError(e?.message ?? String(e));
      } finally {
        if (mounted) setLoading(false);
      }
    })();
    return () => { mounted = false; };
  }, [fileId]);

  const save = async (next: GruppenMap) => {
    await DriveClientCore.overwriteJsonContent<GruppenMap>(fileId, next);
    setGruppen(next);
  };

  return { gruppen, setGruppen, save, loading, error };
}
