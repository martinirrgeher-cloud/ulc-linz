import React from "react";
import { buildMediaUrl } from "../services/mediaUrl";

export type MediaItem = { fileId: string; mimeType?: string; title?: string };

type Props = {
  isOpen: boolean;
  onClose: () => void;
  item?: MediaItem;
};

export function MediaViewerModal({ isOpen, onClose, item }: Props) {
  if (!isOpen || !item?.fileId) return null;

  const src = buildMediaUrl(item.fileId);
  const isVideo = item.mimeType?.startsWith("video/");

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60" onClick={onClose}>
      <div className="bg-white rounded-xl p-4 max-w-[90vw] max-h-[90vh]" onClick={(e) => e.stopPropagation()}>
        <div className="flex justify-between items-center mb-3">
          <h3 className="font-semibold">{item.title || "Medienvorschau"}</h3>
          <button onClick={onClose} aria-label="Close" className="px-3 py-1 border rounded">Schließen</button>
        </div>
        <div className="flex items-center justify-center">
          {isVideo ? (
            <video src={src} controls style={{ maxWidth: "85vw", maxHeight: "75vh" }} />
          ) : (
            <img src={src} alt={item.title || "media"} style={{ maxWidth: "85vw", maxHeight: "75vh" }} />
          )}
        </div>
      </div>
    </div>
  );
}
