export function buildMediaUrl(fileId: string): string {
  if (!fileId) return "";
  return `https://drive.google.com/uc?export=download&id=${fileId}`;
}

const mediaUrl = buildMediaUrl;
export default mediaUrl;
