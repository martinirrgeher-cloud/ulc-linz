import React, { createContext, useContext, useMemo, useState, useCallback, ReactNode } from "react";


export type AuthUser = { id: string; name: string; username?: string; email?: string; roles?: string[]; modules?: string[]; };


export type AuthContextValue = {
  user: AuthUser | null;
  login: (user: AuthUser) => Promise<void>;
  /** Alias für Bestands-Code */
  loginUser: (user: AuthUser) => Promise<void>;
  logout: () => void;
  /** Bestands-Code erwartet das */
  hasModules: () => boolean;
};

const AuthContext = createContext<AuthContextValue | undefined>(undefined);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<AuthUser | null>(null);

  const login = useCallback(async (u: AuthUser) => {
    setUser({ ...u, username: u.username ?? u.name });
  }, []);

  const loginUser = login;

  const logout = useCallback(() => {
    setUser(null);
  }, []);

  const hasModules = useCallback(() => !!(user?.modules && user.modules.length > 0), [user]);

  const value = useMemo<AuthContextValue>(() => ({ user, login, loginUser, logout, hasModules }), [user, login, logout, hasModules]);

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth(): AuthContextValue {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error("useAuth must be used within AuthProvider");
  return ctx;
}
