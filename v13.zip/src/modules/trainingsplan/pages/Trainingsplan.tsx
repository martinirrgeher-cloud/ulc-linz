import { useState, useEffect } from "react";
import styles from "../styles/Trainingsplan.module.css";
import PlanEditor from "../components/PlanEditor";
import { useTrainingsplan } from "../hooks/useTrainingsplan";
import { getCurrentWeek } from "@/lib/dateUtils";

export default function Trainingsplan() {
  const [selectedAthlet, setSelectedAthlet] = useState<string>("");
  const [selectedKW, setSelectedKW] = useState<number>(getCurrentWeek());
  const [jahr] = useState<number>(new Date().getFullYear());
  const { loadPlan, plan, createNewPlan, copyFromPreviousWeek } = useTrainingsplan();

  useEffect(() => {
    if (selectedAthlet) {
      loadPlan(selectedAthlet, selectedKW, jahr);
    }
  }, [selectedAthlet, selectedKW]);

  return (
    <div className={styles.container}>
      <header className={styles.header}>
        <button className={styles.homeButton}>🏠</button>
        <h1>Trainingsplan</h1>
        <button className={styles.settingsButton}>⚙️</button>
      </header>

      <div className={styles.selector}>
        <select
          value={selectedAthlet}
          onChange={(e) => setSelectedAthlet(e.target.value)}
        >
          <option value="">Athlet auswählen</option>
          <option value="a123">Max Mustermann</option>
        </select>

        <select
          value={selectedKW}
          onChange={(e) => setSelectedKW(Number(e.target.value))}
        >
          {Array.from({ length: 52 }, (_, i) => i + 1).map((kw) => (
            <option key={kw} value={kw}>
              KW {kw}
            </option>
          ))}
        </select>
      </div>

      {selectedAthlet && (
        <>
          <div className={styles.toolbar}>
            <button onClick={() => createNewPlan(selectedAthlet, selectedKW, jahr)}>
              Neuer Plan
            </button>
            <button onClick={() => copyFromPreviousWeek(selectedAthlet, selectedKW, jahr)}>
              Vorlage übernehmen
            </button>
          </div>

          <PlanEditor plan={plan} athletId={selectedAthlet} kw={selectedKW} jahr={jahr} />
        </>
      )}
    </div>
  );
}
