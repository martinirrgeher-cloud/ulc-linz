import { useState } from "react";
import { downloadJson, uploadJson } from "@/lib/drive/DriveClient";

const FOLDER_ID = import.meta.env.VITE_DRIVE_TRAININGSPLAENE_FOLDER_ID;

export function useTrainingsplan() {
  const [plan, setPlan] = useState<any>(null);

  const getFilename = (athletId: string, kw: number, jahr: number) =>
    `${athletId}_kw${kw}_${jahr}.json`;

  const loadPlan = async (athletId: string, kw: number, jahr: number) => {
    const filename = getFilename(athletId, kw, jahr);
    try {
      const data = await downloadJson(FOLDER_ID, filename);
      setPlan(data);
    } catch {
      setPlan(null);
    }
  };

  const savePlan = async (athletId: string, kw: number, jahr: number, data: any) => {
    const filename = getFilename(athletId, kw, jahr);
    await uploadJson(FOLDER_ID, filename, data);
    setPlan(data);
  };

  const createNewPlan = (athletId: string, kw: number, jahr: number) => {
    const newPlan = {
      athletId,
      kw,
      jahr,
      tage: [],
      erstelltAm: new Date().toISOString(),
    };
    setPlan(newPlan);
  };

  const copyFromPreviousWeek = async (athletId: string, kw: number, jahr: number) => {
    const prevKW = kw - 1;
    if (prevKW <= 0) return;
    const filename = getFilename(athletId, prevKW, jahr);
    try {
      const prevData = await downloadJson(FOLDER_ID, filename);
      const copy = { ...prevData, kw, erstelltAm: new Date().toISOString() };
      setPlan(copy);
    } catch {
      console.warn("Keine Vorlage gefunden");
    }
  };

  return { plan, loadPlan, savePlan, createNewPlan, copyFromPreviousWeek };
}
