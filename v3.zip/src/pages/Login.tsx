// src/pages/Login.tsx
import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { validateUser } from "../lib/users";
import { hasAccessToken } from "../lib/googleAuth";

export default function Login({ onLogin }: { onLogin: (user: any) => void }) {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const navigate = useNavigate();

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    const user = await validateUser(username, password);
    if (user) {
      onLogin(user);
      navigate("/menu");
    } else {
      setError("❌ Benutzername oder Passwort falsch");
    }
  }

  async function tryAutoLogin() {
    if (hasAccessToken()) {
      // Falls schon ein Token vorhanden ist, Benutzer auslesen
      const allUsers = await validateUser(username, password);
      if (allUsers) {
        onLogin(allUsers);
        navigate("/menu");
      }
    }
  }

  return (
    <div className="container card" style={{ maxWidth: 400 }}>
      <h1>🔐 Login</h1>
      {error && <p style={{ color: "red" }}>{error}</p>}
      <form onSubmit={handleSubmit}>
        <label>Benutzername</label>
        <input value={username} onChange={(e) => setUsername(e.target.value)} />
        <label>Passwort</label>
        <input type="password" value={password} onChange={(e) => setPassword(e.target.value)} />
        <button type="submit">Anmelden</button>
      </form>
    </div>
  );
}
