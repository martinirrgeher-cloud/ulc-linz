import React, { useEffect, useState } from "react";
import { initGoogleAuth } from "@/lib/googleAuth";
import { useAuth } from "@/store/AuthContext";

export default function Login1() {
  const { loginGoogle } = useAuth();
  const [ready, setReady] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    initGoogleAuth()
      .then(() => {
        setReady(true);
      })
      .catch((err) => {
        console.error("Google Auth konnte nicht initialisiert werden:", err);
        setError("Fehler bei der Google-Initialisierung");
      });
  }, []);

  const handleLogin = async () => {
    try {
      console.log("Google Login Button geklickt");
      await loginGoogle();
    } catch (err) {
      console.error("Fehler beim Google Login:", err);
      setError("Fehler beim Google Login");
    }
  };

  return (
    <div className="login-page">
      <h1>ULC Linz Login</h1>

      {!ready && !error && <p>Lade Google Login ...</p>}
      {error && <p style={{ color: "red" }}>{error}</p>}

      <button
        onClick={handleLogin}
        disabled={!ready}
        className="google-login-button"
        style={{
          padding: "12px 20px",
          fontSize: "16px",
          borderRadius: "8px",
          border: "1px solid #ccc",
          cursor: ready ? "pointer" : "not-allowed",
          opacity: ready ? 1 : 0.5,
        }}
      >
        Mit Google anmelden
      </button>
    </div>
  );
}
