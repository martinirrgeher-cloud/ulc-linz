// src/pages/MainMenu.tsx
import { Link } from "react-router-dom";
import { clearAccessToken } from "../lib/googleAuth";

export default function MainMenu({ user, onLogout }: { user: any; onLogout: () => void }) {
  return (
    <div className="container card" style={{ maxWidth: 600 }}>
      <h1>🏠 Hauptmenü</h1>
      <p>Angemeldet als <strong>{user.username}</strong> ({user.role})</p>
      <div className="button-group">
        {user.modules?.includes("Kindertraining") && (
          <Link to="/kindertraining" className="ghost big">🏃 Kindertraining</Link>
        )}
        {user.modules?.includes("Statistik") && (
          <Link to="/kindertraining/statistik" className="ghost big">📊 Statistik</Link>
        )}
        {user.modules?.includes("Wochentage") && (
          <Link to="/kindertraining/wochentage" className="ghost big">🗓️ Wochentage</Link>
        )}
      </div>
      <div style={{ marginTop: 20 }}>
        <button onClick={() => { clearAccessToken(); onLogout(); }}>🚪 Logout</button>
      </div>
    </div>
  );
}
