/// <reference types="vite/client" />
/// <reference types="google.accounts" />
