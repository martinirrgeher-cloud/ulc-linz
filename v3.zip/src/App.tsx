// src/App.tsx
import { useEffect, useState } from "react";
import { BrowserRouter as Router, Routes, Route, Navigate } from "react-router-dom";
import Login from "./pages/Login";
import MainMenu from "./pages/MainMenu";
import Kindertraining from "./modules/Kindertraining/Kindertraining";
import Statistik from "./modules/Kindertraining/Statistik";
import Wochentage from "./modules/Kindertraining/Wochentage";
import { hasAccessToken, restoreAccessToken, getUserInfo } from "./lib/googleAuth";
import { loadUsers } from "./lib/users";
import "./styles/global.css";

export default function App() {
  const [currentUser, setCurrentUser] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  // 🔐 User automatisch wiederherstellen
  useEffect(() => {
    async function restoreUser() {
      try {
        // 1. User aus localStorage laden
        const saved = localStorage.getItem("currentUser");
        if (saved) {
          setCurrentUser(JSON.parse(saved));
          setLoading(false);
          return;
        }

        // 2. Falls kein saved User, aber Google Token vorhanden
        restoreAccessToken();
        if (hasAccessToken()) {
          const info = await getUserInfo();               // z.B. { email: "...", name: "..." }
          const users = await loadUsers();                // users.json laden
          const match = users.find(
            (u) => u.username?.toLowerCase() === info.email?.toLowerCase()
          );
          if (match) {
            setCurrentUser(match);
            localStorage.setItem("currentUser", JSON.stringify(match));
          }
        }
      } catch (err) {
        console.error("❌ Fehler beim automatischen Login:", err);
      } finally {
        setLoading(false);
      }
    }

    restoreUser();
  }, []);

  // 🧽 Logout
  const handleLogout = () => {
    setCurrentUser(null);
    localStorage.removeItem("currentUser");
  };

  if (loading) {
    return <div style={{ padding: 20 }}>🔄 Lade…</div>;
  }

  return (
    <Router>
      <Routes>
        {/* Login */}
        <Route
          path="/"
          element={
            !currentUser ? (
              <Login onLogin={setCurrentUser} />
            ) : (
              <Navigate to="/menu" replace />
            )
          }
        />

        {/* Hauptmenü */}
        <Route
          path="/menu"
          element={
            currentUser ? (
              <MainMenu user={currentUser} onLogout={handleLogout} />
            ) : (
              <Navigate to="/" replace />
            )
          }
        />

        {/* Module */}
        {currentUser?.modules?.includes("Kindertraining") && (
          <Route path="/kindertraining" element={<Kindertraining />} />
        )}
        {currentUser?.modules?.includes("Statistik") && (
          <Route path="/kindertraining/statistik" element={<Statistik />} />
        )}
        {currentUser?.modules?.includes("Wochentage") && (
          <Route path="/kindertraining/wochentage" element={<Wochentage />} />
        )}

        {/* Fallback */}
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </Router>
  );
}
