// src/lib/googleAuth.ts

let accessToken: string | null = null;

export function initGoogleAuth() {
  if (window.google?.accounts?.oauth2) {
    (window as any).tokenClient = google.accounts.oauth2.initTokenClient({
      client_id: import.meta.env.VITE_GOOGLE_CLIENT_ID,
      scope: "https://www.googleapis.com/auth/drive.file",
      callback: (resp: any) => {
        if (resp.error) {
          console.error("❌ Google Auth Error:", resp);
          return;
        }
        accessToken = resp.access_token;
        localStorage.setItem("gAccessToken", accessToken);
        window.location.reload();
      },
    });
  } else {
    console.warn("⚠️ Google OAuth2 Client nicht geladen");
  }
}

export function signInWithGoogle() {
  if (!(window as any).tokenClient) initGoogleAuth();
  (window as any).tokenClient.requestAccessToken();
}

export function getAccessToken() {
  if (!accessToken) {
    accessToken = localStorage.getItem("gAccessToken");
  }
  return accessToken;
}

export function hasAccessToken() {
  return !!getAccessToken();
}

export function clearAccessToken() {
  accessToken = null;
  localStorage.removeItem("gAccessToken");
}

/**
 * 🔁 Versucht, einen bereits gespeicherten Access Token zu laden,
 * ohne einen neuen Login auszulösen.
 */
export function restoreAccessToken() {
  const stored = localStorage.getItem("gAccessToken");
  if (stored) {
    accessToken = stored;
  }
}

/**
 * 📧 Google User Info laden (Mail-Adresse etc.)
 */
export async function getUserInfo() {
  const token = getAccessToken();
  if (!token) throw new Error("Kein Access Token vorhanden");

  const response = await fetch("https://www.googleapis.com/oauth2/v3/userinfo", {
    headers: { Authorization: `Bearer ${token}` },
  });

  if (!response.ok) {
    throw new Error("Fehler beim Laden der User Info");
  }

  return await response.json();
}
