// src/lib/users.ts
import { loadJsonByName } from "./googleDrive";
import { hasAccessToken, signInWithGoogle } from "./googleAuth";

export interface User {
  username: string;
  password: string;
  role: "admin" | "trainer" | "athlet";
  modules?: string[];
}

async function ensureAccessToken() {
  if (!hasAccessToken()) {
    console.log("🔐 Kein Token vorhanden – starte Google Login…");
    await signInWithGoogle();
  }
}

/**
 * Benutzerliste aus users.json laden
 */
export async function loadUsers(): Promise<User[]> {
  await ensureAccessToken();
  const data = await loadJsonByName("users.json");
  if (Array.isArray(data)) return data as User[];
  if (data && Array.isArray(data.users)) return data.users as User[];
  console.warn("⚠️ users.json hat ein unerwartetes Format");
  return [];
}

/**
 * Benutzername und Passwort validieren
 */
export async function validateUser(username: string, password: string) {
  const users = await loadUsers();
  return users.find(
    (u) => u.username === username && u.password === password
  ) || null;
}
