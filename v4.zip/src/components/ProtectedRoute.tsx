// src/components/ProtectedRoute.tsx
import { Navigate } from "react-router-dom";
import { ROUTES } from "../routes";
import { isLoggedIn, hasModuleAccess } from "../lib/authStore";

interface ProtectedRouteProps {
  children: React.ReactNode;
  module?: string; // optional
}

export default function ProtectedRoute({ children, module }: ProtectedRouteProps) {
  if (!isLoggedIn()) {
    return <Navigate to={ROUTES.LOGIN} replace />;
  }

  if (module && !hasModuleAccess(module)) {
    return <Navigate to={ROUTES.MENU} replace />;
  }

  return <>{children}</>;
}
