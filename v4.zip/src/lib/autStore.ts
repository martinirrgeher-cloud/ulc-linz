// src/lib/authStore.ts
import { User } from "./users";

/**
 * Liefert den aktuell eingeloggten User aus dem LocalStorage.
 */
export function getCurrentUser(): User | null {
  const stored = localStorage.getItem("currentUser");
  return stored ? (JSON.parse(stored) as User) : null;
}

/**
 * Prüft, ob ein Benutzer eingeloggt ist.
 */
export function isLoggedIn(): boolean {
  return !!getCurrentUser();
}

/**
 * Prüft, ob der Benutzer Zugriff auf ein bestimmtes Modul hat.
 * Admins dürfen immer alles.
 */
export function hasModuleAccess(moduleName: string): boolean {
  const user = getCurrentUser();
  if (!user) return false;
  if (user.role === "admin") return true;
  return user.modules?.includes(moduleName) ?? false;
}

/**
 * Loggt den Benutzer aus, indem der gespeicherte User entfernt wird.
 */
export function logout() {
  localStorage.removeItem("currentUser");
}
