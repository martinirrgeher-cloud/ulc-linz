export default function PlanErstellen() {
  return (
    <div>
      <h1 className="text-xl font-semibold mb-2">Plan erstellen</h1>
      <p className="text-sm text-gray-600">Wochenpläne zusammenstellen.</p>
    </div>
  )
}
