export default function MeineTeilnahme() {
  return (
    <div>
      <h1 className="text-xl font-semibold mb-2">Meine Teilnahme</h1>
      <p className="text-sm text-gray-600">Status pro Trainingstag festlegen.</p>
    </div>
  )
}
