// src/pages/MainMenu.tsx
import { Link, useNavigate } from "react-router-dom";
import { ROUTES } from "../routes";
import { getCurrentUser, logout } from "../lib/authStore";

export default function MainMenu() {
  const navigate = useNavigate();
  const user = getCurrentUser();

  const handleLogout = () => {
    logout();
    navigate(ROUTES.LOGIN);
  };

  if (!user) return null;

  return (
    <div className="container" style={{ display: "flex", flexDirection: "column", gap: 12 }}>
      <h1>🏠 Hauptmenü</h1>
      <div>👤 {user.username} ({user.role})</div>

      <nav style={{ display: "flex", flexDirection: "column", gap: 8 }}>
        {user.modules?.includes("KINDERTRAINING") && (
          <Link to={ROUTES.KINDERTRAINING}>🏃 Kindertraining</Link>
        )}
        {user.modules?.includes("U12") && <Link to={ROUTES.U12}>👶 U12</Link>}
        {user.modules?.includes("U14") && <Link to={ROUTES.U14}>🏃‍♂️ U14</Link>}
        {user.modules?.includes("LEISTUNGSGRUPPE") && (
          <Link to={ROUTES.LEISTUNGSGRUPPE}>🏋️ Leistungsgruppe</Link>
        )}
        {user.role === "admin" && <div>⚙️ Adminbereich</div>}
      </nav>

      <button onClick={handleLogout}>🚪 Logout</button>
    </div>
  );
}
