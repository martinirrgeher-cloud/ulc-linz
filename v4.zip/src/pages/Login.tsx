// src/pages/Login.tsx
import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { ROUTES } from "../routes";
import { validateUser } from "../lib/users";

export default function Login() {
  const navigate = useNavigate();
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");

    const user = await validateUser(username, password);
    if (!user) {
      setError("❌ Benutzername oder Passwort ist ungültig");
      return;
    }

    // User speichern (z.B. in localStorage)
    localStorage.setItem("currentUser", JSON.stringify(user));

    navigate(ROUTES.MENU);
  };

  return (
    <div className="container" style={{ maxWidth: 400, margin: "0 auto" }}>
      <h1>🔐 Login</h1>
      <form onSubmit={handleLogin} style={{ display: "flex", flexDirection: "column", gap: 8 }}>
        <input
          type="text"
          placeholder="Benutzername"
          value={username}
          onChange={(e) => setUsername(e.target.value)}
        />
        <input
          type="password"
          placeholder="Passwort"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
        />
        {error && <div style={{ color: "red" }}>{error}</div>}
        <button type="submit">Anmelden</button>
      </form>
    </div>
  );
}
