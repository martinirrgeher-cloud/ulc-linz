// src/lib/authStore.ts
import { forceLogout } from "./googleAuth";

export type Role = "admin" | "trainer" | "athlet";
export interface CurrentUser {
  username: string;
  role: Role;
  modules?: string[];
}

const USER_KEY = "current_user";

export function setCurrentUser(user: CurrentUser) {
  localStorage.setItem(USER_KEY, JSON.stringify(user));
}

export function getCurrentUser(): CurrentUser | null {
  const raw = localStorage.getItem(USER_KEY);
  if (!raw) return null;
  try {
    return JSON.parse(raw) as CurrentUser;
  } catch {
    return null;
  }
}

export function clearCurrentUser() {
  localStorage.removeItem(USER_KEY);
}

export function logout() {
  clearCurrentUser();
  forceLogout();
  window.location.href = "/login";
}
