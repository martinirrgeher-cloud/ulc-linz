// src/lib/googleAuth.ts
let accessToken: string | null = null;
let tokenExpiry: number | null = null;

const CLIENT_ID = import.meta.env.VITE_GOOGLE_CLIENT_ID;
const SCOPES = "https://www.googleapis.com/auth/drive.appdata";

export function getAccessToken() {
  return accessToken;
}

export function isTokenValid() {
  return accessToken && tokenExpiry && Date.now() < tokenExpiry;
}

export function clearAccessToken() {
  accessToken = null;
  tokenExpiry = null;
  localStorage.removeItem("google_access_token");
  localStorage.removeItem("google_expiry");
}

export function restoreAccessToken() {
  const stored = localStorage.getItem("google_access_token");
  const exp = localStorage.getItem("google_expiry");
  if (stored && exp && Date.now() < Number(exp)) {
    accessToken = stored;
    tokenExpiry = Number(exp);
    console.log("🔐 Token wiederhergestellt");
    return true;
  }
  clearAccessToken();
  return false;
}

export function saveAccessToken(token: string, expiresIn: number) {
  accessToken = token;
  tokenExpiry = Date.now() + expiresIn * 1000;
  localStorage.setItem("google_access_token", token);
  localStorage.setItem("google_expiry", tokenExpiry.toString());
  console.log("🔐 Token gespeichert, gültig bis:", new Date(tokenExpiry).toLocaleTimeString());
}

export function startGoogleLogin() {
  const redirectUri = `${window.location.origin}/auth/callback`;
  const authUrl = `https://accounts.google.com/o/oauth2/v2/auth?` +
    `client_id=${encodeURIComponent(CLIENT_ID)}` +
    `&redirect_uri=${encodeURIComponent(redirectUri)}` +
    `&response_type=token` +
    `&scope=${encodeURIComponent(SCOPES)}` +
    `&include_granted_scopes=true` +
    `&prompt=consent`;

  window.location.href = authUrl;
}

export function handleGoogleRedirectCallback() {
  if (window.location.hash.includes("access_token")) {
    const params = new URLSearchParams(window.location.hash.substring(1));
    const token = params.get("access_token");
    const expiresIn = parseInt(params.get("expires_in") || "3600", 10);

    if (token) {
      saveAccessToken(token, expiresIn);
      // Danach leiten wir zum Hauptmenü weiter
      window.location.replace("/");
      return true;
    }
  }
  return false;
}
