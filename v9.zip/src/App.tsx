// src/App.tsx
import { useEffect } from "react";
import { BrowserRouter as Router, Routes, Route, Navigate } from "react-router-dom";
import { restoreAccessToken } from "./lib/googleAuth";
import ProtectedRoute from "./components/ProtectedRoute";
import { ROUTES } from "./routes";

// Seiten
import Login from "./pages/Login";
import AuthCallback from "./pages/AuthCallback";
import MainMenu from "./pages/MainMenu";

// Module
import Kindertraining from "./modules/Kindertraining/Kindertraining";
import U12 from "./modules/U12/U12";
import U14 from "./modules/U14/U14";
import Leistungsgruppe from "./modules/Leistungsgruppe/Leistungsgruppe";

export default function App() {
  useEffect(() => {
    // Token aus LocalStorage laden, wenn vorhanden
    restoreAccessToken();
  }, []);

  return (
    <Router>
      <Routes>
        {/* Login ungeschützt */}
        <Route path={ROUTES.LOGIN} element={<Login />} />

        {/* Google Redirect Callback */}
        <Route path={ROUTES.AUTH_CALLBACK} element={<AuthCallback />} />

        {/* Hauptmenü geschützt */}
        <Route
          path={ROUTES.MENU}
          element={
            <ProtectedRoute>
              <MainMenu />
            </ProtectedRoute>
          }
        />

        {/* Module geschützt */}
        <Route
          path={ROUTES.KINDERTRAINING}
          element={
            <ProtectedRoute>
              <Kindertraining />
            </ProtectedRoute>
          }
        />
        <Route
          path={ROUTES.U12}
          element={
            <ProtectedRoute>
              <U12 />
            </ProtectedRoute>
          }
        />
        <Route
          path={ROUTES.U14}
          element={
            <ProtectedRoute>
              <U14 />
            </ProtectedRoute>
          }
        />
        <Route
          path={ROUTES.LEISTUNGSGRUPPE}
          element={
            <ProtectedRoute>
              <Leistungsgruppe />
            </ProtectedRoute>
          }
        />

        {/* Fallback */}
        <Route path="*" element={<Navigate to={ROUTES.MENU} replace />} />
      </Routes>
    </Router>
  );
}
