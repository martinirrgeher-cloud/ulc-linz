// src/routes.ts

export const ROUTES = {
  LOGIN: "/login",
  MENU: "/",
  AUTH_CALLBACK: "/auth/callback",

  // Module
  KINDERTRAINING: "/kindertraining",
  U12: "/u12",
  U14: "/u14",
  LEISTUNGSGRUPPE: "/leistungsgruppe",
};
