// src/pages/Login.tsx
import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { ROUTES } from "../routes";
import { isTokenValid, startGoogleLogin, restoreAccessToken } from "../lib/googleAuth";
import { validateUser, ensureUsersFileExists } from "../lib/users";
import { setCurrentUser } from "../lib/authStore";

export default function Login() {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const navigate = useNavigate();

  useEffect(() => {
    if (restoreAccessToken() && isTokenValid()) {
      navigate(ROUTES.MENU, { replace: true });
    }
  }, [navigate]);

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");

    if (!isTokenValid()) {
      startGoogleLogin(); // → Google Login Seite
      return;
    }

    try {
      await ensureUsersFileExists();
      const user = await validateUser(username, password);
      if (!user) {
        setError("❌ Benutzername oder Passwort ist ungültig");
        return;
      }
      setCurrentUser(user);
      navigate(ROUTES.MENU);
    } catch (err) {
      console.error("❌ Login Fehler:", err);
      setError("Login fehlgeschlagen");
    }
  };

  return (
    <div style={{ maxWidth: 400, margin: "0 auto" }}>
      <h1>🔐 Login</h1>
      <form onSubmit={handleLogin} style={{ display: "flex", flexDirection: "column", gap: 8 }}>
        <input
          type="text"
          placeholder="Benutzername (E-Mail)"
          value={username}
          onChange={(e) => setUsername(e.target.value)}
        />
        <input
          type="password"
          placeholder="Passwort"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
        />
        {error && <div style={{ color: "red" }}>{error}</div>}
        <button type="submit">Login mit Google</button>
      </form>
    </div>
  );
}
