// src/components/ProtectedRoute.tsx
import { Navigate } from "react-router-dom";
import { isTokenValid, forceLogout } from "../lib/googleAuth";
import { ROUTES } from "../routes";

export default function ProtectedRoute({ children }: { children: JSX.Element }) {
  if (!isTokenValid()) {
    console.warn("🚪 Kein/abgelaufener Token – redirect → Login");
    forceLogout();
    return <Navigate to={ROUTES.LOGIN} replace />;
  }
  return children;
}
